﻿namespace AFPI_Beejees_db
{
    partial class BCS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BCS));
            this.label1 = new System.Windows.Forms.Label();
            this.logo = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.buttonUMENU = new System.Windows.Forms.Button();
            this.buttonAMENU = new System.Windows.Forms.Button();
            this.buttonCMENU = new System.Windows.Forms.Button();
            this.buttonEXIT = new System.Windows.Forms.Button();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.buttonBP = new System.Windows.Forms.Button();
            this.buttonm = new System.Windows.Forms.Button();
            this.panelMenu2 = new System.Windows.Forms.Panel();
            this.buttonPD = new System.Windows.Forms.Button();
            this.buttonRDF = new System.Windows.Forms.Button();
            this.buttonRBF = new System.Windows.Forms.Button();
            this.dgvDELETE = new MetroFramework.Controls.MetroTabControl();
            this.tb1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exportCR = new System.Windows.Forms.Button();
            this.buttonSaveCR = new System.Windows.Forms.Button();
            this.delCR = new System.Windows.Forms.Button();
            this.dgvCR = new MetroFramework.Controls.MetroGrid();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonCreateCR = new System.Windows.Forms.Button();
            this.textBoxCANcr = new System.Windows.Forms.TextBox();
            this.tb2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.exportC = new System.Windows.Forms.Button();
            this.buttonSaveC = new System.Windows.Forms.Button();
            this.delC = new System.Windows.Forms.Button();
            this.timePortionDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.datePortionDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label236 = new System.Windows.Forms.Label();
            this.dgvC = new MetroFramework.Controls.MetroGrid();
            this.buttonCREATEC = new System.Windows.Forms.Button();
            this.CTC = new MetroFramework.Controls.MetroComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CSC = new MetroFramework.Controls.MetroComboBox();
            this.label243 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPBC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCANC = new System.Windows.Forms.TextBox();
            this.tb3 = new System.Windows.Forms.TabPage();
            this.panel = new System.Windows.Forms.Panel();
            this.exportBCR = new System.Windows.Forms.Button();
            this.buttonSaveBR = new System.Windows.Forms.Button();
            this.delBR = new System.Windows.Forms.Button();
            this.dgvBR = new MetroFramework.Controls.MetroGrid();
            this.textBoxBR = new System.Windows.Forms.TextBox();
            this.buttonADDBR = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxMN = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCANBR = new System.Windows.Forms.TextBox();
            this.tb4 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.exportBC = new System.Windows.Forms.Button();
            this.buttonSaveBC = new System.Windows.Forms.Button();
            this.delBC = new System.Windows.Forms.Button();
            this.metroComboBoxBDSN = new MetroFramework.Controls.MetroComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonADDBC = new System.Windows.Forms.Button();
            this.dgvBC = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxBRCBC = new MetroFramework.Controls.MetroComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxCANBC = new System.Windows.Forms.TextBox();
            this.tb5 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.exportBR = new System.Windows.Forms.Button();
            this.buttonSaveBRC = new System.Windows.Forms.Button();
            this.delBCR = new System.Windows.Forms.Button();
            this.dgvBCR = new MetroFramework.Controls.MetroGrid();
            this.buttonADDBRC = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxECANBR = new System.Windows.Forms.TextBox();
            this.metroComboBoxBRC = new MetroFramework.Controls.MetroComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxSCANBR = new System.Windows.Forms.TextBox();
            this.tb6 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.exportT = new System.Windows.Forms.Button();
            this.buttonSaveT = new System.Windows.Forms.Button();
            this.delT = new System.Windows.Forms.Button();
            this.dgvT = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxCANT = new MetroFramework.Controls.MetroComboBox();
            this.buttonADDT = new System.Windows.Forms.Button();
            this.dateTimePickerTT = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerT = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.metroComboBoxPNT = new MetroFramework.Controls.MetroComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxTAT = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.titleLB = new System.Windows.Forms.Label();
            this.togDEL = new MetroFramework.Controls.MetroToggle();
            this.label5 = new System.Windows.Forms.Label();
            this.qm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.panel14.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.panelMenu2.SuspendLayout();
            this.dgvDELETE.SuspendLayout();
            this.tb1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCR)).BeginInit();
            this.tb2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvC)).BeginInit();
            this.tb3.SuspendLayout();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBR)).BeginInit();
            this.tb4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBC)).BeginInit();
            this.tb5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBCR)).BeginInit();
            this.tb6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvT)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(382, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 0;
            // 
            // logo
            // 
            this.logo.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.logo1;
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logo.Location = new System.Drawing.Point(0, 5);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(356, 175);
            this.logo.TabIndex = 83;
            this.logo.TabStop = false;
            this.logo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.logo_MouseDown);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel14.Controls.Add(this.buttonUMENU);
            this.panel14.Controls.Add(this.buttonAMENU);
            this.panel14.Controls.Add(this.buttonCMENU);
            this.panel14.Controls.Add(this.buttonEXIT);
            this.panel14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel14.Location = new System.Drawing.Point(0, 179);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(94, 531);
            this.panel14.TabIndex = 87;
            // 
            // buttonUMENU
            // 
            this.buttonUMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.TRANS;
            this.buttonUMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonUMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUMENU.FlatAppearance.BorderSize = 0;
            this.buttonUMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUMENU.Location = new System.Drawing.Point(0, 209);
            this.buttonUMENU.Name = "buttonUMENU";
            this.buttonUMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonUMENU.TabIndex = 76;
            this.buttonUMENU.UseVisualStyleBackColor = true;
            this.buttonUMENU.Click += new System.EventHandler(this.buttonUMENU_Click);
            // 
            // buttonAMENU
            // 
            this.buttonAMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.CARDS1;
            this.buttonAMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonAMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonAMENU.FlatAppearance.BorderSize = 0;
            this.buttonAMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAMENU.Location = new System.Drawing.Point(0, 104);
            this.buttonAMENU.Name = "buttonAMENU";
            this.buttonAMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonAMENU.TabIndex = 75;
            this.buttonAMENU.UseVisualStyleBackColor = true;
            this.buttonAMENU.Click += new System.EventHandler(this.buttonAMENU_Click);
            // 
            // buttonCMENU
            // 
            this.buttonCMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonCMENU.BackColor = System.Drawing.Color.DimGray;
            this.buttonCMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.CARDS;
            this.buttonCMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonCMENU.FlatAppearance.BorderSize = 0;
            this.buttonCMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCMENU.Location = new System.Drawing.Point(0, 0);
            this.buttonCMENU.Name = "buttonCMENU";
            this.buttonCMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonCMENU.TabIndex = 68;
            this.buttonCMENU.UseVisualStyleBackColor = false;
            this.buttonCMENU.Click += new System.EventHandler(this.buttonCMENU_Click);
            // 
            // buttonEXIT
            // 
            this.buttonEXIT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonEXIT.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.DOWN1;
            this.buttonEXIT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonEXIT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonEXIT.FlatAppearance.BorderSize = 0;
            this.buttonEXIT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonEXIT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonEXIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEXIT.Location = new System.Drawing.Point(0, 421);
            this.buttonEXIT.Name = "buttonEXIT";
            this.buttonEXIT.Size = new System.Drawing.Size(94, 105);
            this.buttonEXIT.TabIndex = 75;
            this.buttonEXIT.UseVisualStyleBackColor = true;
            this.buttonEXIT.Click += new System.EventHandler(this.buttonEXIT_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu.Controls.Add(this.buttonBP);
            this.panelMenu.Controls.Add(this.buttonm);
            this.panelMenu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu.Location = new System.Drawing.Point(94, 178);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(262, 531);
            this.panelMenu.TabIndex = 84;
            // 
            // buttonBP
            // 
            this.buttonBP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBP.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonBP.FlatAppearance.BorderSize = 0;
            this.buttonBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBP.Location = new System.Drawing.Point(0, 58);
            this.buttonBP.Name = "buttonBP";
            this.buttonBP.Size = new System.Drawing.Size(263, 45);
            this.buttonBP.TabIndex = 69;
            this.buttonBP.Text = "Cards";
            this.buttonBP.UseVisualStyleBackColor = true;
            this.buttonBP.Click += new System.EventHandler(this.buttonBP_Click);
            // 
            // buttonm
            // 
            this.buttonm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonm.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonm.FlatAppearance.BorderSize = 0;
            this.buttonm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonm.Location = new System.Drawing.Point(0, 8);
            this.buttonm.Name = "buttonm";
            this.buttonm.Size = new System.Drawing.Size(263, 51);
            this.buttonm.TabIndex = 68;
            this.buttonm.Text = "Card Request";
            this.buttonm.UseVisualStyleBackColor = true;
            this.buttonm.Click += new System.EventHandler(this.buttonm_Click);
            // 
            // panelMenu2
            // 
            this.panelMenu2.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu2.Controls.Add(this.buttonPD);
            this.panelMenu2.Controls.Add(this.buttonRDF);
            this.panelMenu2.Controls.Add(this.buttonRBF);
            this.panelMenu2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu2.Location = new System.Drawing.Point(94, 178);
            this.panelMenu2.Name = "panelMenu2";
            this.panelMenu2.Size = new System.Drawing.Size(262, 531);
            this.panelMenu2.TabIndex = 85;
            // 
            // buttonPD
            // 
            this.buttonPD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPD.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPD.FlatAppearance.BorderSize = 0;
            this.buttonPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPD.Location = new System.Drawing.Point(0, 168);
            this.buttonPD.Name = "buttonPD";
            this.buttonPD.Size = new System.Drawing.Size(263, 53);
            this.buttonPD.TabIndex = 81;
            this.buttonPD.Text = "Blacklist Card Range";
            this.buttonPD.UseVisualStyleBackColor = true;
            this.buttonPD.Click += new System.EventHandler(this.buttonPD_Click);
            // 
            // buttonRDF
            // 
            this.buttonRDF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRDF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonRDF.FlatAppearance.BorderSize = 0;
            this.buttonRDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRDF.Location = new System.Drawing.Point(-1, 100);
            this.buttonRDF.Name = "buttonRDF";
            this.buttonRDF.Size = new System.Drawing.Size(263, 62);
            this.buttonRDF.TabIndex = 78;
            this.buttonRDF.Text = "Blacklist Cards";
            this.buttonRDF.UseVisualStyleBackColor = true;
            this.buttonRDF.Click += new System.EventHandler(this.buttonRDF_Click);
            // 
            // buttonRBF
            // 
            this.buttonRBF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRBF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonRBF.FlatAppearance.BorderSize = 0;
            this.buttonRBF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRBF.Location = new System.Drawing.Point(-1, 33);
            this.buttonRBF.Name = "buttonRBF";
            this.buttonRBF.Size = new System.Drawing.Size(263, 53);
            this.buttonRBF.TabIndex = 76;
            this.buttonRBF.Text = "Blacklist Requests";
            this.buttonRBF.UseVisualStyleBackColor = true;
            this.buttonRBF.Click += new System.EventHandler(this.buttonRBF_Click);
            // 
            // dgvDELETE
            // 
            this.dgvDELETE.Controls.Add(this.tb1);
            this.dgvDELETE.Controls.Add(this.tb2);
            this.dgvDELETE.Controls.Add(this.tb3);
            this.dgvDELETE.Controls.Add(this.tb4);
            this.dgvDELETE.Controls.Add(this.tb5);
            this.dgvDELETE.Controls.Add(this.tb6);
            this.dgvDELETE.FontSize = MetroFramework.MetroTabControlSize.Small;
            this.dgvDELETE.FontWeight = MetroFramework.MetroTabControlWeight.Regular;
            this.dgvDELETE.Location = new System.Drawing.Point(365, 47);
            this.dgvDELETE.Margin = new System.Windows.Forms.Padding(0);
            this.dgvDELETE.Name = "dgvDELETE";
            this.dgvDELETE.SelectedIndex = 5;
            this.dgvDELETE.Size = new System.Drawing.Size(950, 604);
            this.dgvDELETE.Style = MetroFramework.MetroColorStyle.Blue;
            this.dgvDELETE.TabIndex = 88;
            this.dgvDELETE.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dgvDELETE.UseSelectable = true;
            // 
            // tb1
            // 
            this.tb1.AllowDrop = true;
            this.tb1.AutoScroll = true;
            this.tb1.Controls.Add(this.panel1);
            this.tb1.Location = new System.Drawing.Point(4, 35);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(942, 565);
            this.tb1.TabIndex = 0;
            this.tb1.Text = "Card Request";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel1.Controls.Add(this.exportCR);
            this.panel1.Controls.Add(this.buttonSaveCR);
            this.panel1.Controls.Add(this.delCR);
            this.panel1.Controls.Add(this.dgvCR);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.buttonCreateCR);
            this.panel1.Controls.Add(this.textBoxCANcr);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(942, 565);
            this.panel1.TabIndex = 50;
            // 
            // exportCR
            // 
            this.exportCR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportCR.Location = new System.Drawing.Point(831, 258);
            this.exportCR.Name = "exportCR";
            this.exportCR.Size = new System.Drawing.Size(107, 45);
            this.exportCR.TabIndex = 218;
            this.exportCR.Text = "Export";
            this.exportCR.UseVisualStyleBackColor = false;
            this.exportCR.Click += new System.EventHandler(this.exportCR_Click);
            // 
            // buttonSaveCR
            // 
            this.buttonSaveCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveCR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Bold);
            this.buttonSaveCR.Location = new System.Drawing.Point(154, 99);
            this.buttonSaveCR.Name = "buttonSaveCR";
            this.buttonSaveCR.Size = new System.Drawing.Size(106, 34);
            this.buttonSaveCR.TabIndex = 214;
            this.buttonSaveCR.Text = "Save";
            this.buttonSaveCR.UseVisualStyleBackColor = true;
            this.buttonSaveCR.Visible = false;
            this.buttonSaveCR.Click += new System.EventHandler(this.buttonSaveCR_Click);
            // 
            // delCR
            // 
            this.delCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delCR.Location = new System.Drawing.Point(3, 260);
            this.delCR.Name = "delCR";
            this.delCR.Size = new System.Drawing.Size(107, 41);
            this.delCR.TabIndex = 213;
            this.delCR.Text = "Delete";
            this.delCR.UseVisualStyleBackColor = true;
            this.delCR.Visible = false;
            this.delCR.Click += new System.EventHandler(this.delCR_Click);
            // 
            // dgvCR
            // 
            this.dgvCR.AllowUserToAddRows = false;
            this.dgvCR.AllowUserToResizeRows = false;
            this.dgvCR.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCR.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvCR.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvCR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvCR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvCR.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCR.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCR.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCR.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvCR.EnableHeadersVisualStyles = false;
            this.dgvCR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvCR.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvCR.Location = new System.Drawing.Point(0, 306);
            this.dgvCR.MultiSelect = false;
            this.dgvCR.Name = "dgvCR";
            this.dgvCR.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCR.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvCR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvCR.RowTemplate.Height = 33;
            this.dgvCR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCR.Size = new System.Drawing.Size(942, 259);
            this.dgvCR.TabIndex = 204;
            this.dgvCR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCR_CellDoubleClick);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 14);
            this.label13.TabIndex = 67;
            this.label13.Text = "CAN:";
            // 
            // buttonCreateCR
            // 
            this.buttonCreateCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonCreateCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateCR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCreateCR.Location = new System.Drawing.Point(15, 99);
            this.buttonCreateCR.Name = "buttonCreateCR";
            this.buttonCreateCR.Size = new System.Drawing.Size(133, 34);
            this.buttonCreateCR.TabIndex = 66;
            this.buttonCreateCR.Text = "Create";
            this.buttonCreateCR.UseVisualStyleBackColor = true;
            this.buttonCreateCR.Click += new System.EventHandler(this.buttonCreateCR_Click);
            // 
            // textBoxCANcr
            // 
            this.textBoxCANcr.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCANcr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCANcr.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCANcr.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxCANcr.Location = new System.Drawing.Point(15, 45);
            this.textBoxCANcr.MaxLength = 16;
            this.textBoxCANcr.Name = "textBoxCANcr";
            this.textBoxCANcr.Size = new System.Drawing.Size(294, 26);
            this.textBoxCANcr.TabIndex = 65;
            this.textBoxCANcr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // tb2
            // 
            this.tb2.AllowDrop = true;
            this.tb2.AutoScroll = true;
            this.tb2.Controls.Add(this.panel2);
            this.tb2.Location = new System.Drawing.Point(4, 34);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(942, 566);
            this.tb2.TabIndex = 1;
            this.tb2.Text = "Cards";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.exportC);
            this.panel2.Controls.Add(this.buttonSaveC);
            this.panel2.Controls.Add(this.delC);
            this.panel2.Controls.Add(this.timePortionDateTimePicker);
            this.panel2.Controls.Add(this.datePortionDateTimePicker);
            this.panel2.Controls.Add(this.label236);
            this.panel2.Controls.Add(this.dgvC);
            this.panel2.Controls.Add(this.buttonCREATEC);
            this.panel2.Controls.Add(this.CTC);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.CSC);
            this.panel2.Controls.Add(this.label243);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBoxPBC);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textBoxCANC);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(942, 566);
            this.panel2.TabIndex = 11;
            // 
            // exportC
            // 
            this.exportC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportC.Location = new System.Drawing.Point(805, 208);
            this.exportC.Name = "exportC";
            this.exportC.Size = new System.Drawing.Size(133, 45);
            this.exportC.TabIndex = 218;
            this.exportC.Text = "Export";
            this.exportC.UseVisualStyleBackColor = false;
            this.exportC.Click += new System.EventHandler(this.exportC_Click);
            // 
            // buttonSaveC
            // 
            this.buttonSaveC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveC.Location = new System.Drawing.Point(693, 118);
            this.buttonSaveC.Name = "buttonSaveC";
            this.buttonSaveC.Size = new System.Drawing.Size(106, 45);
            this.buttonSaveC.TabIndex = 215;
            this.buttonSaveC.Text = "Save";
            this.buttonSaveC.UseVisualStyleBackColor = true;
            this.buttonSaveC.Visible = false;
            this.buttonSaveC.Click += new System.EventHandler(this.buttonSaveC_Click);
            // 
            // delC
            // 
            this.delC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delC.Location = new System.Drawing.Point(0, 243);
            this.delC.Name = "delC";
            this.delC.Size = new System.Drawing.Size(111, 41);
            this.delC.TabIndex = 213;
            this.delC.Text = "Delete";
            this.delC.UseVisualStyleBackColor = true;
            this.delC.Visible = false;
            this.delC.Click += new System.EventHandler(this.delC_Click);
            // 
            // timePortionDateTimePicker
            // 
            this.timePortionDateTimePicker.Font = new System.Drawing.Font("Google Sans", 10.875F);
            this.timePortionDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.timePortionDateTimePicker.Location = new System.Drawing.Point(786, 43);
            this.timePortionDateTimePicker.Name = "timePortionDateTimePicker";
            this.timePortionDateTimePicker.Size = new System.Drawing.Size(132, 26);
            this.timePortionDateTimePicker.TabIndex = 199;
            // 
            // datePortionDateTimePicker
            // 
            this.datePortionDateTimePicker.Font = new System.Drawing.Font("Google Sans", 10.875F);
            this.datePortionDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePortionDateTimePicker.Location = new System.Drawing.Point(620, 43);
            this.datePortionDateTimePicker.Name = "datePortionDateTimePicker";
            this.datePortionDateTimePicker.Size = new System.Drawing.Size(160, 26);
            this.datePortionDateTimePicker.TabIndex = 198;
            // 
            // label236
            // 
            this.label236.AutoSize = true;
            this.label236.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label236.Location = new System.Drawing.Point(620, 14);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(89, 14);
            this.label236.TabIndex = 197;
            this.label236.Text = "Card Sync Date:";
            // 
            // dgvC
            // 
            this.dgvC.AllowUserToAddRows = false;
            this.dgvC.AllowUserToResizeRows = false;
            this.dgvC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvC.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvC.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvC.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvC.EnableHeadersVisualStyles = false;
            this.dgvC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvC.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvC.Location = new System.Drawing.Point(0, 259);
            this.dgvC.MultiSelect = false;
            this.dgvC.Name = "dgvC";
            this.dgvC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvC.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvC.RowTemplate.Height = 33;
            this.dgvC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvC.Size = new System.Drawing.Size(942, 307);
            this.dgvC.TabIndex = 190;
            this.dgvC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvC_CellDoubleClick);
            // 
            // buttonCREATEC
            // 
            this.buttonCREATEC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonCREATEC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCREATEC.Location = new System.Drawing.Point(805, 118);
            this.buttonCREATEC.Name = "buttonCREATEC";
            this.buttonCREATEC.Size = new System.Drawing.Size(133, 45);
            this.buttonCREATEC.TabIndex = 189;
            this.buttonCREATEC.Text = "Add";
            this.buttonCREATEC.UseVisualStyleBackColor = true;
            this.buttonCREATEC.Click += new System.EventHandler(this.buttonUP_UA_Click);
            // 
            // CTC
            // 
            this.CTC.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.CTC.ForeColor = System.Drawing.SystemColors.WindowText;
            this.CTC.FormattingEnabled = true;
            this.CTC.ItemHeight = 23;
            this.CTC.Items.AddRange(new object[] {
            "0",
            "1",
            "17",
            "18",
            "19",
            "2",
            "20",
            "21",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.CTC.Location = new System.Drawing.Point(196, 129);
            this.CTC.Name = "CTC";
            this.CTC.Size = new System.Drawing.Size(170, 29);
            this.CTC.Sorted = true;
            this.CTC.TabIndex = 188;
            this.CTC.UseSelectable = true;
            this.CTC.UseStyleColors = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(191, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 14);
            this.label4.TabIndex = 187;
            this.label4.Text = "Card Type:";
            // 
            // CSC
            // 
            this.CSC.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.CSC.ForeColor = System.Drawing.SystemColors.WindowText;
            this.CSC.FormattingEnabled = true;
            this.CSC.ItemHeight = 23;
            this.CSC.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.CSC.Location = new System.Drawing.Point(15, 129);
            this.CSC.Name = "CSC";
            this.CSC.Size = new System.Drawing.Size(170, 29);
            this.CSC.Sorted = true;
            this.CSC.TabIndex = 186;
            this.CSC.UseSelectable = true;
            this.CSC.UseStyleColors = true;
            // 
            // label243
            // 
            this.label243.AutoSize = true;
            this.label243.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label243.Location = new System.Drawing.Point(10, 102);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(69, 14);
            this.label243.TabIndex = 185;
            this.label243.Text = "Card Status:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(317, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 14);
            this.label3.TabIndex = 71;
            this.label3.Text = "Purse Balance:";
            // 
            // textBoxPBC
            // 
            this.textBoxPBC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxPBC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPBC.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPBC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxPBC.Location = new System.Drawing.Point(320, 43);
            this.textBoxPBC.MaxLength = 16;
            this.textBoxPBC.Name = "textBoxPBC";
            this.textBoxPBC.Size = new System.Drawing.Size(294, 26);
            this.textBoxPBC.TabIndex = 70;
            this.textBoxPBC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 14);
            this.label2.TabIndex = 69;
            this.label2.Text = "CAN:";
            // 
            // textBoxCANC
            // 
            this.textBoxCANC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCANC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCANC.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCANC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxCANC.Location = new System.Drawing.Point(13, 43);
            this.textBoxCANC.MaxLength = 16;
            this.textBoxCANC.Name = "textBoxCANC";
            this.textBoxCANC.Size = new System.Drawing.Size(294, 26);
            this.textBoxCANC.TabIndex = 68;
            this.textBoxCANC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // tb3
            // 
            this.tb3.AllowDrop = true;
            this.tb3.AutoScroll = true;
            this.tb3.Controls.Add(this.panel);
            this.tb3.Location = new System.Drawing.Point(4, 34);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(942, 566);
            this.tb3.TabIndex = 2;
            this.tb3.Text = "Blacklisted Requests";
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.SystemColors.Window;
            this.panel.Controls.Add(this.exportBCR);
            this.panel.Controls.Add(this.buttonSaveBR);
            this.panel.Controls.Add(this.delBR);
            this.panel.Controls.Add(this.dgvBR);
            this.panel.Controls.Add(this.textBoxBR);
            this.panel.Controls.Add(this.buttonADDBR);
            this.panel.Controls.Add(this.label6);
            this.panel.Controls.Add(this.label7);
            this.panel.Controls.Add(this.textBoxMN);
            this.panel.Controls.Add(this.label8);
            this.panel.Controls.Add(this.textBoxCANBR);
            this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(942, 566);
            this.panel.TabIndex = 12;
            // 
            // exportBCR
            // 
            this.exportBCR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportBCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportBCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportBCR.Location = new System.Drawing.Point(794, 218);
            this.exportBCR.Name = "exportBCR";
            this.exportBCR.Size = new System.Drawing.Size(133, 45);
            this.exportBCR.TabIndex = 218;
            this.exportBCR.Text = "Export";
            this.exportBCR.UseVisualStyleBackColor = false;
            this.exportBCR.Click += new System.EventHandler(this.exportBCR_Click);
            // 
            // buttonSaveBR
            // 
            this.buttonSaveBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveBR.Location = new System.Drawing.Point(682, 92);
            this.buttonSaveBR.Name = "buttonSaveBR";
            this.buttonSaveBR.Size = new System.Drawing.Size(106, 45);
            this.buttonSaveBR.TabIndex = 216;
            this.buttonSaveBR.Text = "Save";
            this.buttonSaveBR.UseVisualStyleBackColor = true;
            this.buttonSaveBR.Visible = false;
            this.buttonSaveBR.Click += new System.EventHandler(this.buttonSaveBR_Click);
            // 
            // delBR
            // 
            this.delBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delBR.Location = new System.Drawing.Point(0, 253);
            this.delBR.Name = "delBR";
            this.delBR.Size = new System.Drawing.Size(111, 41);
            this.delBR.TabIndex = 213;
            this.delBR.Text = "Delete";
            this.delBR.UseVisualStyleBackColor = true;
            this.delBR.Visible = false;
            this.delBR.Click += new System.EventHandler(this.delBR_Click);
            // 
            // dgvBR
            // 
            this.dgvBR.AllowUserToAddRows = false;
            this.dgvBR.AllowUserToResizeRows = false;
            this.dgvBR.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBR.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvBR.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBR.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvBR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBR.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvBR.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvBR.EnableHeadersVisualStyles = false;
            this.dgvBR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvBR.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBR.Location = new System.Drawing.Point(0, 269);
            this.dgvBR.MultiSelect = false;
            this.dgvBR.Name = "dgvBR";
            this.dgvBR.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBR.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvBR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBR.RowTemplate.Height = 33;
            this.dgvBR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBR.Size = new System.Drawing.Size(942, 297);
            this.dgvBR.TabIndex = 195;
            this.dgvBR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBR_CellDoubleClick);
            // 
            // textBoxBR
            // 
            this.textBoxBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBR.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxBR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxBR.Location = new System.Drawing.Point(633, 42);
            this.textBoxBR.MaxLength = 40;
            this.textBoxBR.Name = "textBoxBR";
            this.textBoxBR.Size = new System.Drawing.Size(294, 26);
            this.textBoxBR.TabIndex = 194;
            // 
            // buttonADDBR
            // 
            this.buttonADDBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonADDBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonADDBR.Location = new System.Drawing.Point(794, 92);
            this.buttonADDBR.Name = "buttonADDBR";
            this.buttonADDBR.Size = new System.Drawing.Size(133, 45);
            this.buttonADDBR.TabIndex = 193;
            this.buttonADDBR.Text = "Add";
            this.buttonADDBR.UseVisualStyleBackColor = true;
            this.buttonADDBR.Click += new System.EventHandler(this.buttonADDBR_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(628, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 14);
            this.label6.TabIndex = 191;
            this.label6.Text = "Blacklist Reason";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(327, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 14);
            this.label7.TabIndex = 190;
            this.label7.Text = "Mobile Number:";
            // 
            // textBoxMN
            // 
            this.textBoxMN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxMN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMN.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMN.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxMN.Location = new System.Drawing.Point(330, 42);
            this.textBoxMN.MaxLength = 13;
            this.textBoxMN.Name = "textBoxMN";
            this.textBoxMN.Size = new System.Drawing.Size(294, 26);
            this.textBoxMN.TabIndex = 189;
            this.textBoxMN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 14);
            this.label8.TabIndex = 188;
            this.label8.Text = "CAN:";
            // 
            // textBoxCANBR
            // 
            this.textBoxCANBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCANBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCANBR.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCANBR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxCANBR.Location = new System.Drawing.Point(13, 42);
            this.textBoxCANBR.MaxLength = 16;
            this.textBoxCANBR.Name = "textBoxCANBR";
            this.textBoxCANBR.Size = new System.Drawing.Size(294, 26);
            this.textBoxCANBR.TabIndex = 187;
            this.textBoxCANBR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // tb4
            // 
            this.tb4.Controls.Add(this.panel3);
            this.tb4.Location = new System.Drawing.Point(4, 34);
            this.tb4.Name = "tb4";
            this.tb4.Size = new System.Drawing.Size(942, 566);
            this.tb4.TabIndex = 3;
            this.tb4.Text = "Blacklisted Cards";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel3.Controls.Add(this.exportBC);
            this.panel3.Controls.Add(this.buttonSaveBC);
            this.panel3.Controls.Add(this.delBC);
            this.panel3.Controls.Add(this.metroComboBoxBDSN);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.buttonADDBC);
            this.panel3.Controls.Add(this.dgvBC);
            this.panel3.Controls.Add(this.metroComboBoxBRCBC);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.textBoxCANBC);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(942, 566);
            this.panel3.TabIndex = 51;
            // 
            // exportBC
            // 
            this.exportBC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportBC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportBC.Location = new System.Drawing.Point(772, 232);
            this.exportBC.Name = "exportBC";
            this.exportBC.Size = new System.Drawing.Size(133, 45);
            this.exportBC.TabIndex = 218;
            this.exportBC.Text = "Export";
            this.exportBC.UseVisualStyleBackColor = false;
            this.exportBC.Click += new System.EventHandler(this.exportBC_Click);
            // 
            // buttonSaveBC
            // 
            this.buttonSaveBC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveBC.Location = new System.Drawing.Point(659, 76);
            this.buttonSaveBC.Name = "buttonSaveBC";
            this.buttonSaveBC.Size = new System.Drawing.Size(106, 45);
            this.buttonSaveBC.TabIndex = 216;
            this.buttonSaveBC.Text = "Save";
            this.buttonSaveBC.UseVisualStyleBackColor = true;
            this.buttonSaveBC.Visible = false;
            this.buttonSaveBC.Click += new System.EventHandler(this.buttonSaveBC_Click);
            // 
            // delBC
            // 
            this.delBC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delBC.Location = new System.Drawing.Point(0, 255);
            this.delBC.Name = "delBC";
            this.delBC.Size = new System.Drawing.Size(111, 41);
            this.delBC.TabIndex = 213;
            this.delBC.Text = "Delete";
            this.delBC.UseVisualStyleBackColor = true;
            this.delBC.Visible = false;
            this.delBC.Click += new System.EventHandler(this.delBC_Click);
            // 
            // metroComboBoxBDSN
            // 
            this.metroComboBoxBDSN.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxBDSN.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxBDSN.FormattingEnabled = true;
            this.metroComboBoxBDSN.ItemHeight = 23;
            this.metroComboBoxBDSN.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.metroComboBoxBDSN.Location = new System.Drawing.Point(315, 30);
            this.metroComboBoxBDSN.Name = "metroComboBoxBDSN";
            this.metroComboBoxBDSN.Size = new System.Drawing.Size(296, 29);
            this.metroComboBoxBDSN.Sorted = true;
            this.metroComboBoxBDSN.TabIndex = 208;
            this.metroComboBoxBDSN.UseSelectable = true;
            this.metroComboBoxBDSN.UseStyleColors = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(310, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 14);
            this.label11.TabIndex = 207;
            this.label11.Text = "Bad debt Sequence no.:";
            // 
            // buttonADDBC
            // 
            this.buttonADDBC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonADDBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonADDBC.Location = new System.Drawing.Point(771, 76);
            this.buttonADDBC.Name = "buttonADDBC";
            this.buttonADDBC.Size = new System.Drawing.Size(133, 45);
            this.buttonADDBC.TabIndex = 206;
            this.buttonADDBC.Text = "Add";
            this.buttonADDBC.UseVisualStyleBackColor = true;
            this.buttonADDBC.Click += new System.EventHandler(this.buttonCREATEBC_Click);
            // 
            // dgvBC
            // 
            this.dgvBC.AllowUserToAddRows = false;
            this.dgvBC.AllowUserToResizeRows = false;
            this.dgvBC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvBC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBC.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvBC.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvBC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBC.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvBC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvBC.EnableHeadersVisualStyles = false;
            this.dgvBC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvBC.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBC.Location = new System.Drawing.Point(0, 272);
            this.dgvBC.MultiSelect = false;
            this.dgvBC.Name = "dgvBC";
            this.dgvBC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBC.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvBC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBC.RowTemplate.Height = 33;
            this.dgvBC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBC.Size = new System.Drawing.Size(942, 294);
            this.dgvBC.TabIndex = 205;
            this.dgvBC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBC_CellDoubleClick);
            // 
            // metroComboBoxBRCBC
            // 
            this.metroComboBoxBRCBC.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxBRCBC.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxBRCBC.FormattingEnabled = true;
            this.metroComboBoxBRCBC.ItemHeight = 23;
            this.metroComboBoxBRCBC.Items.AddRange(new object[] {
            "1",
            "2",
            "6",
            "5",
            "7",
            "8",
            "21"});
            this.metroComboBoxBRCBC.Location = new System.Drawing.Point(625, 30);
            this.metroComboBoxBRCBC.Name = "metroComboBoxBRCBC";
            this.metroComboBoxBRCBC.Size = new System.Drawing.Size(280, 29);
            this.metroComboBoxBRCBC.TabIndex = 188;
            this.metroComboBoxBRCBC.UseSelectable = true;
            this.metroComboBoxBRCBC.UseStyleColors = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(620, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 14);
            this.label10.TabIndex = 187;
            this.label10.Text = "Blacklist Reason Code:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 14);
            this.label9.TabIndex = 70;
            this.label9.Text = "CAN:";
            // 
            // textBoxCANBC
            // 
            this.textBoxCANBC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCANBC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCANBC.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCANBC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxCANBC.Location = new System.Drawing.Point(13, 32);
            this.textBoxCANBC.MaxLength = 16;
            this.textBoxCANBC.Name = "textBoxCANBC";
            this.textBoxCANBC.Size = new System.Drawing.Size(294, 26);
            this.textBoxCANBC.TabIndex = 68;
            this.textBoxCANBC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // tb5
            // 
            this.tb5.Controls.Add(this.panel4);
            this.tb5.Location = new System.Drawing.Point(4, 34);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(942, 566);
            this.tb5.TabIndex = 4;
            this.tb5.Text = "Blacklisted Range";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel4.Controls.Add(this.exportBR);
            this.panel4.Controls.Add(this.buttonSaveBRC);
            this.panel4.Controls.Add(this.delBCR);
            this.panel4.Controls.Add(this.dgvBCR);
            this.panel4.Controls.Add(this.buttonADDBRC);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.textBoxECANBR);
            this.panel4.Controls.Add(this.metroComboBoxBRC);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.textBoxSCANBR);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(942, 566);
            this.panel4.TabIndex = 51;
            // 
            // exportBR
            // 
            this.exportBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportBR.Location = new System.Drawing.Point(805, 223);
            this.exportBR.Name = "exportBR";
            this.exportBR.Size = new System.Drawing.Size(133, 45);
            this.exportBR.TabIndex = 218;
            this.exportBR.Text = "Export";
            this.exportBR.UseVisualStyleBackColor = false;
            this.exportBR.Click += new System.EventHandler(this.exportBR_Click);
            // 
            // buttonSaveBRC
            // 
            this.buttonSaveBRC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveBRC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveBRC.Location = new System.Drawing.Point(696, 105);
            this.buttonSaveBRC.Name = "buttonSaveBRC";
            this.buttonSaveBRC.Size = new System.Drawing.Size(106, 45);
            this.buttonSaveBRC.TabIndex = 216;
            this.buttonSaveBRC.Text = "Save";
            this.buttonSaveBRC.UseVisualStyleBackColor = true;
            this.buttonSaveBRC.Visible = false;
            this.buttonSaveBRC.Click += new System.EventHandler(this.buttonSaveBRC_Click);
            // 
            // delBCR
            // 
            this.delBCR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delBCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delBCR.Location = new System.Drawing.Point(0, 253);
            this.delBCR.Name = "delBCR";
            this.delBCR.Size = new System.Drawing.Size(133, 41);
            this.delBCR.TabIndex = 213;
            this.delBCR.Text = "Delete";
            this.delBCR.UseVisualStyleBackColor = true;
            this.delBCR.Visible = false;
            this.delBCR.Click += new System.EventHandler(this.delBCR_Click);
            // 
            // dgvBCR
            // 
            this.dgvBCR.AllowUserToAddRows = false;
            this.dgvBCR.AllowUserToResizeRows = false;
            this.dgvBCR.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBCR.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBCR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBCR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvBCR.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBCR.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvBCR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBCR.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvBCR.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvBCR.EnableHeadersVisualStyles = false;
            this.dgvBCR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvBCR.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBCR.Location = new System.Drawing.Point(0, 274);
            this.dgvBCR.MultiSelect = false;
            this.dgvBCR.Name = "dgvBCR";
            this.dgvBCR.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBCR.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvBCR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBCR.RowTemplate.Height = 33;
            this.dgvBCR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBCR.Size = new System.Drawing.Size(942, 292);
            this.dgvBCR.TabIndex = 208;
            this.dgvBCR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBCR_CellDoubleClick);
            // 
            // buttonADDBRC
            // 
            this.buttonADDBRC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonADDBRC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonADDBRC.Location = new System.Drawing.Point(805, 105);
            this.buttonADDBRC.Margin = new System.Windows.Forms.Padding(0);
            this.buttonADDBRC.Name = "buttonADDBRC";
            this.buttonADDBRC.Size = new System.Drawing.Size(133, 45);
            this.buttonADDBRC.TabIndex = 207;
            this.buttonADDBRC.Text = "Add";
            this.buttonADDBRC.UseVisualStyleBackColor = true;
            this.buttonADDBRC.Click += new System.EventHandler(this.buttonADDBRC_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(271, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(160, 14);
            this.label15.TabIndex = 194;
            this.label15.Text = "End Card Application Number:";
            // 
            // textBoxECANBR
            // 
            this.textBoxECANBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxECANBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxECANBR.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxECANBR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxECANBR.Location = new System.Drawing.Point(274, 45);
            this.textBoxECANBR.MaxLength = 16;
            this.textBoxECANBR.Name = "textBoxECANBR";
            this.textBoxECANBR.Size = new System.Drawing.Size(294, 26);
            this.textBoxECANBR.TabIndex = 193;
            this.textBoxECANBR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // metroComboBoxBRC
            // 
            this.metroComboBoxBRC.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxBRC.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxBRC.FormattingEnabled = true;
            this.metroComboBoxBRC.ItemHeight = 23;
            this.metroComboBoxBRC.Items.AddRange(new object[] {
            "1",
            "2",
            "6",
            "5",
            "7",
            "8",
            "21"});
            this.metroComboBoxBRC.Location = new System.Drawing.Point(579, 45);
            this.metroComboBoxBRC.Name = "metroComboBoxBRC";
            this.metroComboBoxBRC.Size = new System.Drawing.Size(359, 29);
            this.metroComboBoxBRC.TabIndex = 192;
            this.metroComboBoxBRC.UseSelectable = true;
            this.metroComboBoxBRC.UseStyleColors = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(574, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 14);
            this.label12.TabIndex = 191;
            this.label12.Text = "Blacklist Reason Code:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(10, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(165, 14);
            this.label14.TabIndex = 190;
            this.label14.Text = "Start Card Application Number:";
            // 
            // textBoxSCANBR
            // 
            this.textBoxSCANBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSCANBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSCANBR.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSCANBR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSCANBR.Location = new System.Drawing.Point(13, 45);
            this.textBoxSCANBR.MaxLength = 16;
            this.textBoxSCANBR.Name = "textBoxSCANBR";
            this.textBoxSCANBR.Size = new System.Drawing.Size(252, 26);
            this.textBoxSCANBR.TabIndex = 189;
            this.textBoxSCANBR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // tb6
            // 
            this.tb6.Controls.Add(this.panel5);
            this.tb6.Location = new System.Drawing.Point(4, 34);
            this.tb6.Name = "tb6";
            this.tb6.Size = new System.Drawing.Size(942, 566);
            this.tb6.TabIndex = 5;
            this.tb6.Text = "Transactions";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel5.Controls.Add(this.exportT);
            this.panel5.Controls.Add(this.buttonSaveT);
            this.panel5.Controls.Add(this.delT);
            this.panel5.Controls.Add(this.dgvT);
            this.panel5.Controls.Add(this.metroComboBoxCANT);
            this.panel5.Controls.Add(this.buttonADDT);
            this.panel5.Controls.Add(this.dateTimePickerTT);
            this.panel5.Controls.Add(this.dateTimePickerT);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.metroComboBoxPNT);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.textBoxTAT);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(942, 566);
            this.panel5.TabIndex = 51;
            // 
            // exportT
            // 
            this.exportT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.exportT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exportT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportT.Location = new System.Drawing.Point(805, 214);
            this.exportT.Name = "exportT";
            this.exportT.Size = new System.Drawing.Size(133, 45);
            this.exportT.TabIndex = 217;
            this.exportT.Text = "Export";
            this.exportT.UseVisualStyleBackColor = false;
            this.exportT.Click += new System.EventHandler(this.exportT_Click);
            // 
            // buttonSaveT
            // 
            this.buttonSaveT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveT.Location = new System.Drawing.Point(711, 81);
            this.buttonSaveT.Name = "buttonSaveT";
            this.buttonSaveT.Size = new System.Drawing.Size(106, 45);
            this.buttonSaveT.TabIndex = 216;
            this.buttonSaveT.Text = "Save";
            this.buttonSaveT.UseVisualStyleBackColor = true;
            this.buttonSaveT.Visible = false;
            this.buttonSaveT.Click += new System.EventHandler(this.buttonSaveT_Click);
            // 
            // delT
            // 
            this.delT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.delT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delT.Location = new System.Drawing.Point(0, 252);
            this.delT.Name = "delT";
            this.delT.Size = new System.Drawing.Size(133, 41);
            this.delT.TabIndex = 212;
            this.delT.Text = "Delete";
            this.delT.UseVisualStyleBackColor = true;
            this.delT.Visible = false;
            this.delT.Click += new System.EventHandler(this.delT_Click);
            // 
            // dgvT
            // 
            this.dgvT.AllowUserToAddRows = false;
            this.dgvT.AllowUserToResizeRows = false;
            this.dgvT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvT.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvT.EnableHeadersVisualStyles = false;
            this.dgvT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvT.Location = new System.Drawing.Point(0, 269);
            this.dgvT.MultiSelect = false;
            this.dgvT.Name = "dgvT";
            this.dgvT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvT.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvT.RowTemplate.Height = 33;
            this.dgvT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvT.Size = new System.Drawing.Size(942, 297);
            this.dgvT.TabIndex = 211;
            this.dgvT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvT_CellDoubleClick);
            // 
            // metroComboBoxCANT
            // 
            this.metroComboBoxCANT.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxCANT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxCANT.FormattingEnabled = true;
            this.metroComboBoxCANT.ItemHeight = 23;
            this.metroComboBoxCANT.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.metroComboBoxCANT.Location = new System.Drawing.Point(21, 44);
            this.metroComboBoxCANT.Name = "metroComboBoxCANT";
            this.metroComboBoxCANT.Size = new System.Drawing.Size(170, 29);
            this.metroComboBoxCANT.Sorted = true;
            this.metroComboBoxCANT.TabIndex = 210;
            this.metroComboBoxCANT.UseSelectable = true;
            this.metroComboBoxCANT.UseStyleColors = true;
            // 
            // buttonADDT
            // 
            this.buttonADDT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonADDT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonADDT.Location = new System.Drawing.Point(823, 81);
            this.buttonADDT.Name = "buttonADDT";
            this.buttonADDT.Size = new System.Drawing.Size(115, 45);
            this.buttonADDT.TabIndex = 209;
            this.buttonADDT.Text = "Add";
            this.buttonADDT.UseVisualStyleBackColor = true;
            this.buttonADDT.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePickerTT
            // 
            this.dateTimePickerTT.Font = new System.Drawing.Font("Google Sans", 10.875F);
            this.dateTimePickerTT.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerTT.Location = new System.Drawing.Point(187, 105);
            this.dateTimePickerTT.Name = "dateTimePickerTT";
            this.dateTimePickerTT.Size = new System.Drawing.Size(153, 26);
            this.dateTimePickerTT.TabIndex = 208;
            // 
            // dateTimePickerT
            // 
            this.dateTimePickerT.Font = new System.Drawing.Font("Google Sans", 10.875F);
            this.dateTimePickerT.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerT.Location = new System.Drawing.Point(21, 105);
            this.dateTimePickerT.Name = "dateTimePickerT";
            this.dateTimePickerT.Size = new System.Drawing.Size(160, 26);
            this.dateTimePickerT.TabIndex = 207;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(21, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 14);
            this.label16.TabIndex = 206;
            this.label16.Text = "Card Sync Date:";
            // 
            // metroComboBoxPNT
            // 
            this.metroComboBoxPNT.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPNT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPNT.FormattingEnabled = true;
            this.metroComboBoxPNT.ItemHeight = 23;
            this.metroComboBoxPNT.Items.AddRange(new object[] {
            "AF Payments Inc.",
            "Ayala Foundation",
            "Ayala Property Mgnt Corp",
            "Bank of the Philippine Islands",
            "BGC Bus",
            "Binalot Fiesta Food  Inc",
            "Biocrest Multi-Purpose Coop.",
            "China Banking Corporation",
            "Citylink Bus",
            "Clemenisle Inc.",
            "CoinsPH",
            "DELTA NEOSOLUTIONS",
            "FamilyMart",
            "Froehlich Tours",
            "G-Xchange  Inc.",
            "Genesis Transport Services Inc",
            "Global Pinoy Remittance & Svcs",
            "HM Transport Inc",
            "Island Ferries",
            "LRT1 Rail Service Provider",
            "LRT2 Rail Service Provider",
            "McDonalds PH",
            "MRT3 Rail Service Provider",
            "N. Dela Rosa liner",
            "Paymaya Philippines  Inc",
            "Robinsons Convenience Store",
            "Robinsons Land Corp. Snackbar ",
            "RRCG EAST",
            "RRCG Transport Systems Co Inc",
            "San Miguel Foods Inc",
            "Senate Employees Trans Service",
            "Taguig Transport Service Coop",
            "TAS Group of Companies",
            "TouchPay",
            "UNITED COCONUT PLANTERS BANK",
            "Wenphil Corporation",
            "Xytrix Systems Corporation"});
            this.metroComboBoxPNT.Location = new System.Drawing.Point(201, 44);
            this.metroComboBoxPNT.Name = "metroComboBoxPNT";
            this.metroComboBoxPNT.Size = new System.Drawing.Size(395, 29);
            this.metroComboBoxPNT.Sorted = true;
            this.metroComboBoxPNT.TabIndex = 205;
            this.metroComboBoxPNT.UseSelectable = true;
            this.metroComboBoxPNT.UseStyleColors = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(196, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 14);
            this.label17.TabIndex = 204;
            this.label17.Text = "Participant Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(610, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(110, 14);
            this.label18.TabIndex = 203;
            this.label18.Text = "Transaction Amount:";
            // 
            // textBoxTAT
            // 
            this.textBoxTAT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxTAT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTAT.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTAT.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxTAT.Location = new System.Drawing.Point(613, 45);
            this.textBoxTAT.MaxLength = 16;
            this.textBoxTAT.Name = "textBoxTAT";
            this.textBoxTAT.Size = new System.Drawing.Size(325, 26);
            this.textBoxTAT.TabIndex = 202;
            this.textBoxTAT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPNBP_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(21, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 14);
            this.label19.TabIndex = 201;
            this.label19.Text = "Card:";
            // 
            // titleLB
            // 
            this.titleLB.AutoSize = true;
            this.titleLB.Font = new System.Drawing.Font("Google Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.titleLB.Location = new System.Drawing.Point(376, 16);
            this.titleLB.Name = "titleLB";
            this.titleLB.Size = new System.Drawing.Size(0, 20);
            this.titleLB.TabIndex = 89;
            // 
            // togDEL
            // 
            this.togDEL.AutoSize = true;
            this.togDEL.Location = new System.Drawing.Point(466, 659);
            this.togDEL.Name = "togDEL";
            this.togDEL.Size = new System.Drawing.Size(80, 22);
            this.togDEL.TabIndex = 90;
            this.togDEL.Text = "Off";
            this.togDEL.UseSelectable = true;
            this.togDEL.CheckedChanged += new System.EventHandler(this.togDEL_CheckedChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(383, 663);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 14);
            this.label5.TabIndex = 91;
            this.label5.Text = "Admin Mode:";
            // 
            // qm
            // 
            this.qm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.qm.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.qm1;
            this.qm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.qm.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.qm.FlatAppearance.BorderSize = 0;
            this.qm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.qm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qm.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qm.Location = new System.Drawing.Point(1291, 663);
            this.qm.Name = "qm";
            this.qm.Size = new System.Drawing.Size(24, 25);
            this.qm.TabIndex = 219;
            this.qm.UseVisualStyleBackColor = true;
            this.qm.Click += new System.EventHandler(this.qm_Click);
            // 
            // BCS
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(1340, 707);
            this.Controls.Add(this.qm);
            this.Controls.Add(this.togDEL);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.titleLB);
            this.Controls.Add(this.dgvDELETE);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelMenu2);
            this.Controls.Add(this.panelMenu);
            this.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BCS";
            this.Padding = new System.Windows.Forms.Padding(30, 87, 30, 29);
            this.Resizable = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Card Manager";
            this.Theme = MetroFramework.MetroThemeStyle.Default;
            this.TransparencyKey = System.Drawing.Color.Ivory;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.Load += new System.EventHandler(this.BCS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu2.ResumeLayout(false);
            this.dgvDELETE.ResumeLayout(false);
            this.tb1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCR)).EndInit();
            this.tb2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvC)).EndInit();
            this.tb3.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBR)).EndInit();
            this.tb4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBC)).EndInit();
            this.tb5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBCR)).EndInit();
            this.tb6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button buttonUMENU;
        private System.Windows.Forms.Button buttonAMENU;
        private System.Windows.Forms.Button buttonCMENU;
        private System.Windows.Forms.Button buttonEXIT;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button buttonBP;
        private System.Windows.Forms.Button buttonm;
        private System.Windows.Forms.Panel panelMenu2;
        private System.Windows.Forms.Button buttonPD;
        private System.Windows.Forms.Button buttonRDF;
        private System.Windows.Forms.Button buttonRBF;
        private MetroFramework.Controls.MetroTabControl dgvDELETE;
        private System.Windows.Forms.TabPage tb1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tb2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabPage tb3;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label titleLB;
        private System.Windows.Forms.TabPage tb4;
        private System.Windows.Forms.TabPage tb5;
        private System.Windows.Forms.TabPage tb6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonCreateCR;
        private System.Windows.Forms.TextBox textBoxCANcr;
        private MetroFramework.Controls.MetroGrid dgvCR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxPBC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCANC;
        private MetroFramework.Controls.MetroComboBox CTC;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Controls.MetroComboBox CSC;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Button buttonCREATEC;
        private MetroFramework.Controls.MetroGrid dgvC;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.DateTimePicker timePortionDateTimePicker;
        private System.Windows.Forms.DateTimePicker datePortionDateTimePicker;
        private MetroFramework.Controls.MetroToggle togDEL;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxMN;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCANBR;
        private System.Windows.Forms.Button buttonADDBR;
        private System.Windows.Forms.TextBox textBoxBR;
        private MetroFramework.Controls.MetroGrid dgvBR;
        private MetroFramework.Controls.MetroComboBox metroComboBoxBRCBC;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxCANBC;
        private MetroFramework.Controls.MetroGrid dgvBC;
        private System.Windows.Forms.Button buttonADDBC;
        private MetroFramework.Controls.MetroComboBox metroComboBoxBDSN;
        private System.Windows.Forms.Label label11;
        private MetroFramework.Controls.MetroComboBox metroComboBoxBRC;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxSCANBR;
        private System.Windows.Forms.Button buttonADDBRC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxECANBR;
        private MetroFramework.Controls.MetroGrid dgvBCR;
        private System.Windows.Forms.DateTimePicker dateTimePickerTT;
        private System.Windows.Forms.DateTimePicker dateTimePickerT;
        private System.Windows.Forms.Label label16;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPNT;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxTAT;
        private System.Windows.Forms.Label label19;
        private MetroFramework.Controls.MetroComboBox metroComboBoxCANT;
        private System.Windows.Forms.Button buttonADDT;
        private MetroFramework.Controls.MetroGrid dgvT;
        private System.Windows.Forms.Button delBCR;
        private System.Windows.Forms.Button delT;
        private System.Windows.Forms.Button delBC;
        private System.Windows.Forms.Button delBR;
        private System.Windows.Forms.Button delCR;
        private System.Windows.Forms.Button delC;
        private System.Windows.Forms.Button buttonSaveCR;
        private System.Windows.Forms.Button buttonSaveC;
        private System.Windows.Forms.Button buttonSaveBR;
        private System.Windows.Forms.Button buttonSaveBC;
        private System.Windows.Forms.Button buttonSaveBRC;
        private System.Windows.Forms.Button buttonSaveT;
        private System.Windows.Forms.Button qm;
        private System.Windows.Forms.Button exportT;
        private System.Windows.Forms.Button exportCR;
        private System.Windows.Forms.Button exportC;
        private System.Windows.Forms.Button exportBCR;
        private System.Windows.Forms.Button exportBC;
        private System.Windows.Forms.Button exportBR;
    }
}