Changelogs 6/25/19
______________________________________________________
- Added Clipboard Cell feature.
- Added configuration checker.
