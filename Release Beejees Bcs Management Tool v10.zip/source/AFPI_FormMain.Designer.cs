﻿namespace AFPI_Beejees_db
{
    partial class MainProg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainProg));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle841 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle842 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle843 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle844 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle845 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle846 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle847 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle848 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle849 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle850 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle851 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle852 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle853 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle854 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle855 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle856 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle857 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle858 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle859 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle860 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle861 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle862 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle863 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle864 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle865 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle866 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle867 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle868 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle869 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle870 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle871 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle872 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle873 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle874 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle875 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle876 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle838 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle839 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle840 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle877 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle878 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle879 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle880 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle881 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle882 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle883 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle884 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle885 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle886 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle887 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle888 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle889 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle890 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle891 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle892 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle893 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle894 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle895 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle896 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle897 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle898 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle899 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle900 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle901 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle902 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle903 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle904 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle905 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle906 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle907 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle908 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle909 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle910 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle911 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle912 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle913 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle914 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle915 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle916 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle917 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle918 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle919 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle920 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle921 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle922 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle923 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle924 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle925 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle926 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle927 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle928 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle929 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle930 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabMASTER = new MetroFramework.Controls.MetroTabControl();
            this.tb1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonexpmerc = new System.Windows.Forms.Button();
            this.panelMerc = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_CreatePsname = new System.Windows.Forms.TextBox();
            this.PB_PNCHECKER = new System.Windows.Forms.PictureBox();
            this.textBoxCreatePname = new System.Windows.Forms.TextBox();
            this.PB_PIDCHECKER = new System.Windows.Forms.PictureBox();
            this.buttonCreate = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.textBoxCreate_PID = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvMERC = new MetroFramework.Controls.MetroGrid();
            this.panelPlaceHolderMerc = new System.Windows.Forms.Panel();
            this.comboBoxMerchantList = new MetroFramework.Controls.MetroComboBox();
            this.buttonDELMERC = new System.Windows.Forms.Button();
            this.textBoxEdit_Pname = new System.Windows.Forms.TextBox();
            this.textBox_PSname = new System.Windows.Forms.TextBox();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonexpbp = new System.Windows.Forms.Button();
            this.buttonSaveBP = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.buttonBPdel = new System.Windows.Forms.Button();
            this.dataGridViewBP = new MetroFramework.Controls.MetroGrid();
            this.label34 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxPNBP2 = new System.Windows.Forms.TextBox();
            this.buttonUpdateBP = new System.Windows.Forms.Button();
            this.textBoxPNBP = new System.Windows.Forms.TextBox();
            this.tb3 = new System.Windows.Forms.TabPage();
            this.panel = new System.Windows.Forms.Panel();
            this.buttonexpbf = new System.Windows.Forms.Button();
            this.label275 = new System.Windows.Forms.Label();
            this.panelBF = new System.Windows.Forms.Panel();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.textBoxNewPIDBF = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxAppend = new System.Windows.Forms.TextBox();
            this.textBoxFleetsName = new System.Windows.Forms.TextBox();
            this.label20d = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.comboBoxBF = new MetroFramework.Controls.MetroComboBox();
            this.buttonSAVE_Fleets = new System.Windows.Forms.Button();
            this.comboBoxMercBP = new MetroFramework.Controls.MetroComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.buttonBFdel = new System.Windows.Forms.Button();
            this.dataGridViewFleets = new MetroFramework.Controls.MetroGrid();
            this.label36 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonBF = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.tb4 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonterminalexp = new System.Windows.Forms.Button();
            this.panelTerminal2 = new System.Windows.Forms.Panel();
            this.metroComboBoxFleet = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxTType = new MetroFramework.Controls.MetroComboBox();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.textBoxNewTID = new System.Windows.Forms.TextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.buttonST = new System.Windows.Forms.Button();
            this.label137 = new System.Windows.Forms.Label();
            this.buttonDelT = new System.Windows.Forms.Button();
            this.metroGridFleets = new MetroFramework.Controls.MetroGrid();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBoxTermT = new MetroFramework.Controls.MetroComboBox();
            this.textBoxFname = new MetroFramework.Controls.MetroComboBox();
            this.comboBoxBJFID = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.buttonTerminalUP = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_TermID = new System.Windows.Forms.TextBox();
            this.tb5 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelDBR = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.checkBoxNDBR = new System.Windows.Forms.CheckBox();
            this.label145 = new System.Windows.Forms.Label();
            this.radioButtonNdcDBR = new System.Windows.Forms.RadioButton();
            this.radioButtonNddDBR = new System.Windows.Forms.RadioButton();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.textBoxNRID_DBR = new System.Windows.Forms.TextBox();
            this.textBoxNRSN_DBR = new System.Windows.Forms.TextBox();
            this.textBoxRLN_DBR = new System.Windows.Forms.TextBox();
            this.buttonexpdbr = new System.Windows.Forms.Button();
            this.buttonDELDBR = new System.Windows.Forms.Button();
            this.buttonSAVEDBR = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.buttonDBR_Create = new System.Windows.Forms.Button();
            this.dgvDBR = new MetroFramework.Controls.MetroGrid();
            this.checkBoxDBR = new System.Windows.Forms.CheckBox();
            this.label48 = new System.Windows.Forms.Label();
            this.radioButton_cred = new System.Windows.Forms.RadioButton();
            this.radioButton_debit = new System.Windows.Forms.RadioButton();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBoxBDR_RID = new System.Windows.Forms.TextBox();
            this.textBoxDBR_RSN = new System.Windows.Forms.TextBox();
            this.textBoxDBR_RLN = new System.Windows.Forms.TextBox();
            this.tb6 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panelDFT = new System.Windows.Forms.Panel();
            this.checkBoxPro_DFT2 = new System.Windows.Forms.CheckBox();
            this.checkBoxAcc_DFT2 = new System.Windows.Forms.CheckBox();
            this.radioButtonNDOWN_DFT = new System.Windows.Forms.RadioButton();
            this.numericUpDownNRA_DFT = new System.Windows.Forms.NumericUpDown();
            this.label112 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.metroDateTimeNTO_DFT = new MetroFramework.Controls.MetroDateTime();
            this.label183 = new System.Windows.Forms.Label();
            this.metroDateTimeNED_DFT = new MetroFramework.Controls.MetroDateTime();
            this.checkBoxA_DFT = new System.Windows.Forms.CheckBox();
            this.label184 = new System.Windows.Forms.Label();
            this.radioButtonNUP_DFT = new System.Windows.Forms.RadioButton();
            this.radioButtonExactNDFT = new System.Windows.Forms.RadioButton();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.textBoxNFTID_DFT = new System.Windows.Forms.TextBox();
            this.textBoxND_DFT = new System.Windows.Forms.TextBox();
            this.buttonexpdft = new System.Windows.Forms.Button();
            this.buttonSaveDFT = new System.Windows.Forms.Button();
            this.radioButtonDFT_D = new System.Windows.Forms.RadioButton();
            this.textBoxDFT_RA = new System.Windows.Forms.NumericUpDown();
            this.buttonDELDFT = new System.Windows.Forms.Button();
            this.label94 = new System.Windows.Forms.Label();
            this.dgvDFT = new MetroFramework.Controls.MetroGrid();
            this.label92 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.buttonDFT_Create = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.metroDateTimeDFT_T = new MetroFramework.Controls.MetroDateTime();
            this.label54 = new System.Windows.Forms.Label();
            this.metroDateTimeDFT_F = new MetroFramework.Controls.MetroDateTime();
            this.checkBoxDFT_ACT = new System.Windows.Forms.CheckBox();
            this.label50 = new System.Windows.Forms.Label();
            this.radioButtonDFT_U = new System.Windows.Forms.RadioButton();
            this.radioButtonDFT_E = new System.Windows.Forms.RadioButton();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.textBoxDFT_FTB = new System.Windows.Forms.TextBox();
            this.textBoxDFT_DISC = new System.Windows.Forms.TextBox();
            this.checkBoxPro_DFT = new System.Windows.Forms.CheckBox();
            this.checkBoxAcc_DFT = new System.Windows.Forms.CheckBox();
            this.tb7 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.buttonexpdbft = new System.Windows.Forms.Button();
            this.panelDBFT = new System.Windows.Forms.Panel();
            this.checkBoxPro_DBFT2 = new System.Windows.Forms.CheckBox();
            this.checkBoxAcc_DBFT2 = new System.Windows.Forms.CheckBox();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.textBoxNBFD_DBFT = new System.Windows.Forms.TextBox();
            this.label192 = new System.Windows.Forms.Label();
            this.metroDateTimeNTO_DBFT = new MetroFramework.Controls.MetroDateTime();
            this.label193 = new System.Windows.Forms.Label();
            this.metroDateTimeNED_DBFT = new MetroFramework.Controls.MetroDateTime();
            this.checkBoxA_DBFT = new System.Windows.Forms.CheckBox();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.textBoxNFTID_DBFT = new System.Windows.Forms.TextBox();
            this.textBoxNFA_DBFT = new System.Windows.Forms.TextBox();
            this.checkBoxPro_DBFT = new System.Windows.Forms.CheckBox();
            this.checkBoxAcc_DBFT = new System.Windows.Forms.CheckBox();
            this.buttonSAVE_DBFT = new System.Windows.Forms.Button();
            this.buttonDELDBFT = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.dgvDBFT = new MetroFramework.Controls.MetroGrid();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.buttonDBFT_Create = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxDBFT_BFD = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.metroDateTimeDBFT_T = new MetroFramework.Controls.MetroDateTime();
            this.label59 = new System.Windows.Forms.Label();
            this.metroDateTimeDBFT_F = new MetroFramework.Controls.MetroDateTime();
            this.checkBoxDBFT_A = new System.Windows.Forms.CheckBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.textBoxDBFT_FTI = new System.Windows.Forms.TextBox();
            this.textBoxDBFT_FA = new System.Windows.Forms.TextBox();
            this.tb8 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.buttonexprbf = new System.Windows.Forms.Button();
            this.panelRBF = new System.Windows.Forms.Panel();
            this.label246 = new System.Windows.Forms.Label();
            this.label247 = new System.Windows.Forms.Label();
            this.metroComboBoxRBF_BFI2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxRBF_RID2 = new MetroFramework.Controls.MetroComboBox();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.buttonSAVERBF = new System.Windows.Forms.Button();
            this.buttonDELRBF = new System.Windows.Forms.Button();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.dgvRBF = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxRBF_BFI = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxRBF_RID = new MetroFramework.Controls.MetroComboBox();
            this.buttonRBF_Gen = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.tb9 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.buttonexprdf = new System.Windows.Forms.Button();
            this.panelRDF = new System.Windows.Forms.Panel();
            this.label250 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.metroComboBoxRDBF_DID2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxRDBF_RID2 = new MetroFramework.Controls.MetroComboBox();
            this.label252 = new System.Windows.Forms.Label();
            this.label253 = new System.Windows.Forms.Label();
            this.buttonSAVERDF = new System.Windows.Forms.Button();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.buttonDELRDF = new System.Windows.Forms.Button();
            this.dgvRDF = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxRDBF_DID = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxRDBF_RID = new MetroFramework.Controls.MetroComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.buttonRDBF_Gen = new System.Windows.Forms.Button();
            this.tb10 = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.buttonexppr = new System.Windows.Forms.Button();
            this.panelPR = new System.Windows.Forms.Panel();
            this.label254 = new System.Windows.Forms.Label();
            this.label255 = new System.Windows.Forms.Label();
            this.metroComboBoxPR_RID2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPR_PID2 = new MetroFramework.Controls.MetroComboBox();
            this.label256 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.buttonSavePR = new System.Windows.Forms.Button();
            this.buttonDELPR = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.dgvPR = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxPR_RID = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPR_PID = new MetroFramework.Controls.MetroComboBox();
            this.buttonPR_Gen = new System.Windows.Forms.Button();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.tb11 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.buttonexppdb = new System.Windows.Forms.Button();
            this.panelPDB = new System.Windows.Forms.Panel();
            this.label258 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.metroComboBoxPDB_BID2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPDB_PID2 = new MetroFramework.Controls.MetroComboBox();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.buttonSAVEPDB = new System.Windows.Forms.Button();
            this.buttonDELPDB = new System.Windows.Forms.Button();
            this.dgvPDB = new MetroFramework.Controls.MetroGrid();
            this.label35 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.metroComboBoxPDB_BID = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPDB_PID = new MetroFramework.Controls.MetroComboBox();
            this.buttonPDB_Gen = new System.Windows.Forms.Button();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.tb12 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panelPP = new System.Windows.Forms.Panel();
            this.labelSSVAL2 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.metroComboBoxPP_SPI2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPP_PID2 = new MetroFramework.Controls.MetroComboBox();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.buttonexppp = new System.Windows.Forms.Button();
            this.labelSSVAL = new System.Windows.Forms.Label();
            this.buttonsavePP = new System.Windows.Forms.Button();
            this.buttonDELPP = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.dgvPP = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxPP_SPI = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxPP_PID = new MetroFramework.Controls.MetroComboBox();
            this.buttonGenPP = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.tb13 = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panelSP = new System.Windows.Forms.Panel();
            this.metroComboBoxSP_T2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBoxSP_P2 = new MetroFramework.Controls.MetroComboBox();
            this.label205 = new System.Windows.Forms.Label();
            this.textBoxSP_V2 = new System.Windows.Forms.TextBox();
            this.label206 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.buttonRemoveSP = new System.Windows.Forms.Button();
            this.buttonexpsp = new System.Windows.Forms.Button();
            this.buttonSaveSP = new System.Windows.Forms.Button();
            this.buttonDELSP = new System.Windows.Forms.Button();
            this.metroComboBoxSP_P = new MetroFramework.Controls.MetroComboBox();
            this.buttonSP_Gen = new System.Windows.Forms.Button();
            this.label101 = new System.Windows.Forms.Label();
            this.dgvSP = new MetroFramework.Controls.MetroGrid();
            this.label102 = new System.Windows.Forms.Label();
            this.metroComboBoxSP_T = new MetroFramework.Controls.MetroComboBox();
            this.textBoxSP_V = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.tb14 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panelDBIF = new System.Windows.Forms.Panel();
            this.checkBoxOneDBIF = new System.Windows.Forms.CheckBox();
            this.cbxNewFTIDDBIF = new MetroFramework.Controls.MetroComboBox();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.textBoxNIFD_DBIF = new System.Windows.Forms.TextBox();
            this.label201 = new System.Windows.Forms.Label();
            this.textBoxNSDDBIF = new System.Windows.Forms.TextBox();
            this.textBoxNIF_DBIF = new System.Windows.Forms.TextBox();
            this.label202 = new System.Windows.Forms.Label();
            this.buttonexpdbif = new System.Windows.Forms.Button();
            this.buttonSAVE_DBIF = new System.Windows.Forms.Button();
            this.buttonDELDBIF = new System.Windows.Forms.Button();
            this.DBIF_ftid = new MetroFramework.Controls.MetroComboBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.buttonCreate_DBIF = new System.Windows.Forms.Button();
            this.label104 = new System.Windows.Forms.Label();
            this.DBIF_ifd = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.DBIF_sd = new System.Windows.Forms.TextBox();
            this.DBIF_ifa = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.dgvDBIF = new MetroFramework.Controls.MetroGrid();
            this.tb15 = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.buttonexpua = new System.Windows.Forms.Button();
            this.panelUA = new System.Windows.Forms.Panel();
            this.label226 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.metroDateTimeEDUA2second = new MetroFramework.Controls.MetroDateTime();
            this.label236 = new System.Windows.Forms.Label();
            this.metroDateTimeEDUAsecond = new MetroFramework.Controls.MetroDateTime();
            this.label237 = new System.Windows.Forms.Label();
            this.textBox_UA_SN2 = new System.Windows.Forms.TextBox();
            this.label238 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.textBox_UA_LN2 = new System.Windows.Forms.TextBox();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.textBoxUA_CID2 = new System.Windows.Forms.TextBox();
            this.metroComboBoxUA_MN2 = new MetroFramework.Controls.MetroComboBox();
            this.label242 = new System.Windows.Forms.Label();
            this.label243 = new System.Windows.Forms.Label();
            this.label244 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.textBox_UA_UID2 = new System.Windows.Forms.TextBox();
            this.buttonSaveUA = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.buttonDELUA = new System.Windows.Forms.Button();
            this.buttonUP_UA = new System.Windows.Forms.Button();
            this.label121 = new System.Windows.Forms.Label();
            this.metroDateTimeEDUA2 = new MetroFramework.Controls.MetroDateTime();
            this.label122 = new System.Windows.Forms.Label();
            this.dgvUA = new MetroFramework.Controls.MetroGrid();
            this.metroDateTimeEDUA = new MetroFramework.Controls.MetroDateTime();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.textBox_UA_SN = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.textBox_UA_LN = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.textBoxUA_CID = new System.Windows.Forms.TextBox();
            this.metroComboBoxUA_MN = new MetroFramework.Controls.MetroComboBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox_UA_UID = new System.Windows.Forms.TextBox();
            this.tb16 = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.buttonexpuc = new System.Windows.Forms.Button();
            this.panelUC = new System.Windows.Forms.Panel();
            this.label228 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.radioButtonDISPATCHER2 = new System.Windows.Forms.RadioButton();
            this.radioButtonDRIVER2 = new System.Windows.Forms.RadioButton();
            this.label230 = new System.Windows.Forms.Label();
            this.metroComboBoxUC_UN2 = new MetroFramework.Controls.MetroComboBox();
            this.label231 = new System.Windows.Forms.Label();
            this.metroDateTimeUCED2second = new MetroFramework.Controls.MetroDateTime();
            this.label232 = new System.Windows.Forms.Label();
            this.metroDateTimeUCEDsecond = new MetroFramework.Controls.MetroDateTime();
            this.label233 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.textBoxUC_UID2 = new System.Windows.Forms.TextBox();
            this.buttonSaveUC = new System.Windows.Forms.Button();
            this.labelPID = new System.Windows.Forms.Label();
            this.metroComboBoxVID = new MetroFramework.Controls.MetroComboBox();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.radioButtonDISPATCHER = new System.Windows.Forms.RadioButton();
            this.radioButtonDRIVER = new System.Windows.Forms.RadioButton();
            this.buttonUC_DEL = new System.Windows.Forms.Button();
            this.buttonUCADD = new System.Windows.Forms.Button();
            this.dgvUC = new MetroFramework.Controls.MetroGrid();
            this.label125 = new System.Windows.Forms.Label();
            this.metroComboBoxUC_UN = new MetroFramework.Controls.MetroComboBox();
            this.label126 = new System.Windows.Forms.Label();
            this.metroDateTimeUCED2 = new MetroFramework.Controls.MetroDateTime();
            this.label127 = new System.Windows.Forms.Label();
            this.metroDateTimeUCED = new MetroFramework.Controls.MetroDateTime();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.textBoxUC_UID = new System.Windows.Forms.TextBox();
            this.tb17 = new System.Windows.Forms.TabPage();
            this.panel17 = new System.Windows.Forms.Panel();
            this.textBoxINS = new MetroFramework.Controls.MetroComboBox();
            this.buttonOpenINS = new System.Windows.Forms.Button();
            this.labelINSfile = new System.Windows.Forms.Label();
            this.buttonPlayIns = new System.Windows.Forms.Button();
            this.label155 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.dgvINSERT = new MetroFramework.Controls.MetroGrid();
            this.label153 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.tb18 = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label162 = new System.Windows.Forms.Label();
            this.textBoxSETUP = new System.Windows.Forms.TextBox();
            this.textBoxVALUP = new System.Windows.Forms.TextBox();
            this.label157 = new System.Windows.Forms.Label();
            this.buttonUp = new System.Windows.Forms.Button();
            this.label159 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.mcbxColUP = new MetroFramework.Controls.MetroComboBox();
            this.mcbxTB = new MetroFramework.Controls.MetroComboBox();
            this.label158 = new System.Windows.Forms.Label();
            this.dgvUPDATE = new MetroFramework.Controls.MetroGrid();
            this.label160 = new System.Windows.Forms.Label();
            this.tb19 = new System.Windows.Forms.TabPage();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label161 = new System.Windows.Forms.Label();
            this.mcbxVALDEL = new System.Windows.Forms.TextBox();
            this.label164 = new System.Windows.Forms.Label();
            this.mcbxCOLDEL = new MetroFramework.Controls.MetroComboBox();
            this.mcbxTBDEL = new MetroFramework.Controls.MetroComboBox();
            this.buttonDEL = new System.Windows.Forms.Button();
            this.label165 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.dgvDEL = new MetroFramework.Controls.MetroGrid();
            this.tb20 = new System.Windows.Forms.TabPage();
            this.panel20 = new System.Windows.Forms.Panel();
            this.buttonexpbjs = new System.Windows.Forms.Button();
            this.panelBJS = new System.Windows.Forms.Panel();
            this.label200 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.DTBSTO2 = new MetroFramework.Controls.MetroDateTime();
            this.DTBSFROM2 = new MetroFramework.Controls.MetroDateTime();
            this.label204 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.SIBS2 = new System.Windows.Forms.TextBox();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.LNBS2 = new System.Windows.Forms.TextBox();
            this.label211 = new System.Windows.Forms.Label();
            this.VIDBS2 = new System.Windows.Forms.TextBox();
            this.TIDBS2 = new MetroFramework.Controls.MetroComboBox();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.buttonSaveBJS = new System.Windows.Forms.Button();
            this.buttonDELBS = new System.Windows.Forms.Button();
            this.buttonUPBS = new System.Windows.Forms.Button();
            this.dgvBS = new MetroFramework.Controls.MetroGrid();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.DTBSTO = new MetroFramework.Controls.MetroDateTime();
            this.DTBSFROM = new MetroFramework.Controls.MetroDateTime();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.SIBS = new System.Windows.Forms.TextBox();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.LNBS = new System.Windows.Forms.TextBox();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.VIDBS = new System.Windows.Forms.TextBox();
            this.TIDBS = new MetroFramework.Controls.MetroComboBox();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.tb21 = new System.Windows.Forms.TabPage();
            this.panel21 = new System.Windows.Forms.Panel();
            this.labelAlert = new System.Windows.Forms.Label();
            this.dgvQUERY = new MetroFramework.Controls.MetroGrid();
            this.button3 = new System.Windows.Forms.Button();
            this.label180 = new System.Windows.Forms.Label();
            this.textBoxQuery = new System.Windows.Forms.TextBox();
            this.buttonQuery = new System.Windows.Forms.Button();
            this.labelQuery = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.tb22 = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panelSFF = new System.Windows.Forms.Panel();
            this.SFFPro2 = new System.Windows.Forms.CheckBox();
            this.SFFacc2 = new System.Windows.Forms.CheckBox();
            this.checkBoxSFF_A2 = new System.Windows.Forms.CheckBox();
            this.label214 = new System.Windows.Forms.Label();
            this.label215 = new System.Windows.Forms.Label();
            this.textBoxSFF_FA2 = new System.Windows.Forms.TextBox();
            this.label216 = new System.Windows.Forms.Label();
            this.label217 = new System.Windows.Forms.Label();
            this.metroDateTimeSFF_TO2 = new MetroFramework.Controls.MetroDateTime();
            this.metroDateTimeSFF_FROM2 = new MetroFramework.Controls.MetroDateTime();
            this.label218 = new System.Windows.Forms.Label();
            this.label219 = new System.Windows.Forms.Label();
            this.textBoxSFF_FTID2 = new System.Windows.Forms.TextBox();
            this.SFFacc = new System.Windows.Forms.CheckBox();
            this.SFFPro = new System.Windows.Forms.CheckBox();
            this.buttonexpsff = new System.Windows.Forms.Button();
            this.buttonSaveSFF = new System.Windows.Forms.Button();
            this.buttonSFFDEL = new System.Windows.Forms.Button();
            this.dgvSFF = new MetroFramework.Controls.MetroGrid();
            this.checkBoxSFF_A = new System.Windows.Forms.CheckBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.textBoxSFF_FA = new System.Windows.Forms.TextBox();
            this.buttonSFFADD = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.metroDateTimeSFF_TO = new MetroFramework.Controls.MetroDateTime();
            this.metroDateTimeSFF_FROM = new MetroFramework.Controls.MetroDateTime();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.textBoxSFF_FTID = new System.Windows.Forms.TextBox();
            this.tb23 = new System.Windows.Forms.TabPage();
            this.panel23 = new System.Windows.Forms.Panel();
            this.buttonexpdbcp = new System.Windows.Forms.Button();
            this.panelDBCP = new System.Windows.Forms.Panel();
            this.metroComboBoxDBCP_DFTID2 = new MetroFramework.Controls.MetroComboBox();
            this.label220 = new System.Windows.Forms.Label();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.textBoxDBCP_CPID2 = new System.Windows.Forms.TextBox();
            this.label224 = new System.Windows.Forms.Label();
            this.label225 = new System.Windows.Forms.Label();
            this.textBoxDBCP_CPN2 = new System.Windows.Forms.TextBox();
            this.buttonSaveDBCP = new System.Windows.Forms.Button();
            this.buttonDBCPDEL = new System.Windows.Forms.Button();
            this.dgvDBCP = new MetroFramework.Controls.MetroGrid();
            this.buttonDBCPADD = new System.Windows.Forms.Button();
            this.metroComboBoxDBCP_DFTID = new MetroFramework.Controls.MetroComboBox();
            this.label103 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.textBoxDBCP_CPID = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.textBoxDBCP_CPN = new System.Windows.Forms.TextBox();
            this.tb24 = new System.Windows.Forms.TabPage();
            this.p = new System.Windows.Forms.Panel();
            this.dgvSEARCH = new MetroFramework.Controls.MetroGrid();
            this.metroComboBoxSearchParam = new MetroFramework.Controls.MetroComboBox();
            this.label267 = new System.Windows.Forms.Label();
            this.panelUID = new System.Windows.Forms.Panel();
            this.buttonUID = new System.Windows.Forms.Button();
            this.label274 = new System.Windows.Forms.Label();
            this.textBoxUID = new System.Windows.Forms.TextBox();
            this.panelTerminalID = new System.Windows.Forms.Panel();
            this.buttonSearchTerminal = new System.Windows.Forms.Button();
            this.label269 = new System.Windows.Forms.Label();
            this.txtBxTerminalID = new System.Windows.Forms.TextBox();
            this.panelProfileID = new System.Windows.Forms.Panel();
            this.label273 = new System.Windows.Forms.Label();
            this.label272 = new System.Windows.Forms.Label();
            this.label271 = new System.Windows.Forms.Label();
            this.metroComboBoxParam = new MetroFramework.Controls.MetroComboBox();
            this.label270 = new System.Windows.Forms.Label();
            this.label268 = new System.Windows.Forms.Label();
            this.textBoxVal = new System.Windows.Forms.TextBox();
            this.buttonProfileID = new System.Windows.Forms.Button();
            this.label266 = new System.Windows.Forms.Label();
            this.textBoxProfileID = new System.Windows.Forms.TextBox();
            this.tb25 = new System.Windows.Forms.TabPage();
            this.panel24 = new System.Windows.Forms.Panel();
            this.buttonexppd = new System.Windows.Forms.Button();
            this.panelPD = new System.Windows.Forms.Panel();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.mcbxFTID2 = new MetroFramework.Controls.MetroComboBox();
            this.mcbxProfiles2 = new MetroFramework.Controls.MetroComboBox();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.buttonSAVEPD = new System.Windows.Forms.Button();
            this.buttonDELPD = new System.Windows.Forms.Button();
            this.dgvPD = new MetroFramework.Controls.MetroGrid();
            this.label280 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.mcbxFTID = new MetroFramework.Controls.MetroComboBox();
            this.mcbxProfiles = new MetroFramework.Controls.MetroComboBox();
            this.buttonGENPD = new System.Windows.Forms.Button();
            this.label282 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.tb26 = new System.Windows.Forms.TabPage();
            this.panel25 = new System.Windows.Forms.Panel();
            this.efx = new System.Windows.Forms.Label();
            this.buttonPauseResume = new System.Windows.Forms.Button();
            this.pb = new System.Windows.Forms.PictureBox();
            this.labelCHECK = new System.Windows.Forms.Label();
            this.startInitial = new System.Windows.Forms.Button();
            this.comboCHECK = new MetroFramework.Controls.MetroComboBox();
            this.label284 = new System.Windows.Forms.Label();
            this.dgvCC = new MetroFramework.Controls.MetroGrid();
            this.tb27 = new System.Windows.Forms.TabPage();
            this.panel26 = new System.Windows.Forms.Panel();
            this.buttonMove = new System.Windows.Forms.Button();
            this.moveTo = new MetroFramework.Controls.MetroComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.selRoute = new MetroFramework.Controls.MetroComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tb28 = new System.Windows.Forms.TabPage();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label123 = new System.Windows.Forms.Label();
            this.PTTN = new System.Windows.Forms.TextBox();
            this.PTT = new System.Windows.Forms.TextBox();
            this.label291 = new System.Windows.Forms.Label();
            this.label289 = new System.Windows.Forms.Label();
            this.label290 = new System.Windows.Forms.Label();
            this.PTDT2 = new MetroFramework.Controls.MetroDateTime();
            this.PTDT = new MetroFramework.Controls.MetroDateTime();
            this.PTExp = new System.Windows.Forms.Button();
            this.PTDel = new System.Windows.Forms.Button();
            this.dgvPT = new MetroFramework.Controls.MetroGrid();
            this.PTSave = new System.Windows.Forms.Button();
            this.PTAdd = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.PTTID = new System.Windows.Forms.TextBox();
            this.PTTT = new MetroFramework.Controls.MetroComboBox();
            this.label288 = new System.Windows.Forms.Label();
            this.tb29 = new System.Windows.Forms.TabPage();
            this.panel28 = new System.Windows.Forms.Panel();
            this.labelTT = new System.Windows.Forms.Label();
            this.labelList = new System.Windows.Forms.Label();
            this.labelList3 = new System.Windows.Forms.Label();
            this.buttonPPE = new System.Windows.Forms.Button();
            this.buttonPPDEL = new System.Windows.Forms.Button();
            this.dgvPPT = new MetroFramework.Controls.MetroGrid();
            this.PPsave = new System.Windows.Forms.Button();
            this.PPadd = new System.Windows.Forms.Button();
            this.label287 = new System.Windows.Forms.Label();
            this.PPVERtxt = new System.Windows.Forms.TextBox();
            this.PPTIDcbx = new MetroFramework.Controls.MetroComboBox();
            this.label286 = new System.Windows.Forms.Label();
            this.PPPcbx = new MetroFramework.Controls.MetroComboBox();
            this.label285 = new System.Windows.Forms.Label();
            this.tb30 = new System.Windows.Forms.TabPage();
            this.panel29 = new System.Windows.Forms.Panel();
            this.SBFTexp = new System.Windows.Forms.Button();
            this.SBFTDel = new System.Windows.Forms.Button();
            this.dgvSBFT = new MetroFramework.Controls.MetroGrid();
            this.SBFTSave = new System.Windows.Forms.Button();
            this.SBFTAdd = new System.Windows.Forms.Button();
            this.SBFT_Pro = new System.Windows.Forms.CheckBox();
            this.SBFT_Acc = new System.Windows.Forms.CheckBox();
            this.label292 = new System.Windows.Forms.Label();
            this.SBFT_ET = new MetroFramework.Controls.MetroDateTime();
            this.label293 = new System.Windows.Forms.Label();
            this.SBFT_EF = new MetroFramework.Controls.MetroDateTime();
            this.SBFT_Act = new System.Windows.Forms.CheckBox();
            this.label294 = new System.Windows.Forms.Label();
            this.label295 = new System.Windows.Forms.Label();
            this.SBFT_Ftid = new System.Windows.Forms.TextBox();
            this.SBFT_Fm = new System.Windows.Forms.TextBox();
            this.tb31 = new System.Windows.Forms.TabPage();
            this.panel30 = new System.Windows.Forms.Panel();
            this.PSBExp = new System.Windows.Forms.Button();
            this.PSBsave = new System.Windows.Forms.Button();
            this.PSBDel = new System.Windows.Forms.Button();
            this.dgvPSB = new MetroFramework.Controls.MetroGrid();
            this.PSBgen = new System.Windows.Forms.Button();
            this.PSBsid = new MetroFramework.Controls.MetroComboBox();
            this.PSBpn = new MetroFramework.Controls.MetroComboBox();
            this.label296 = new System.Windows.Forms.Label();
            this.label297 = new System.Windows.Forms.Label();
            this.tb32 = new System.Windows.Forms.TabPage();
            this.panel31 = new System.Windows.Forms.Panel();
            this.RSFExp = new System.Windows.Forms.Button();
            this.RSFsave = new System.Windows.Forms.Button();
            this.RSFDel = new System.Windows.Forms.Button();
            this.dgvRSF = new MetroFramework.Controls.MetroGrid();
            this.RSFGen = new System.Windows.Forms.Button();
            this.RSFsid = new MetroFramework.Controls.MetroComboBox();
            this.RSFrn = new MetroFramework.Controls.MetroComboBox();
            this.label298 = new System.Windows.Forms.Label();
            this.label299 = new System.Windows.Forms.Label();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.buttonDFRT = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.buttonSP = new System.Windows.Forms.Button();
            this.buttonDBIF = new System.Windows.Forms.Button();
            this.buttonDBFRT = new System.Windows.Forms.Button();
            this.buttonDBRm = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonBP = new System.Windows.Forms.Button();
            this.buttonm = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.buttonRBF = new System.Windows.Forms.Button();
            this.buttonAMENU = new System.Windows.Forms.Button();
            this.buttonRDF = new System.Windows.Forms.Button();
            this.logo = new System.Windows.Forms.PictureBox();
            this.panelMenu2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonPD = new System.Windows.Forms.Button();
            this.buttonPP = new System.Windows.Forms.Button();
            this.buttonPR = new System.Windows.Forms.Button();
            this.buttonpdb = new System.Windows.Forms.Button();
            this.buttonMoveR = new System.Windows.Forms.Button();
            this.buttonConfigChecker = new System.Windows.Forms.Button();
            this.buttonEXIT = new System.Windows.Forms.Button();
            this.buttonCMENU = new System.Windows.Forms.Button();
            this.titleLB = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.buttonqsl = new System.Windows.Forms.Button();
            this.buttonUMENU = new System.Windows.Forms.Button();
            this.togDEL = new MetroFramework.Controls.MetroToggle();
            this.label4 = new System.Windows.Forms.Label();
            this.panelMenu3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonUC = new System.Windows.Forms.Button();
            this.buttonUA = new System.Windows.Forms.Button();
            this.panelMenu4 = new System.Windows.Forms.Panel();
            this.SearchQuery = new System.Windows.Forms.Button();
            this.QueryRunner = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.timerCHECK = new System.Windows.Forms.Timer(this.components);
            this.qm = new System.Windows.Forms.Button();
            this.label300 = new System.Windows.Forms.Label();
            this.label301 = new System.Windows.Forms.Label();
            this.tabMASTER.SuspendLayout();
            this.tb1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelMerc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PNCHECKER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PIDCHECKER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMERC)).BeginInit();
            this.panelPlaceHolderMerc.SuspendLayout();
            this.tb2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBP)).BeginInit();
            this.tb3.SuspendLayout();
            this.panel.SuspendLayout();
            this.panelBF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFleets)).BeginInit();
            this.tb4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panelTerminal2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGridFleets)).BeginInit();
            this.tb5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panelDBR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBR)).BeginInit();
            this.tb6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panelDFT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNRA_DFT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxDFT_RA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDFT)).BeginInit();
            this.tb7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panelDBFT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBFT)).BeginInit();
            this.tb8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelRBF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRBF)).BeginInit();
            this.tb9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panelRDF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDF)).BeginInit();
            this.tb10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panelPR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPR)).BeginInit();
            this.tb11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panelPDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPDB)).BeginInit();
            this.tb12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panelPP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPP)).BeginInit();
            this.tb13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panelSP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSP)).BeginInit();
            this.tb14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panelDBIF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBIF)).BeginInit();
            this.tb15.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panelUA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUA)).BeginInit();
            this.tb16.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panelUC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUC)).BeginInit();
            this.tb17.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvINSERT)).BeginInit();
            this.tb18.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUPDATE)).BeginInit();
            this.tb19.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDEL)).BeginInit();
            this.tb20.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panelBJS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBS)).BeginInit();
            this.tb21.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQUERY)).BeginInit();
            this.tb22.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panelSFF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSFF)).BeginInit();
            this.tb23.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panelDBCP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBCP)).BeginInit();
            this.tb24.SuspendLayout();
            this.p.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSEARCH)).BeginInit();
            this.panelUID.SuspendLayout();
            this.panelTerminalID.SuspendLayout();
            this.panelProfileID.SuspendLayout();
            this.tb25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panelPD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPD)).BeginInit();
            this.tb26.SuspendLayout();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCC)).BeginInit();
            this.tb27.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tb28.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).BeginInit();
            this.tb29.SuspendLayout();
            this.panel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPPT)).BeginInit();
            this.tb30.SuspendLayout();
            this.panel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSBFT)).BeginInit();
            this.tb31.SuspendLayout();
            this.panel30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSB)).BeginInit();
            this.tb32.SuspendLayout();
            this.panel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSF)).BeginInit();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.panelMenu2.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panelMenu3.SuspendLayout();
            this.panelMenu4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMASTER
            // 
            this.tabMASTER.Controls.Add(this.tb1);
            this.tabMASTER.Controls.Add(this.tb2);
            this.tabMASTER.Controls.Add(this.tb3);
            this.tabMASTER.Controls.Add(this.tb4);
            this.tabMASTER.Controls.Add(this.tb5);
            this.tabMASTER.Controls.Add(this.tb6);
            this.tabMASTER.Controls.Add(this.tb7);
            this.tabMASTER.Controls.Add(this.tb8);
            this.tabMASTER.Controls.Add(this.tb9);
            this.tabMASTER.Controls.Add(this.tb10);
            this.tabMASTER.Controls.Add(this.tb11);
            this.tabMASTER.Controls.Add(this.tb12);
            this.tabMASTER.Controls.Add(this.tb13);
            this.tabMASTER.Controls.Add(this.tb14);
            this.tabMASTER.Controls.Add(this.tb15);
            this.tabMASTER.Controls.Add(this.tb16);
            this.tabMASTER.Controls.Add(this.tb17);
            this.tabMASTER.Controls.Add(this.tb18);
            this.tabMASTER.Controls.Add(this.tb19);
            this.tabMASTER.Controls.Add(this.tb20);
            this.tabMASTER.Controls.Add(this.tb21);
            this.tabMASTER.Controls.Add(this.tb22);
            this.tabMASTER.Controls.Add(this.tb23);
            this.tabMASTER.Controls.Add(this.tb24);
            this.tabMASTER.Controls.Add(this.tb25);
            this.tabMASTER.Controls.Add(this.tb26);
            this.tabMASTER.Controls.Add(this.tb27);
            this.tabMASTER.Controls.Add(this.tb28);
            this.tabMASTER.Controls.Add(this.tb29);
            this.tabMASTER.Controls.Add(this.tb30);
            this.tabMASTER.Controls.Add(this.tb31);
            this.tabMASTER.Controls.Add(this.tb32);
            this.tabMASTER.FontSize = MetroFramework.MetroTabControlSize.Small;
            this.tabMASTER.FontWeight = MetroFramework.MetroTabControlWeight.Regular;
            this.tabMASTER.Location = new System.Drawing.Point(363, 39);
            this.tabMASTER.Margin = new System.Windows.Forms.Padding(5);
            this.tabMASTER.Name = "tabMASTER";
            this.tabMASTER.RightToLeftLayout = true;
            this.tabMASTER.SelectedIndex = 12;
            this.tabMASTER.Size = new System.Drawing.Size(870, 603);
            this.tabMASTER.Style = MetroFramework.MetroColorStyle.Blue;
            this.tabMASTER.TabIndex = 9;
            this.tabMASTER.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tabMASTER.UseSelectable = true;
            this.tabMASTER.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mouse_Down);
            // 
            // tb1
            // 
            this.tb1.AllowDrop = true;
            this.tb1.AutoScroll = true;
            this.tb1.Controls.Add(this.panel1);
            this.tb1.Location = new System.Drawing.Point(4, 34);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(862, 565);
            this.tb1.TabIndex = 0;
            this.tb1.Text = "Merchants";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel1.Controls.Add(this.buttonexpmerc);
            this.panel1.Controls.Add(this.panelMerc);
            this.panel1.Controls.Add(this.dgvMERC);
            this.panel1.Controls.Add(this.panelPlaceHolderMerc);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(862, 565);
            this.panel1.TabIndex = 50;
            // 
            // buttonexpmerc
            // 
            this.buttonexpmerc.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpmerc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpmerc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpmerc.Location = new System.Drawing.Point(711, 339);
            this.buttonexpmerc.Name = "buttonexpmerc";
            this.buttonexpmerc.Size = new System.Drawing.Size(133, 45);
            this.buttonexpmerc.TabIndex = 130;
            this.buttonexpmerc.Text = "Export";
            this.buttonexpmerc.UseVisualStyleBackColor = false;
            this.buttonexpmerc.Click += new System.EventHandler(this.buttonexpmerc_Click);
            // 
            // panelMerc
            // 
            this.panelMerc.Controls.Add(this.label2);
            this.panelMerc.Controls.Add(this.textBox_CreatePsname);
            this.panelMerc.Controls.Add(this.PB_PNCHECKER);
            this.panelMerc.Controls.Add(this.textBoxCreatePname);
            this.panelMerc.Controls.Add(this.PB_PIDCHECKER);
            this.panelMerc.Controls.Add(this.buttonCreate);
            this.panelMerc.Controls.Add(this.label29);
            this.panelMerc.Controls.Add(this.textBoxCreate_PID);
            this.panelMerc.Controls.Add(this.label28);
            this.panelMerc.Controls.Add(this.label5);
            this.panelMerc.Controls.Add(this.label27);
            this.panelMerc.Controls.Add(this.label6);
            this.panelMerc.Controls.Add(this.label7);
            this.panelMerc.Location = new System.Drawing.Point(268, 25);
            this.panelMerc.Name = "panelMerc";
            this.panelMerc.Size = new System.Drawing.Size(314, 320);
            this.panelMerc.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 18);
            this.label2.TabIndex = 50;
            this.label2.Text = "Create Merchant";
            // 
            // textBox_CreatePsname
            // 
            this.textBox_CreatePsname.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_CreatePsname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_CreatePsname.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_CreatePsname.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBox_CreatePsname.Location = new System.Drawing.Point(25, 219);
            this.textBox_CreatePsname.Name = "textBox_CreatePsname";
            this.textBox_CreatePsname.Size = new System.Drawing.Size(234, 24);
            this.textBox_CreatePsname.TabIndex = 54;
            this.textBox_CreatePsname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // PB_PNCHECKER
            // 
            this.PB_PNCHECKER.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PB_PNCHECKER.BackgroundImage")));
            this.PB_PNCHECKER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PB_PNCHECKER.Location = new System.Drawing.Point(265, 142);
            this.PB_PNCHECKER.Name = "PB_PNCHECKER";
            this.PB_PNCHECKER.Size = new System.Drawing.Size(30, 32);
            this.PB_PNCHECKER.TabIndex = 76;
            this.PB_PNCHECKER.TabStop = false;
            this.PB_PNCHECKER.Visible = false;
            // 
            // textBoxCreatePname
            // 
            this.textBoxCreatePname.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCreatePname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCreatePname.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCreatePname.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxCreatePname.Location = new System.Drawing.Point(25, 146);
            this.textBoxCreatePname.Name = "textBoxCreatePname";
            this.textBoxCreatePname.Size = new System.Drawing.Size(234, 24);
            this.textBoxCreatePname.TabIndex = 53;
            this.textBoxCreatePname.TextChanged += new System.EventHandler(this.textBoxCreatePname_TextChanged);
            this.textBoxCreatePname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // PB_PIDCHECKER
            // 
            this.PB_PIDCHECKER.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PB_PIDCHECKER.BackgroundImage")));
            this.PB_PIDCHECKER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PB_PIDCHECKER.Location = new System.Drawing.Point(265, 68);
            this.PB_PIDCHECKER.Name = "PB_PIDCHECKER";
            this.PB_PIDCHECKER.Size = new System.Drawing.Size(30, 32);
            this.PB_PIDCHECKER.TabIndex = 75;
            this.PB_PIDCHECKER.TabStop = false;
            this.PB_PIDCHECKER.Visible = false;
            // 
            // buttonCreate
            // 
            this.buttonCreate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreate.Location = new System.Drawing.Point(78, 269);
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(133, 45);
            this.buttonCreate.TabIndex = 55;
            this.buttonCreate.Text = "Create";
            this.buttonCreate.UseVisualStyleBackColor = true;
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(238, 190);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(15, 18);
            this.label29.TabIndex = 71;
            this.label29.Text = "*";
            // 
            // textBoxCreate_PID
            // 
            this.textBoxCreate_PID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxCreate_PID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCreate_PID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCreate_PID.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxCreate_PID.Location = new System.Drawing.Point(25, 73);
            this.textBoxCreate_PID.MaxLength = 10;
            this.textBoxCreate_PID.Name = "textBoxCreate_PID";
            this.textBoxCreate_PID.Size = new System.Drawing.Size(234, 24);
            this.textBoxCreate_PID.TabIndex = 51;
            this.textBoxCreate_PID.TextChanged += new System.EventHandler(this.textBoxCreate_PID_TextChanged);
            this.textBoxCreate_PID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(238, 118);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(15, 18);
            this.label28.TabIndex = 70;
            this.label28.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 14);
            this.label5.TabIndex = 61;
            this.label5.Text = "Participant ID:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(238, 44);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(15, 18);
            this.label27.TabIndex = 69;
            this.label27.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 14);
            this.label6.TabIndex = 62;
            this.label6.Text = "Participant Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 14);
            this.label7.TabIndex = 63;
            this.label7.Text = "Participant Shortname:";
            // 
            // dgvMERC
            // 
            this.dgvMERC.AllowUserToAddRows = false;
            this.dgvMERC.AllowUserToResizeRows = false;
            this.dgvMERC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMERC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvMERC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvMERC.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvMERC.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle841.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle841.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle841.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle841.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle841.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle841.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle841.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMERC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle841;
            this.dgvMERC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle842.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle842.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle842.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle842.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle842.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle842.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle842.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMERC.DefaultCellStyle = dataGridViewCellStyle842;
            this.dgvMERC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvMERC.EnableHeadersVisualStyles = false;
            this.dgvMERC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvMERC.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvMERC.Location = new System.Drawing.Point(0, 358);
            this.dgvMERC.MultiSelect = false;
            this.dgvMERC.Name = "dgvMERC";
            this.dgvMERC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle843.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle843.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle843.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle843.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle843.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle843.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle843.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMERC.RowHeadersDefaultCellStyle = dataGridViewCellStyle843;
            this.dgvMERC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvMERC.RowTemplate.Height = 33;
            this.dgvMERC.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvMERC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMERC.Size = new System.Drawing.Size(862, 207);
            this.dgvMERC.TabIndex = 129;
            this.dgvMERC.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMERC_CellClick);
            // 
            // panelPlaceHolderMerc
            // 
            this.panelPlaceHolderMerc.Controls.Add(this.comboBoxMerchantList);
            this.panelPlaceHolderMerc.Controls.Add(this.buttonDELMERC);
            this.panelPlaceHolderMerc.Controls.Add(this.textBoxEdit_Pname);
            this.panelPlaceHolderMerc.Controls.Add(this.textBox_PSname);
            this.panelPlaceHolderMerc.Controls.Add(this.buttonUpdate);
            this.panelPlaceHolderMerc.Controls.Add(this.label32);
            this.panelPlaceHolderMerc.Controls.Add(this.label3);
            this.panelPlaceHolderMerc.Controls.Add(this.label31);
            this.panelPlaceHolderMerc.Controls.Add(this.label8);
            this.panelPlaceHolderMerc.Controls.Add(this.label30);
            this.panelPlaceHolderMerc.Controls.Add(this.label9);
            this.panelPlaceHolderMerc.Controls.Add(this.label10);
            this.panelPlaceHolderMerc.Controls.Add(this.label1);
            this.panelPlaceHolderMerc.Location = new System.Drawing.Point(408, 25);
            this.panelPlaceHolderMerc.Name = "panelPlaceHolderMerc";
            this.panelPlaceHolderMerc.Size = new System.Drawing.Size(378, 311);
            this.panelPlaceHolderMerc.TabIndex = 128;
            this.panelPlaceHolderMerc.Visible = false;
            // 
            // comboBoxMerchantList
            // 
            this.comboBoxMerchantList.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoxMerchantList.FormattingEnabled = true;
            this.comboBoxMerchantList.ItemHeight = 23;
            this.comboBoxMerchantList.Location = new System.Drawing.Point(111, 73);
            this.comboBoxMerchantList.Name = "comboBoxMerchantList";
            this.comboBoxMerchantList.Size = new System.Drawing.Size(234, 29);
            this.comboBoxMerchantList.Sorted = true;
            this.comboBoxMerchantList.TabIndex = 68;
            this.comboBoxMerchantList.UseSelectable = true;
            this.comboBoxMerchantList.SelectedIndexChanged += new System.EventHandler(this.comboBoxMerchantList_SelectedIndexChanged);
            // 
            // buttonDELMERC
            // 
            this.buttonDELMERC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELMERC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELMERC.Location = new System.Drawing.Point(233, 0);
            this.buttonDELMERC.Name = "buttonDELMERC";
            this.buttonDELMERC.Size = new System.Drawing.Size(111, 41);
            this.buttonDELMERC.TabIndex = 127;
            this.buttonDELMERC.Text = "Delete";
            this.buttonDELMERC.UseVisualStyleBackColor = true;
            this.buttonDELMERC.Click += new System.EventHandler(this.buttonDELMERC_Click);
            // 
            // textBoxEdit_Pname
            // 
            this.textBoxEdit_Pname.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxEdit_Pname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxEdit_Pname.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEdit_Pname.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxEdit_Pname.Location = new System.Drawing.Point(111, 146);
            this.textBoxEdit_Pname.Name = "textBoxEdit_Pname";
            this.textBoxEdit_Pname.Size = new System.Drawing.Size(234, 24);
            this.textBoxEdit_Pname.TabIndex = 57;
            this.textBoxEdit_Pname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // textBox_PSname
            // 
            this.textBox_PSname.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_PSname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_PSname.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PSname.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBox_PSname.Location = new System.Drawing.Point(111, 219);
            this.textBox_PSname.Name = "textBox_PSname";
            this.textBox_PSname.Size = new System.Drawing.Size(234, 24);
            this.textBox_PSname.TabIndex = 58;
            this.textBox_PSname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUpdate.Location = new System.Drawing.Point(159, 266);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(133, 45);
            this.buttonUpdate.TabIndex = 59;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(324, 190);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(15, 18);
            this.label32.TabIndex = 74;
            this.label32.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 18);
            this.label3.TabIndex = 60;
            this.label3.Text = "or";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(324, 118);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 18);
            this.label31.TabIndex = 73;
            this.label31.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(106, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 14);
            this.label8.TabIndex = 64;
            this.label8.Text = "Merchant:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(324, 44);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 18);
            this.label30.TabIndex = 72;
            this.label30.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(106, 118);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 14);
            this.label9.TabIndex = 65;
            this.label9.Text = "Participant Name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(106, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 14);
            this.label10.TabIndex = 66;
            this.label10.Text = "Participant Shortname:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(105, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 18);
            this.label1.TabIndex = 67;
            this.label1.Text = "Edit Merchant";
            // 
            // tb2
            // 
            this.tb2.AllowDrop = true;
            this.tb2.AutoScroll = true;
            this.tb2.Controls.Add(this.panel2);
            this.tb2.Location = new System.Drawing.Point(4, 34);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(862, 565);
            this.tb2.TabIndex = 1;
            this.tb2.Text = "BeejeesProfiles";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.buttonexpbp);
            this.panel2.Controls.Add(this.buttonSaveBP);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.buttonBPdel);
            this.panel2.Controls.Add(this.dataGridViewBP);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.textBoxPNBP2);
            this.panel2.Controls.Add(this.buttonUpdateBP);
            this.panel2.Controls.Add(this.textBoxPNBP);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(862, 565);
            this.panel2.TabIndex = 11;
            // 
            // buttonexpbp
            // 
            this.buttonexpbp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpbp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpbp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpbp.Location = new System.Drawing.Point(717, 168);
            this.buttonexpbp.Name = "buttonexpbp";
            this.buttonexpbp.Size = new System.Drawing.Size(133, 45);
            this.buttonexpbp.TabIndex = 131;
            this.buttonexpbp.Text = "Export";
            this.buttonexpbp.UseVisualStyleBackColor = false;
            this.buttonexpbp.Click += new System.EventHandler(this.buttonexpbp_Click);
            // 
            // buttonSaveBP
            // 
            this.buttonSaveBP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveBP.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveBP.Location = new System.Drawing.Point(578, 99);
            this.buttonSaveBP.Name = "buttonSaveBP";
            this.buttonSaveBP.Size = new System.Drawing.Size(133, 34);
            this.buttonSaveBP.TabIndex = 128;
            this.buttonSaveBP.Text = "Save";
            this.buttonSaveBP.UseVisualStyleBackColor = true;
            this.buttonSaveBP.Visible = false;
            this.buttonSaveBP.Click += new System.EventHandler(this.buttonSaveBP_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(822, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 18);
            this.label24.TabIndex = 127;
            this.label24.Text = "*";
            // 
            // buttonBPdel
            // 
            this.buttonBPdel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonBPdel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBPdel.Location = new System.Drawing.Point(9, 164);
            this.buttonBPdel.Name = "buttonBPdel";
            this.buttonBPdel.Size = new System.Drawing.Size(111, 41);
            this.buttonBPdel.TabIndex = 126;
            this.buttonBPdel.Text = "Delete";
            this.buttonBPdel.UseVisualStyleBackColor = true;
            this.buttonBPdel.Click += new System.EventHandler(this.buttonBPdel_Click);
            // 
            // dataGridViewBP
            // 
            this.dataGridViewBP.AllowUserToAddRows = false;
            this.dataGridViewBP.AllowUserToResizeRows = false;
            this.dataGridViewBP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridViewBP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewBP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewBP.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewBP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle844.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle844.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle844.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle844.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle844.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle844.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle844.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle844;
            this.dataGridViewBP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle845.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle845.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle845.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle845.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle845.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle845.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle845.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewBP.DefaultCellStyle = dataGridViewCellStyle845;
            this.dataGridViewBP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewBP.EnableHeadersVisualStyles = false;
            this.dataGridViewBP.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataGridViewBP.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewBP.Location = new System.Drawing.Point(0, 195);
            this.dataGridViewBP.MultiSelect = false;
            this.dataGridViewBP.Name = "dataGridViewBP";
            this.dataGridViewBP.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle846.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle846.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle846.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle846.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle846.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle846.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle846.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBP.RowHeadersDefaultCellStyle = dataGridViewCellStyle846;
            this.dataGridViewBP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewBP.RowTemplate.Height = 33;
            this.dataGridViewBP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBP.Size = new System.Drawing.Size(862, 370);
            this.dataGridViewBP.TabIndex = 125;
            this.dataGridViewBP.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewBP_CellContentClick);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(305, 22);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 18);
            this.label34.TabIndex = 81;
            this.label34.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(33, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 14);
            this.label13.TabIndex = 64;
            this.label13.Text = "Profile ID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(339, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 14);
            this.label12.TabIndex = 63;
            this.label12.Text = "Profile Name:";
            // 
            // textBoxPNBP2
            // 
            this.textBoxPNBP2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxPNBP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPNBP2.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPNBP2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxPNBP2.Location = new System.Drawing.Point(344, 51);
            this.textBoxPNBP2.Name = "textBoxPNBP2";
            this.textBoxPNBP2.Size = new System.Drawing.Size(506, 26);
            this.textBoxPNBP2.TabIndex = 60;
            this.textBoxPNBP2.TextChanged += new System.EventHandler(this.textBoxPNBP2_TextChanged);
            // 
            // buttonUpdateBP
            // 
            this.buttonUpdateBP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUpdateBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUpdateBP.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateBP.Location = new System.Drawing.Point(717, 99);
            this.buttonUpdateBP.Name = "buttonUpdateBP";
            this.buttonUpdateBP.Size = new System.Drawing.Size(133, 34);
            this.buttonUpdateBP.TabIndex = 59;
            this.buttonUpdateBP.Text = "Create";
            this.buttonUpdateBP.UseVisualStyleBackColor = true;
            this.buttonUpdateBP.Click += new System.EventHandler(this.buttonUpdateBP_Click);
            // 
            // textBoxPNBP
            // 
            this.textBoxPNBP.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxPNBP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPNBP.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPNBP.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxPNBP.Location = new System.Drawing.Point(38, 51);
            this.textBoxPNBP.Name = "textBoxPNBP";
            this.textBoxPNBP.Size = new System.Drawing.Size(294, 26);
            this.textBoxPNBP.TabIndex = 58;
            this.textBoxPNBP.TextChanged += new System.EventHandler(this.NumZeroTextChanged);
            this.textBoxPNBP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // tb3
            // 
            this.tb3.AllowDrop = true;
            this.tb3.AutoScroll = true;
            this.tb3.Controls.Add(this.panel);
            this.tb3.Location = new System.Drawing.Point(4, 34);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(862, 565);
            this.tb3.TabIndex = 2;
            this.tb3.Text = "BeejeesFleets";
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.SystemColors.Window;
            this.panel.Controls.Add(this.buttonexpbf);
            this.panel.Controls.Add(this.label275);
            this.panel.Controls.Add(this.panelBF);
            this.panel.Controls.Add(this.label23);
            this.panel.Controls.Add(this.textBoxAppend);
            this.panel.Controls.Add(this.textBoxFleetsName);
            this.panel.Controls.Add(this.label20d);
            this.panel.Controls.Add(this.label33);
            this.panel.Controls.Add(this.comboBoxBF);
            this.panel.Controls.Add(this.buttonSAVE_Fleets);
            this.panel.Controls.Add(this.comboBoxMercBP);
            this.panel.Controls.Add(this.label37);
            this.panel.Controls.Add(this.buttonBFdel);
            this.panel.Controls.Add(this.dataGridViewFleets);
            this.panel.Controls.Add(this.label36);
            this.panel.Controls.Add(this.label11);
            this.panel.Controls.Add(this.buttonBF);
            this.panel.Controls.Add(this.label19);
            this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(862, 565);
            this.panel.TabIndex = 12;
            // 
            // buttonexpbf
            // 
            this.buttonexpbf.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpbf.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpbf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpbf.Location = new System.Drawing.Point(703, 191);
            this.buttonexpbf.Name = "buttonexpbf";
            this.buttonexpbf.Size = new System.Drawing.Size(133, 45);
            this.buttonexpbf.TabIndex = 134;
            this.buttonexpbf.Text = "Export";
            this.buttonexpbf.UseVisualStyleBackColor = false;
            this.buttonexpbf.Click += new System.EventHandler(this.buttonexpbf_Click);
            // 
            // label275
            // 
            this.label275.AutoSize = true;
            this.label275.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label275.ForeColor = System.Drawing.Color.Red;
            this.label275.Location = new System.Drawing.Point(220, 100);
            this.label275.Name = "label275";
            this.label275.Size = new System.Drawing.Size(15, 18);
            this.label275.TabIndex = 133;
            this.label275.Text = "*";
            // 
            // panelBF
            // 
            this.panelBF.Controls.Add(this.label135);
            this.panelBF.Controls.Add(this.label136);
            this.panelBF.Controls.Add(this.textBoxNewPIDBF);
            this.panelBF.Location = new System.Drawing.Point(258, 11);
            this.panelBF.Name = "panelBF";
            this.panelBF.Size = new System.Drawing.Size(225, 100);
            this.panelBF.TabIndex = 83;
            this.panelBF.Visible = false;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label135.ForeColor = System.Drawing.Color.Red;
            this.label135.Location = new System.Drawing.Point(187, 12);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(15, 18);
            this.label135.TabIndex = 133;
            this.label135.Text = "*";
            this.label135.Visible = false;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.Location = new System.Drawing.Point(15, 12);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(82, 14);
            this.label136.TabIndex = 132;
            this.label136.Text = "New Profile ID:";
            this.label136.Visible = false;
            // 
            // textBoxNewPIDBF
            // 
            this.textBoxNewPIDBF.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNewPIDBF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNewPIDBF.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewPIDBF.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxNewPIDBF.Location = new System.Drawing.Point(20, 51);
            this.textBoxNewPIDBF.Name = "textBoxNewPIDBF";
            this.textBoxNewPIDBF.Size = new System.Drawing.Size(188, 24);
            this.textBoxNewPIDBF.TabIndex = 131;
            this.textBoxNewPIDBF.Visible = false;
            this.textBoxNewPIDBF.TextChanged += new System.EventHandler(this.textBoxNewPIDBF_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(32, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 14);
            this.label23.TabIndex = 132;
            this.label23.Text = "Fleets Name:";
            // 
            // textBoxAppend
            // 
            this.textBoxAppend.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxAppend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAppend.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAppend.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxAppend.Location = new System.Drawing.Point(33, 132);
            this.textBoxAppend.Name = "textBoxAppend";
            this.textBoxAppend.Size = new System.Drawing.Size(220, 26);
            this.textBoxAppend.TabIndex = 131;
            // 
            // textBoxFleetsName
            // 
            this.textBoxFleetsName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxFleetsName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxFleetsName.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFleetsName.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxFleetsName.Location = new System.Drawing.Point(489, 59);
            this.textBoxFleetsName.Name = "textBoxFleetsName";
            this.textBoxFleetsName.ReadOnly = true;
            this.textBoxFleetsName.Size = new System.Drawing.Size(347, 26);
            this.textBoxFleetsName.TabIndex = 65;
            // 
            // label20d
            // 
            this.label20d.AutoSize = true;
            this.label20d.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20d.Location = new System.Drawing.Point(484, 29);
            this.label20d.Name = "label20d";
            this.label20d.Size = new System.Drawing.Size(75, 14);
            this.label20d.TabIndex = 66;
            this.label20d.Text = "Profile Name:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Location = new System.Drawing.Point(200, 31);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 18);
            this.label33.TabIndex = 80;
            this.label33.Text = "*";
            // 
            // comboBoxBF
            // 
            this.comboBoxBF.FormattingEnabled = true;
            this.comboBoxBF.ItemHeight = 23;
            this.comboBoxBF.Location = new System.Drawing.Point(277, 60);
            this.comboBoxBF.Name = "comboBoxBF";
            this.comboBoxBF.Size = new System.Drawing.Size(188, 29);
            this.comboBoxBF.Sorted = true;
            this.comboBoxBF.TabIndex = 130;
            this.comboBoxBF.UseSelectable = true;
            this.comboBoxBF.SelectedIndexChanged += new System.EventHandler(this.comboBoxBF_SelectedIndexChanged);
            // 
            // buttonSAVE_Fleets
            // 
            this.buttonSAVE_Fleets.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVE_Fleets.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVE_Fleets.Location = new System.Drawing.Point(508, 127);
            this.buttonSAVE_Fleets.Name = "buttonSAVE_Fleets";
            this.buttonSAVE_Fleets.Size = new System.Drawing.Size(161, 41);
            this.buttonSAVE_Fleets.TabIndex = 129;
            this.buttonSAVE_Fleets.Text = "Save";
            this.buttonSAVE_Fleets.UseVisualStyleBackColor = true;
            this.buttonSAVE_Fleets.Visible = false;
            this.buttonSAVE_Fleets.Click += new System.EventHandler(this.buttonSAVE_Fleets_Click);
            // 
            // comboBoxMercBP
            // 
            this.comboBoxMercBP.FormattingEnabled = true;
            this.comboBoxMercBP.ItemHeight = 23;
            this.comboBoxMercBP.Location = new System.Drawing.Point(33, 60);
            this.comboBoxMercBP.Name = "comboBoxMercBP";
            this.comboBoxMercBP.Size = new System.Drawing.Size(224, 29);
            this.comboBoxMercBP.TabIndex = 79;
            this.comboBoxMercBP.Theme = MetroFramework.MetroThemeStyle.Light;
            this.comboBoxMercBP.UseSelectable = true;
            this.comboBoxMercBP.UseStyleColors = true;
            this.comboBoxMercBP.SelectedIndexChanged += new System.EventHandler(this.comboBoxMercBP_SelectedIndexChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(905, 25);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(15, 18);
            this.label37.TabIndex = 81;
            this.label37.Text = "*";
            // 
            // buttonBFdel
            // 
            this.buttonBFdel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonBFdel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBFdel.Location = new System.Drawing.Point(0, 193);
            this.buttonBFdel.Name = "buttonBFdel";
            this.buttonBFdel.Size = new System.Drawing.Size(111, 41);
            this.buttonBFdel.TabIndex = 127;
            this.buttonBFdel.Text = "Delete";
            this.buttonBFdel.UseVisualStyleBackColor = true;
            this.buttonBFdel.Click += new System.EventHandler(this.buttonBFdel_Click);
            // 
            // dataGridViewFleets
            // 
            this.dataGridViewFleets.AllowUserToAddRows = false;
            this.dataGridViewFleets.AllowUserToResizeRows = false;
            this.dataGridViewFleets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFleets.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewFleets.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewFleets.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewFleets.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle847.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle847.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle847.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle847.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle847.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle847.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle847.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewFleets.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle847;
            this.dataGridViewFleets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle848.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle848.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle848.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle848.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle848.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle848.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle848.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewFleets.DefaultCellStyle = dataGridViewCellStyle848;
            this.dataGridViewFleets.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewFleets.EnableHeadersVisualStyles = false;
            this.dataGridViewFleets.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataGridViewFleets.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewFleets.Location = new System.Drawing.Point(0, 212);
            this.dataGridViewFleets.MultiSelect = false;
            this.dataGridViewFleets.Name = "dataGridViewFleets";
            this.dataGridViewFleets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle849.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle849.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle849.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle849.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle849.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle849.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle849.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewFleets.RowHeadersDefaultCellStyle = dataGridViewCellStyle849;
            this.dataGridViewFleets.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewFleets.RowTemplate.Height = 33;
            this.dataGridViewFleets.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFleets.Size = new System.Drawing.Size(862, 353);
            this.dataGridViewFleets.TabIndex = 126;
            this.dataGridViewFleets.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewFleets_CellDoubleClick);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Red;
            this.label36.Location = new System.Drawing.Point(444, 29);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(15, 18);
            this.label36.TabIndex = 80;
            this.label36.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 14);
            this.label11.TabIndex = 62;
            this.label11.Text = "Merchant Participant ID:";
            // 
            // buttonBF
            // 
            this.buttonBF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonBF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBF.Location = new System.Drawing.Point(675, 127);
            this.buttonBF.Name = "buttonBF";
            this.buttonBF.Size = new System.Drawing.Size(161, 41);
            this.buttonBF.TabIndex = 67;
            this.buttonBF.Text = "Generate";
            this.buttonBF.UseVisualStyleBackColor = true;
            this.buttonBF.Click += new System.EventHandler(this.buttonBF_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(272, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 14);
            this.label19.TabIndex = 64;
            this.label19.Text = "BejeesProfile ID:";
            // 
            // tb4
            // 
            this.tb4.AllowDrop = true;
            this.tb4.AutoScroll = true;
            this.tb4.Controls.Add(this.panel4);
            this.tb4.Location = new System.Drawing.Point(4, 34);
            this.tb4.Name = "tb4";
            this.tb4.Size = new System.Drawing.Size(862, 565);
            this.tb4.TabIndex = 3;
            this.tb4.Text = "Terminals";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel4.Controls.Add(this.buttonterminalexp);
            this.panel4.Controls.Add(this.panelTerminal2);
            this.panel4.Controls.Add(this.buttonST);
            this.panel4.Controls.Add(this.label137);
            this.panel4.Controls.Add(this.buttonDelT);
            this.panel4.Controls.Add(this.metroGridFleets);
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.comboBoxTermT);
            this.panel4.Controls.Add(this.textBoxFname);
            this.panel4.Controls.Add(this.comboBoxBJFID);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.buttonTerminalUP);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.textBox_TermID);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(862, 565);
            this.panel4.TabIndex = 12;
            // 
            // buttonterminalexp
            // 
            this.buttonterminalexp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonterminalexp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonterminalexp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonterminalexp.Location = new System.Drawing.Point(717, 247);
            this.buttonterminalexp.Name = "buttonterminalexp";
            this.buttonterminalexp.Size = new System.Drawing.Size(133, 45);
            this.buttonterminalexp.TabIndex = 147;
            this.buttonterminalexp.Text = "Export";
            this.buttonterminalexp.UseVisualStyleBackColor = false;
            this.buttonterminalexp.Click += new System.EventHandler(this.buttonterminalexp_Click);
            // 
            // panelTerminal2
            // 
            this.panelTerminal2.Controls.Add(this.metroComboBoxFleet);
            this.panelTerminal2.Controls.Add(this.metroComboBoxTType);
            this.panelTerminal2.Controls.Add(this.label139);
            this.panelTerminal2.Controls.Add(this.label138);
            this.panelTerminal2.Controls.Add(this.textBoxNewTID);
            this.panelTerminal2.Controls.Add(this.label141);
            this.panelTerminal2.Controls.Add(this.label142);
            this.panelTerminal2.Controls.Add(this.label140);
            this.panelTerminal2.Controls.Add(this.label143);
            this.panelTerminal2.Location = new System.Drawing.Point(14, 6);
            this.panelTerminal2.Name = "panelTerminal2";
            this.panelTerminal2.Size = new System.Drawing.Size(792, 180);
            this.panelTerminal2.TabIndex = 145;
            this.panelTerminal2.Visible = false;
            // 
            // metroComboBoxFleet
            // 
            this.metroComboBoxFleet.FormattingEnabled = true;
            this.metroComboBoxFleet.ItemHeight = 23;
            this.metroComboBoxFleet.Location = new System.Drawing.Point(21, 57);
            this.metroComboBoxFleet.Name = "metroComboBoxFleet";
            this.metroComboBoxFleet.Size = new System.Drawing.Size(519, 29);
            this.metroComboBoxFleet.TabIndex = 144;
            this.metroComboBoxFleet.UseSelectable = true;
            this.metroComboBoxFleet.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxFleet_SelectedIndexChanged);
            // 
            // metroComboBoxTType
            // 
            this.metroComboBoxTType.FormattingEnabled = true;
            this.metroComboBoxTType.ItemHeight = 23;
            this.metroComboBoxTType.Items.AddRange(new object[] {
            "BUS",
            "JEEPNEY",
            "PARKING"});
            this.metroComboBoxTType.Location = new System.Drawing.Point(549, 57);
            this.metroComboBoxTType.Name = "metroComboBoxTType";
            this.metroComboBoxTType.Size = new System.Drawing.Size(188, 29);
            this.metroComboBoxTType.Sorted = true;
            this.metroComboBoxTType.TabIndex = 143;
            this.metroComboBoxTType.UseSelectable = true;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.Location = new System.Drawing.Point(16, 28);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(60, 14);
            this.label139.TabIndex = 132;
            this.label139.Text = "New Fleet:";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label138.ForeColor = System.Drawing.Color.Red;
            this.label138.Location = new System.Drawing.Point(512, 28);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(15, 18);
            this.label138.TabIndex = 133;
            this.label138.Text = "*";
            // 
            // textBoxNewTID
            // 
            this.textBoxNewTID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNewTID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNewTID.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewTID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxNewTID.Location = new System.Drawing.Point(23, 131);
            this.textBoxNewTID.Name = "textBoxNewTID";
            this.textBoxNewTID.Size = new System.Drawing.Size(188, 21);
            this.textBoxNewTID.TabIndex = 134;
            this.textBoxNewTID.TextChanged += new System.EventHandler(this.textBoxNewTID_TextChanged);
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(18, 106);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(91, 14);
            this.label141.TabIndex = 135;
            this.label141.Text = "New Terminal ID:";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label142.ForeColor = System.Drawing.Color.Red;
            this.label142.Location = new System.Drawing.Point(715, 28);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(15, 18);
            this.label142.TabIndex = 139;
            this.label142.Text = "*";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.ForeColor = System.Drawing.Color.Red;
            this.label140.Location = new System.Drawing.Point(190, 106);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(15, 18);
            this.label140.TabIndex = 136;
            this.label140.Text = "*";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label143.Location = new System.Drawing.Point(543, 28);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(104, 14);
            this.label143.TabIndex = 138;
            this.label143.Text = "New Terminal Type:";
            // 
            // buttonST
            // 
            this.buttonST.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonST.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonST.Location = new System.Drawing.Point(578, 200);
            this.buttonST.Name = "buttonST";
            this.buttonST.Size = new System.Drawing.Size(133, 45);
            this.buttonST.TabIndex = 146;
            this.buttonST.Text = "Save";
            this.buttonST.UseVisualStyleBackColor = true;
            this.buttonST.Visible = false;
            this.buttonST.Click += new System.EventHandler(this.buttonST_Click);
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.ForeColor = System.Drawing.Color.Red;
            this.label137.Location = new System.Drawing.Point(399, 107);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(15, 18);
            this.label137.TabIndex = 130;
            this.label137.Text = "*";
            this.label137.Visible = false;
            // 
            // buttonDelT
            // 
            this.buttonDelT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDelT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonDelT.Location = new System.Drawing.Point(0, 249);
            this.buttonDelT.Name = "buttonDelT";
            this.buttonDelT.Size = new System.Drawing.Size(111, 41);
            this.buttonDelT.TabIndex = 128;
            this.buttonDelT.Text = "Delete";
            this.buttonDelT.UseVisualStyleBackColor = true;
            this.buttonDelT.Click += new System.EventHandler(this.button5_Click);
            // 
            // metroGridFleets
            // 
            this.metroGridFleets.AllowUserToAddRows = false;
            this.metroGridFleets.AllowUserToResizeRows = false;
            this.metroGridFleets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.metroGridFleets.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGridFleets.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGridFleets.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGridFleets.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle850.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle850.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle850.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle850.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle850.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle850.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle850.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGridFleets.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle850;
            this.metroGridFleets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle851.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle851.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle851.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle851.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle851.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle851.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle851.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGridFleets.DefaultCellStyle = dataGridViewCellStyle851;
            this.metroGridFleets.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroGridFleets.EnableHeadersVisualStyles = false;
            this.metroGridFleets.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGridFleets.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGridFleets.Location = new System.Drawing.Point(0, 267);
            this.metroGridFleets.MultiSelect = false;
            this.metroGridFleets.Name = "metroGridFleets";
            this.metroGridFleets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle852.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle852.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle852.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle852.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle852.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle852.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle852.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGridFleets.RowHeadersDefaultCellStyle = dataGridViewCellStyle852;
            this.metroGridFleets.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGridFleets.RowTemplate.Height = 33;
            this.metroGridFleets.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGridFleets.Size = new System.Drawing.Size(862, 298);
            this.metroGridFleets.TabIndex = 127;
            this.metroGridFleets.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.metroGridFleets_CellContentDoubleClick);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Red;
            this.label40.Location = new System.Drawing.Point(729, 34);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(15, 18);
            this.label40.TabIndex = 85;
            this.label40.Text = "*";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(526, 34);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(15, 18);
            this.label39.TabIndex = 84;
            this.label39.Text = "*";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(203, 106);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(15, 18);
            this.label38.TabIndex = 83;
            this.label38.Text = "*";
            // 
            // comboBoxTermT
            // 
            this.comboBoxTermT.FormattingEnabled = true;
            this.comboBoxTermT.ItemHeight = 23;
            this.comboBoxTermT.Items.AddRange(new object[] {
            "BUS",
            "JEEPNEY",
            "PARKING"});
            this.comboBoxTermT.Location = new System.Drawing.Point(562, 63);
            this.comboBoxTermT.Name = "comboBoxTermT";
            this.comboBoxTermT.Size = new System.Drawing.Size(188, 29);
            this.comboBoxTermT.Sorted = true;
            this.comboBoxTermT.TabIndex = 78;
            this.comboBoxTermT.UseSelectable = true;
            // 
            // textBoxFname
            // 
            this.textBoxFname.FormattingEnabled = true;
            this.textBoxFname.ItemHeight = 23;
            this.textBoxFname.Location = new System.Drawing.Point(36, 63);
            this.textBoxFname.Name = "textBoxFname";
            this.textBoxFname.Size = new System.Drawing.Size(520, 29);
            this.textBoxFname.TabIndex = 77;
            this.textBoxFname.UseSelectable = true;
            this.textBoxFname.SelectedIndexChanged += new System.EventHandler(this.comboBoxBJFID_SelectedIndexChanged);
            // 
            // comboBoxBJFID
            // 
            this.comboBoxBJFID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.comboBoxBJFID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.comboBoxBJFID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxBJFID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.comboBoxBJFID.Location = new System.Drawing.Point(232, 136);
            this.comboBoxBJFID.Name = "comboBoxBJFID";
            this.comboBoxBJFID.ReadOnly = true;
            this.comboBoxBJFID.Size = new System.Drawing.Size(188, 24);
            this.comboBoxBJFID.TabIndex = 72;
            this.comboBoxBJFID.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(31, 34);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 14);
            this.label21.TabIndex = 73;
            this.label21.Text = "Fleets Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(560, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 14);
            this.label18.TabIndex = 70;
            this.label18.Text = "Terminal Type:";
            // 
            // buttonTerminalUP
            // 
            this.buttonTerminalUP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonTerminalUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTerminalUP.Location = new System.Drawing.Point(717, 200);
            this.buttonTerminalUP.Name = "buttonTerminalUP";
            this.buttonTerminalUP.Size = new System.Drawing.Size(133, 45);
            this.buttonTerminalUP.TabIndex = 71;
            this.buttonTerminalUP.Text = "Create";
            this.buttonTerminalUP.UseVisualStyleBackColor = true;
            this.buttonTerminalUP.Click += new System.EventHandler(this.buttonTerminalUP_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(31, 106);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 14);
            this.label15.TabIndex = 68;
            this.label15.Text = "Terminal ID:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(230, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 14);
            this.label16.TabIndex = 67;
            this.label16.Text = "Fleets ID:";
            this.label16.Visible = false;
            // 
            // textBox_TermID
            // 
            this.textBox_TermID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_TermID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_TermID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TermID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_TermID.Location = new System.Drawing.Point(36, 135);
            this.textBox_TermID.Name = "textBox_TermID";
            this.textBox_TermID.Size = new System.Drawing.Size(188, 24);
            this.textBox_TermID.TabIndex = 66;
            this.textBox_TermID.TextChanged += new System.EventHandler(this.textBox_TermID_TextChanged);
            this.textBox_TermID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // tb5
            // 
            this.tb5.AllowDrop = true;
            this.tb5.AutoScroll = true;
            this.tb5.Controls.Add(this.panel3);
            this.tb5.Location = new System.Drawing.Point(4, 34);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(862, 565);
            this.tb5.TabIndex = 4;
            this.tb5.Text = "DistanceBasedRoutes";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel3.Controls.Add(this.panelDBR);
            this.panel3.Controls.Add(this.buttonexpdbr);
            this.panel3.Controls.Add(this.buttonDELDBR);
            this.panel3.Controls.Add(this.buttonSAVEDBR);
            this.panel3.Controls.Add(this.label77);
            this.panel3.Controls.Add(this.buttonDBR_Create);
            this.panel3.Controls.Add(this.dgvDBR);
            this.panel3.Controls.Add(this.checkBoxDBR);
            this.panel3.Controls.Add(this.label48);
            this.panel3.Controls.Add(this.radioButton_cred);
            this.panel3.Controls.Add(this.radioButton_debit);
            this.panel3.Controls.Add(this.label42);
            this.panel3.Controls.Add(this.label43);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Controls.Add(this.label45);
            this.panel3.Controls.Add(this.label46);
            this.panel3.Controls.Add(this.label47);
            this.panel3.Controls.Add(this.textBoxBDR_RID);
            this.panel3.Controls.Add(this.textBoxDBR_RSN);
            this.panel3.Controls.Add(this.textBoxDBR_RLN);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(862, 565);
            this.panel3.TabIndex = 66;
            // 
            // panelDBR
            // 
            this.panelDBR.Controls.Add(this.label22);
            this.panelDBR.Controls.Add(this.label144);
            this.panelDBR.Controls.Add(this.checkBoxNDBR);
            this.panelDBR.Controls.Add(this.label145);
            this.panelDBR.Controls.Add(this.radioButtonNdcDBR);
            this.panelDBR.Controls.Add(this.radioButtonNddDBR);
            this.panelDBR.Controls.Add(this.label146);
            this.panelDBR.Controls.Add(this.label147);
            this.panelDBR.Controls.Add(this.label148);
            this.panelDBR.Controls.Add(this.label149);
            this.panelDBR.Controls.Add(this.label150);
            this.panelDBR.Controls.Add(this.label151);
            this.panelDBR.Controls.Add(this.textBoxNRID_DBR);
            this.panelDBR.Controls.Add(this.textBoxNRSN_DBR);
            this.panelDBR.Controls.Add(this.textBoxRLN_DBR);
            this.panelDBR.Location = new System.Drawing.Point(3, 8);
            this.panelDBR.Name = "panelDBR";
            this.panelDBR.Size = new System.Drawing.Size(848, 214);
            this.panelDBR.TabIndex = 82;
            this.panelDBR.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(813, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(15, 18);
            this.label22.TabIndex = 131;
            this.label22.Text = "*";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label144.ForeColor = System.Drawing.Color.Red;
            this.label144.Location = new System.Drawing.Point(119, 100);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(15, 18);
            this.label144.TabIndex = 102;
            this.label144.Text = "*";
            // 
            // checkBoxNDBR
            // 
            this.checkBoxNDBR.AutoSize = true;
            this.checkBoxNDBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxNDBR.Location = new System.Drawing.Point(27, 171);
            this.checkBoxNDBR.Name = "checkBoxNDBR";
            this.checkBoxNDBR.Size = new System.Drawing.Size(57, 18);
            this.checkBoxNDBR.TabIndex = 101;
            this.checkBoxNDBR.Text = "Active";
            this.checkBoxNDBR.UseVisualStyleBackColor = true;
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label145.Location = new System.Drawing.Point(22, 103);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(104, 14);
            this.label145.TabIndex = 100;
            this.label145.Text = "New Fare Strategy:";
            // 
            // radioButtonNdcDBR
            // 
            this.radioButtonNdcDBR.AutoSize = true;
            this.radioButtonNdcDBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNdcDBR.Location = new System.Drawing.Point(188, 135);
            this.radioButtonNdcDBR.Name = "radioButtonNdcDBR";
            this.radioButtonNdcDBR.Size = new System.Drawing.Size(85, 18);
            this.radioButtonNdcDBR.TabIndex = 99;
            this.radioButtonNdcDBR.TabStop = true;
            this.radioButtonNdcDBR.Text = "debit_credit";
            this.radioButtonNdcDBR.UseVisualStyleBackColor = true;
            // 
            // radioButtonNddDBR
            // 
            this.radioButtonNddDBR.AutoSize = true;
            this.radioButtonNddDBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNddDBR.Location = new System.Drawing.Point(27, 132);
            this.radioButtonNddDBR.Name = "radioButtonNddDBR";
            this.radioButtonNddDBR.Size = new System.Drawing.Size(82, 18);
            this.radioButtonNddDBR.TabIndex = 98;
            this.radioButtonNddDBR.TabStop = true;
            this.radioButtonNddDBR.Text = "debit_debit";
            this.radioButtonNddDBR.UseVisualStyleBackColor = true;
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label146.ForeColor = System.Drawing.Color.Red;
            this.label146.Location = new System.Drawing.Point(947, 10);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(15, 18);
            this.label146.TabIndex = 97;
            this.label146.Text = "*";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label147.ForeColor = System.Drawing.Color.Red;
            this.label147.Location = new System.Drawing.Point(459, 19);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(15, 18);
            this.label147.TabIndex = 96;
            this.label147.Text = "*";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label148.ForeColor = System.Drawing.Color.Red;
            this.label148.Location = new System.Drawing.Point(206, 19);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(15, 18);
            this.label148.TabIndex = 95;
            this.label148.Text = "*";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.Location = new System.Drawing.Point(498, 21);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(122, 14);
            this.label149.TabIndex = 94;
            this.label149.Text = "New Route Longname:";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label150.Location = new System.Drawing.Point(228, 24);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(123, 14);
            this.label150.TabIndex = 93;
            this.label150.Text = "New Route Shortname:";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label151.Location = new System.Drawing.Point(22, 19);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(79, 14);
            this.label151.TabIndex = 92;
            this.label151.Text = "New Route ID:";
            // 
            // textBoxNRID_DBR
            // 
            this.textBoxNRID_DBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNRID_DBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNRID_DBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNRID_DBR.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNRID_DBR.Location = new System.Drawing.Point(27, 48);
            this.textBoxNRID_DBR.Name = "textBoxNRID_DBR";
            this.textBoxNRID_DBR.Size = new System.Drawing.Size(207, 21);
            this.textBoxNRID_DBR.TabIndex = 89;
            this.textBoxNRID_DBR.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBoxNRSN_DBR
            // 
            this.textBoxNRSN_DBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNRSN_DBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNRSN_DBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNRSN_DBR.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNRSN_DBR.Location = new System.Drawing.Point(241, 48);
            this.textBoxNRSN_DBR.MaxLength = 9;
            this.textBoxNRSN_DBR.Name = "textBoxNRSN_DBR";
            this.textBoxNRSN_DBR.Size = new System.Drawing.Size(246, 21);
            this.textBoxNRSN_DBR.TabIndex = 90;
            // 
            // textBoxRLN_DBR
            // 
            this.textBoxRLN_DBR.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxRLN_DBR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxRLN_DBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRLN_DBR.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxRLN_DBR.Location = new System.Drawing.Point(494, 48);
            this.textBoxRLN_DBR.Name = "textBoxRLN_DBR";
            this.textBoxRLN_DBR.Size = new System.Drawing.Size(347, 21);
            this.textBoxRLN_DBR.TabIndex = 91;
            // 
            // buttonexpdbr
            // 
            this.buttonexpdbr.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpdbr.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpdbr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpdbr.Location = new System.Drawing.Point(714, 285);
            this.buttonexpdbr.Name = "buttonexpdbr";
            this.buttonexpdbr.Size = new System.Drawing.Size(133, 45);
            this.buttonexpdbr.TabIndex = 131;
            this.buttonexpdbr.Text = "Export";
            this.buttonexpdbr.UseVisualStyleBackColor = false;
            this.buttonexpdbr.Click += new System.EventHandler(this.buttonexpdbr_Click);
            // 
            // buttonDELDBR
            // 
            this.buttonDELDBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELDBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELDBR.Location = new System.Drawing.Point(1, 286);
            this.buttonDELDBR.Name = "buttonDELDBR";
            this.buttonDELDBR.Size = new System.Drawing.Size(111, 41);
            this.buttonDELDBR.TabIndex = 129;
            this.buttonDELDBR.Text = "Delete";
            this.buttonDELDBR.UseVisualStyleBackColor = true;
            this.buttonDELDBR.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonSAVEDBR
            // 
            this.buttonSAVEDBR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVEDBR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVEDBR.Location = new System.Drawing.Point(575, 234);
            this.buttonSAVEDBR.Name = "buttonSAVEDBR";
            this.buttonSAVEDBR.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVEDBR.TabIndex = 130;
            this.buttonSAVEDBR.Text = "Save";
            this.buttonSAVEDBR.UseVisualStyleBackColor = true;
            this.buttonSAVEDBR.Visible = false;
            this.buttonSAVEDBR.Click += new System.EventHandler(this.buttonSAVEDBR_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.Color.Red;
            this.label77.Location = new System.Drawing.Point(95, 106);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(15, 18);
            this.label77.TabIndex = 88;
            this.label77.Text = "*";
            // 
            // buttonDBR_Create
            // 
            this.buttonDBR_Create.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonDBR_Create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBR_Create.Location = new System.Drawing.Point(714, 234);
            this.buttonDBR_Create.Name = "buttonDBR_Create";
            this.buttonDBR_Create.Size = new System.Drawing.Size(133, 45);
            this.buttonDBR_Create.TabIndex = 85;
            this.buttonDBR_Create.Text = "Create";
            this.buttonDBR_Create.UseVisualStyleBackColor = true;
            this.buttonDBR_Create.Click += new System.EventHandler(this.buttonDBR_Create_Click);
            // 
            // dgvDBR
            // 
            this.dgvDBR.AllowUserToAddRows = false;
            this.dgvDBR.AllowUserToResizeRows = false;
            this.dgvDBR.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDBR.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDBR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDBR.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle853.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle853.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle853.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle853.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle853.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle853.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle853.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBR.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle853;
            this.dgvDBR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle854.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle854.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle854.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle854.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle854.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle854.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle854.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDBR.DefaultCellStyle = dataGridViewCellStyle854;
            this.dgvDBR.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDBR.EnableHeadersVisualStyles = false;
            this.dgvDBR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDBR.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBR.Location = new System.Drawing.Point(0, 306);
            this.dgvDBR.MultiSelect = false;
            this.dgvDBR.Name = "dgvDBR";
            this.dgvDBR.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle855.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle855.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle855.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle855.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle855.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle855.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle855.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBR.RowHeadersDefaultCellStyle = dataGridViewCellStyle855;
            this.dgvDBR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDBR.RowTemplate.Height = 33;
            this.dgvDBR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDBR.Size = new System.Drawing.Size(862, 259);
            this.dgvDBR.TabIndex = 128;
            this.dgvDBR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDBR_CellDoubleClick);
            // 
            // checkBoxDBR
            // 
            this.checkBoxDBR.AutoSize = true;
            this.checkBoxDBR.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDBR.Location = new System.Drawing.Point(26, 188);
            this.checkBoxDBR.Name = "checkBoxDBR";
            this.checkBoxDBR.Size = new System.Drawing.Size(57, 18);
            this.checkBoxDBR.TabIndex = 84;
            this.checkBoxDBR.Text = "Active";
            this.checkBoxDBR.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(21, 109);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(78, 14);
            this.label48.TabIndex = 83;
            this.label48.Text = "Fare Strategy:";
            // 
            // radioButton_cred
            // 
            this.radioButton_cred.AutoSize = true;
            this.radioButton_cred.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_cred.Location = new System.Drawing.Point(187, 141);
            this.radioButton_cred.Name = "radioButton_cred";
            this.radioButton_cred.Size = new System.Drawing.Size(85, 18);
            this.radioButton_cred.TabIndex = 82;
            this.radioButton_cred.TabStop = true;
            this.radioButton_cred.Text = "debit_credit";
            this.radioButton_cred.UseVisualStyleBackColor = true;
            // 
            // radioButton_debit
            // 
            this.radioButton_debit.AutoSize = true;
            this.radioButton_debit.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_debit.Location = new System.Drawing.Point(26, 138);
            this.radioButton_debit.Name = "radioButton_debit";
            this.radioButton_debit.Size = new System.Drawing.Size(82, 18);
            this.radioButton_debit.TabIndex = 81;
            this.radioButton_debit.TabStop = true;
            this.radioButton_debit.Text = "debit_debit";
            this.radioButton_debit.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(956, 24);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(15, 18);
            this.label42.TabIndex = 80;
            this.label42.Text = "*";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(485, 27);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(15, 18);
            this.label43.TabIndex = 79;
            this.label43.Text = "*";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(186, 25);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(15, 18);
            this.label44.TabIndex = 78;
            this.label44.Text = "*";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(510, 18);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(96, 14);
            this.label45.TabIndex = 77;
            this.label45.Text = "Route Longname:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(220, 26);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(97, 14);
            this.label46.TabIndex = 76;
            this.label46.Text = "Route Shortname:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(21, 25);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(53, 14);
            this.label47.TabIndex = 75;
            this.label47.Text = "Route ID:";
            // 
            // textBoxBDR_RID
            // 
            this.textBoxBDR_RID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxBDR_RID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBDR_RID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxBDR_RID.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxBDR_RID.Location = new System.Drawing.Point(26, 54);
            this.textBoxBDR_RID.Name = "textBoxBDR_RID";
            this.textBoxBDR_RID.Size = new System.Drawing.Size(188, 24);
            this.textBoxBDR_RID.TabIndex = 72;
            this.textBoxBDR_RID.TextChanged += new System.EventHandler(this.textBoxBDR_RID_TextChanged);
            this.textBoxBDR_RID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // textBoxDBR_RSN
            // 
            this.textBoxDBR_RSN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBR_RSN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBR_RSN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBR_RSN.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDBR_RSN.Location = new System.Drawing.Point(225, 53);
            this.textBoxDBR_RSN.MaxLength = 9;
            this.textBoxDBR_RSN.Name = "textBoxDBR_RSN";
            this.textBoxDBR_RSN.Size = new System.Drawing.Size(284, 24);
            this.textBoxDBR_RSN.TabIndex = 73;
            this.textBoxDBR_RSN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // textBoxDBR_RLN
            // 
            this.textBoxDBR_RLN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBR_RLN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBR_RLN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBR_RLN.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDBR_RLN.Location = new System.Drawing.Point(515, 53);
            this.textBoxDBR_RLN.Name = "textBoxDBR_RLN";
            this.textBoxDBR_RLN.Size = new System.Drawing.Size(332, 24);
            this.textBoxDBR_RLN.TabIndex = 74;
            this.textBoxDBR_RLN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // tb6
            // 
            this.tb6.AllowDrop = true;
            this.tb6.AutoScroll = true;
            this.tb6.Controls.Add(this.panel5);
            this.tb6.Location = new System.Drawing.Point(4, 34);
            this.tb6.Name = "tb6";
            this.tb6.Size = new System.Drawing.Size(862, 565);
            this.tb6.TabIndex = 5;
            this.tb6.Text = "DiscountFareTables";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Window;
            this.panel5.Controls.Add(this.panelDFT);
            this.panel5.Controls.Add(this.buttonexpdft);
            this.panel5.Controls.Add(this.buttonSaveDFT);
            this.panel5.Controls.Add(this.radioButtonDFT_D);
            this.panel5.Controls.Add(this.textBoxDFT_RA);
            this.panel5.Controls.Add(this.buttonDELDFT);
            this.panel5.Controls.Add(this.label94);
            this.panel5.Controls.Add(this.dgvDFT);
            this.panel5.Controls.Add(this.label92);
            this.panel5.Controls.Add(this.label89);
            this.panel5.Controls.Add(this.label90);
            this.panel5.Controls.Add(this.label91);
            this.panel5.Controls.Add(this.buttonDFT_Create);
            this.panel5.Controls.Add(this.label56);
            this.panel5.Controls.Add(this.label55);
            this.panel5.Controls.Add(this.metroDateTimeDFT_T);
            this.panel5.Controls.Add(this.label54);
            this.panel5.Controls.Add(this.metroDateTimeDFT_F);
            this.panel5.Controls.Add(this.checkBoxDFT_ACT);
            this.panel5.Controls.Add(this.label50);
            this.panel5.Controls.Add(this.radioButtonDFT_U);
            this.panel5.Controls.Add(this.radioButtonDFT_E);
            this.panel5.Controls.Add(this.label51);
            this.panel5.Controls.Add(this.label52);
            this.panel5.Controls.Add(this.textBoxDFT_FTB);
            this.panel5.Controls.Add(this.textBoxDFT_DISC);
            this.panel5.Controls.Add(this.checkBoxPro_DFT);
            this.panel5.Controls.Add(this.checkBoxAcc_DFT);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(862, 565);
            this.panel5.TabIndex = 66;
            // 
            // panelDFT
            // 
            this.panelDFT.Controls.Add(this.checkBoxPro_DFT2);
            this.panelDFT.Controls.Add(this.checkBoxAcc_DFT2);
            this.panelDFT.Controls.Add(this.radioButtonNDOWN_DFT);
            this.panelDFT.Controls.Add(this.numericUpDownNRA_DFT);
            this.panelDFT.Controls.Add(this.label112);
            this.panelDFT.Controls.Add(this.label124);
            this.panelDFT.Controls.Add(this.label166);
            this.panelDFT.Controls.Add(this.label177);
            this.panelDFT.Controls.Add(this.label179);
            this.panelDFT.Controls.Add(this.label181);
            this.panelDFT.Controls.Add(this.label182);
            this.panelDFT.Controls.Add(this.metroDateTimeNTO_DFT);
            this.panelDFT.Controls.Add(this.label183);
            this.panelDFT.Controls.Add(this.metroDateTimeNED_DFT);
            this.panelDFT.Controls.Add(this.checkBoxA_DFT);
            this.panelDFT.Controls.Add(this.label184);
            this.panelDFT.Controls.Add(this.radioButtonNUP_DFT);
            this.panelDFT.Controls.Add(this.radioButtonExactNDFT);
            this.panelDFT.Controls.Add(this.label185);
            this.panelDFT.Controls.Add(this.label186);
            this.panelDFT.Controls.Add(this.textBoxNFTID_DFT);
            this.panelDFT.Controls.Add(this.textBoxND_DFT);
            this.panelDFT.Location = new System.Drawing.Point(50, 15);
            this.panelDFT.Name = "panelDFT";
            this.panelDFT.Size = new System.Drawing.Size(786, 183);
            this.panelDFT.TabIndex = 83;
            this.panelDFT.Visible = false;
            // 
            // checkBoxPro_DFT2
            // 
            this.checkBoxPro_DFT2.AutoSize = true;
            this.checkBoxPro_DFT2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPro_DFT2.Location = new System.Drawing.Point(690, 150);
            this.checkBoxPro_DFT2.Name = "checkBoxPro_DFT2";
            this.checkBoxPro_DFT2.Size = new System.Drawing.Size(70, 18);
            this.checkBoxPro_DFT2.TabIndex = 156;
            this.checkBoxPro_DFT2.Text = "Prorated";
            this.checkBoxPro_DFT2.UseVisualStyleBackColor = true;
            // 
            // checkBoxAcc_DFT2
            // 
            this.checkBoxAcc_DFT2.AutoSize = true;
            this.checkBoxAcc_DFT2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAcc_DFT2.Location = new System.Drawing.Point(592, 150);
            this.checkBoxAcc_DFT2.Name = "checkBoxAcc_DFT2";
            this.checkBoxAcc_DFT2.Size = new System.Drawing.Size(93, 18);
            this.checkBoxAcc_DFT2.TabIndex = 155;
            this.checkBoxAcc_DFT2.Text = "Accumulative";
            this.checkBoxAcc_DFT2.UseVisualStyleBackColor = true;
            // 
            // radioButtonNDOWN_DFT
            // 
            this.radioButtonNDOWN_DFT.AutoSize = true;
            this.radioButtonNDOWN_DFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNDOWN_DFT.Location = new System.Drawing.Point(689, 123);
            this.radioButtonNDOWN_DFT.Name = "radioButtonNDOWN_DFT";
            this.radioButtonNDOWN_DFT.Size = new System.Drawing.Size(55, 18);
            this.radioButtonNDOWN_DFT.TabIndex = 154;
            this.radioButtonNDOWN_DFT.TabStop = true;
            this.radioButtonNDOWN_DFT.Text = "Down";
            this.radioButtonNDOWN_DFT.UseVisualStyleBackColor = true;
            this.radioButtonNDOWN_DFT.CheckedChanged += new System.EventHandler(this.radioButtonNDOWN_DFT_CheckedChanged);
            // 
            // numericUpDownNRA_DFT
            // 
            this.numericUpDownNRA_DFT.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numericUpDownNRA_DFT.Font = new System.Drawing.Font("Google Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownNRA_DFT.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownNRA_DFT.Location = new System.Drawing.Point(270, 115);
            this.numericUpDownNRA_DFT.Name = "numericUpDownNRA_DFT";
            this.numericUpDownNRA_DFT.ReadOnly = true;
            this.numericUpDownNRA_DFT.Size = new System.Drawing.Size(234, 22);
            this.numericUpDownNRA_DFT.TabIndex = 153;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.ForeColor = System.Drawing.Color.Red;
            this.label112.Location = new System.Drawing.Point(664, 12);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(15, 18);
            this.label112.TabIndex = 152;
            this.label112.Text = "*";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.ForeColor = System.Drawing.Color.Red;
            this.label124.Location = new System.Drawing.Point(633, 92);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(15, 18);
            this.label124.TabIndex = 150;
            this.label124.Text = "*";
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label166.ForeColor = System.Drawing.Color.Red;
            this.label166.Location = new System.Drawing.Point(476, 88);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(15, 18);
            this.label166.TabIndex = 149;
            this.label166.Text = "*";
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label177.ForeColor = System.Drawing.Color.Red;
            this.label177.Location = new System.Drawing.Point(214, 86);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(15, 18);
            this.label177.TabIndex = 148;
            this.label177.Text = "*";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label179.ForeColor = System.Drawing.Color.Red;
            this.label179.Location = new System.Drawing.Point(214, 12);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(15, 18);
            this.label179.TabIndex = 147;
            this.label179.Text = "*";
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label181.Location = new System.Drawing.Point(265, 86);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(107, 14);
            this.label181.TabIndex = 146;
            this.label181.Text = "Rounding Accuracy:";
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label182.Location = new System.Drawing.Point(469, 45);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(18, 14);
            this.label182.TabIndex = 145;
            this.label182.Text = "to";
            // 
            // metroDateTimeNTO_DFT
            // 
            this.metroDateTimeNTO_DFT.Location = new System.Drawing.Point(487, 36);
            this.metroDateTimeNTO_DFT.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeNTO_DFT.Name = "metroDateTimeNTO_DFT";
            this.metroDateTimeNTO_DFT.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeNTO_DFT.TabIndex = 144;
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label183.Location = new System.Drawing.Point(262, 7);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(78, 14);
            this.label183.TabIndex = 143;
            this.label183.Text = "Effective Date";
            // 
            // metroDateTimeNED_DFT
            // 
            this.metroDateTimeNED_DFT.Location = new System.Drawing.Point(267, 36);
            this.metroDateTimeNED_DFT.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeNED_DFT.Name = "metroDateTimeNED_DFT";
            this.metroDateTimeNED_DFT.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeNED_DFT.TabIndex = 142;
            // 
            // checkBoxA_DFT
            // 
            this.checkBoxA_DFT.AutoSize = true;
            this.checkBoxA_DFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxA_DFT.Location = new System.Drawing.Point(529, 150);
            this.checkBoxA_DFT.Name = "checkBoxA_DFT";
            this.checkBoxA_DFT.Size = new System.Drawing.Size(57, 18);
            this.checkBoxA_DFT.TabIndex = 141;
            this.checkBoxA_DFT.Text = "Active";
            this.checkBoxA_DFT.UseVisualStyleBackColor = true;
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label184.Location = new System.Drawing.Point(523, 94);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(100, 14);
            this.label184.TabIndex = 140;
            this.label184.Text = "Rounding Method:";
            // 
            // radioButtonNUP_DFT
            // 
            this.radioButtonNUP_DFT.AutoSize = true;
            this.radioButtonNUP_DFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNUP_DFT.Location = new System.Drawing.Point(620, 123);
            this.radioButtonNUP_DFT.Name = "radioButtonNUP_DFT";
            this.radioButtonNUP_DFT.Size = new System.Drawing.Size(39, 18);
            this.radioButtonNUP_DFT.TabIndex = 139;
            this.radioButtonNUP_DFT.TabStop = true;
            this.radioButtonNUP_DFT.Text = "Up";
            this.radioButtonNUP_DFT.UseVisualStyleBackColor = true;
            this.radioButtonNUP_DFT.CheckedChanged += new System.EventHandler(this.radioButtonNUP_DFT_CheckedChanged);
            // 
            // radioButtonExactNDFT
            // 
            this.radioButtonExactNDFT.AutoSize = true;
            this.radioButtonExactNDFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonExactNDFT.Location = new System.Drawing.Point(528, 123);
            this.radioButtonExactNDFT.Name = "radioButtonExactNDFT";
            this.radioButtonExactNDFT.Size = new System.Drawing.Size(52, 18);
            this.radioButtonExactNDFT.TabIndex = 138;
            this.radioButtonExactNDFT.TabStop = true;
            this.radioButtonExactNDFT.Text = "Exact";
            this.radioButtonExactNDFT.UseVisualStyleBackColor = true;
            this.radioButtonExactNDFT.CheckedChanged += new System.EventHandler(this.radioButtonExactNDFT_CheckedChanged);
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label185.Location = new System.Drawing.Point(3, 84);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(54, 14);
            this.label185.TabIndex = 137;
            this.label185.Text = "Discount:";
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label186.Location = new System.Drawing.Point(3, 10);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(101, 14);
            this.label186.TabIndex = 136;
            this.label186.Text = "New Fare Table ID:";
            // 
            // textBoxNFTID_DFT
            // 
            this.textBoxNFTID_DFT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNFTID_DFT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNFTID_DFT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNFTID_DFT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNFTID_DFT.Location = new System.Drawing.Point(8, 39);
            this.textBoxNFTID_DFT.Name = "textBoxNFTID_DFT";
            this.textBoxNFTID_DFT.Size = new System.Drawing.Size(234, 24);
            this.textBoxNFTID_DFT.TabIndex = 134;
            // 
            // textBoxND_DFT
            // 
            this.textBoxND_DFT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxND_DFT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxND_DFT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxND_DFT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxND_DFT.Location = new System.Drawing.Point(8, 112);
            this.textBoxND_DFT.Name = "textBoxND_DFT";
            this.textBoxND_DFT.Size = new System.Drawing.Size(234, 24);
            this.textBoxND_DFT.TabIndex = 135;
            // 
            // buttonexpdft
            // 
            this.buttonexpdft.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpdft.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpdft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpdft.Location = new System.Drawing.Point(703, 271);
            this.buttonexpdft.Name = "buttonexpdft";
            this.buttonexpdft.Size = new System.Drawing.Size(133, 45);
            this.buttonexpdft.TabIndex = 135;
            this.buttonexpdft.Text = "Export";
            this.buttonexpdft.UseVisualStyleBackColor = false;
            this.buttonexpdft.Click += new System.EventHandler(this.buttonexpdft_Click);
            // 
            // buttonSaveDFT
            // 
            this.buttonSaveDFT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveDFT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveDFT.Location = new System.Drawing.Point(564, 216);
            this.buttonSaveDFT.Name = "buttonSaveDFT";
            this.buttonSaveDFT.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveDFT.TabIndex = 134;
            this.buttonSaveDFT.Text = "Save";
            this.buttonSaveDFT.UseVisualStyleBackColor = true;
            this.buttonSaveDFT.Visible = false;
            this.buttonSaveDFT.Click += new System.EventHandler(this.buttonSaveDFT_Click);
            // 
            // radioButtonDFT_D
            // 
            this.radioButtonDFT_D.AutoSize = true;
            this.radioButtonDFT_D.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDFT_D.Location = new System.Drawing.Point(739, 138);
            this.radioButtonDFT_D.Name = "radioButtonDFT_D";
            this.radioButtonDFT_D.Size = new System.Drawing.Size(55, 18);
            this.radioButtonDFT_D.TabIndex = 133;
            this.radioButtonDFT_D.TabStop = true;
            this.radioButtonDFT_D.Text = "Down";
            this.radioButtonDFT_D.UseVisualStyleBackColor = true;
            this.radioButtonDFT_D.CheckedChanged += new System.EventHandler(this.radioButtonDFT_D_CheckedChanged);
            // 
            // textBoxDFT_RA
            // 
            this.textBoxDFT_RA.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBoxDFT_RA.Font = new System.Drawing.Font("Google Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDFT_RA.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.textBoxDFT_RA.Location = new System.Drawing.Point(320, 130);
            this.textBoxDFT_RA.Name = "textBoxDFT_RA";
            this.textBoxDFT_RA.ReadOnly = true;
            this.textBoxDFT_RA.Size = new System.Drawing.Size(234, 22);
            this.textBoxDFT_RA.TabIndex = 132;
            // 
            // buttonDELDFT
            // 
            this.buttonDELDFT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELDFT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELDFT.Location = new System.Drawing.Point(1, 275);
            this.buttonDELDFT.Name = "buttonDELDFT";
            this.buttonDELDFT.Size = new System.Drawing.Size(111, 41);
            this.buttonDELDFT.TabIndex = 130;
            this.buttonDELDFT.Text = "Delete";
            this.buttonDELDFT.UseVisualStyleBackColor = true;
            this.buttonDELDFT.Click += new System.EventHandler(this.buttonDELDFT_Click);
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.ForeColor = System.Drawing.Color.Red;
            this.label94.Location = new System.Drawing.Point(714, 27);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(15, 18);
            this.label94.TabIndex = 106;
            this.label94.Text = "*";
            // 
            // dgvDFT
            // 
            this.dgvDFT.AllowUserToAddRows = false;
            this.dgvDFT.AllowUserToResizeRows = false;
            this.dgvDFT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDFT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDFT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDFT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDFT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle856.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle856.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle856.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle856.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle856.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle856.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle856.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDFT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle856;
            this.dgvDFT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle857.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle857.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle857.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle857.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle857.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle857.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle857.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDFT.DefaultCellStyle = dataGridViewCellStyle857;
            this.dgvDFT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDFT.EnableHeadersVisualStyles = false;
            this.dgvDFT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDFT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDFT.Location = new System.Drawing.Point(0, 294);
            this.dgvDFT.MultiSelect = false;
            this.dgvDFT.Name = "dgvDFT";
            this.dgvDFT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle858.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle858.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle858.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle858.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle858.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle858.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle858.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDFT.RowHeadersDefaultCellStyle = dataGridViewCellStyle858;
            this.dgvDFT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDFT.RowTemplate.Height = 33;
            this.dgvDFT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDFT.Size = new System.Drawing.Size(862, 271);
            this.dgvDFT.TabIndex = 129;
            this.dgvDFT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDFT_CellDoubleClick);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.Color.Red;
            this.label92.Location = new System.Drawing.Point(683, 107);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(15, 18);
            this.label92.TabIndex = 104;
            this.label92.Text = "*";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.Color.Red;
            this.label89.Location = new System.Drawing.Point(526, 103);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(15, 18);
            this.label89.TabIndex = 103;
            this.label89.Text = "*";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.ForeColor = System.Drawing.Color.Red;
            this.label90.Location = new System.Drawing.Point(264, 101);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(15, 18);
            this.label90.TabIndex = 102;
            this.label90.Text = "*";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.ForeColor = System.Drawing.Color.Red;
            this.label91.Location = new System.Drawing.Point(264, 27);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(15, 18);
            this.label91.TabIndex = 101;
            this.label91.Text = "*";
            // 
            // buttonDFT_Create
            // 
            this.buttonDFT_Create.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonDFT_Create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDFT_Create.Location = new System.Drawing.Point(703, 216);
            this.buttonDFT_Create.Name = "buttonDFT_Create";
            this.buttonDFT_Create.Size = new System.Drawing.Size(133, 45);
            this.buttonDFT_Create.TabIndex = 100;
            this.buttonDFT_Create.Text = "Create";
            this.buttonDFT_Create.UseVisualStyleBackColor = true;
            this.buttonDFT_Create.Click += new System.EventHandler(this.buttonDFT_Create_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(315, 101);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(107, 14);
            this.label56.TabIndex = 99;
            this.label56.Text = "Rounding Accuracy:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(519, 60);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(18, 14);
            this.label55.TabIndex = 97;
            this.label55.Text = "to";
            // 
            // metroDateTimeDFT_T
            // 
            this.metroDateTimeDFT_T.Location = new System.Drawing.Point(537, 51);
            this.metroDateTimeDFT_T.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeDFT_T.Name = "metroDateTimeDFT_T";
            this.metroDateTimeDFT_T.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeDFT_T.TabIndex = 96;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(312, 22);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(78, 14);
            this.label54.TabIndex = 95;
            this.label54.Text = "Effective Date";
            // 
            // metroDateTimeDFT_F
            // 
            this.metroDateTimeDFT_F.Location = new System.Drawing.Point(317, 51);
            this.metroDateTimeDFT_F.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeDFT_F.Name = "metroDateTimeDFT_F";
            this.metroDateTimeDFT_F.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeDFT_F.TabIndex = 94;
            this.metroDateTimeDFT_F.ValueChanged += new System.EventHandler(this.metroDateTimeDFT_F_ValueChanged);
            // 
            // checkBoxDFT_ACT
            // 
            this.checkBoxDFT_ACT.AutoSize = true;
            this.checkBoxDFT_ACT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDFT_ACT.Location = new System.Drawing.Point(578, 171);
            this.checkBoxDFT_ACT.Name = "checkBoxDFT_ACT";
            this.checkBoxDFT_ACT.Size = new System.Drawing.Size(57, 18);
            this.checkBoxDFT_ACT.TabIndex = 93;
            this.checkBoxDFT_ACT.Text = "Active";
            this.checkBoxDFT_ACT.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(573, 109);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(100, 14);
            this.label50.TabIndex = 92;
            this.label50.Text = "Rounding Method:";
            // 
            // radioButtonDFT_U
            // 
            this.radioButtonDFT_U.AutoSize = true;
            this.radioButtonDFT_U.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDFT_U.Location = new System.Drawing.Point(670, 138);
            this.radioButtonDFT_U.Name = "radioButtonDFT_U";
            this.radioButtonDFT_U.Size = new System.Drawing.Size(39, 18);
            this.radioButtonDFT_U.TabIndex = 91;
            this.radioButtonDFT_U.TabStop = true;
            this.radioButtonDFT_U.Text = "Up";
            this.radioButtonDFT_U.UseVisualStyleBackColor = true;
            this.radioButtonDFT_U.CheckedChanged += new System.EventHandler(this.radioButtonDFT_U_CheckedChanged);
            // 
            // radioButtonDFT_E
            // 
            this.radioButtonDFT_E.AutoSize = true;
            this.radioButtonDFT_E.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDFT_E.Location = new System.Drawing.Point(578, 138);
            this.radioButtonDFT_E.Name = "radioButtonDFT_E";
            this.radioButtonDFT_E.Size = new System.Drawing.Size(52, 18);
            this.radioButtonDFT_E.TabIndex = 90;
            this.radioButtonDFT_E.TabStop = true;
            this.radioButtonDFT_E.Text = "Exact";
            this.radioButtonDFT_E.UseVisualStyleBackColor = true;
            this.radioButtonDFT_E.CheckedChanged += new System.EventHandler(this.radioButtonDFT_E_CheckedChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(53, 99);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(54, 14);
            this.label51.TabIndex = 89;
            this.label51.Text = "Discount:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(53, 25);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(75, 14);
            this.label52.TabIndex = 88;
            this.label52.Text = "Fare Table ID:";
            // 
            // textBoxDFT_FTB
            // 
            this.textBoxDFT_FTB.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDFT_FTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDFT_FTB.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDFT_FTB.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDFT_FTB.Location = new System.Drawing.Point(58, 54);
            this.textBoxDFT_FTB.Name = "textBoxDFT_FTB";
            this.textBoxDFT_FTB.Size = new System.Drawing.Size(234, 24);
            this.textBoxDFT_FTB.TabIndex = 86;
            this.textBoxDFT_FTB.TextChanged += new System.EventHandler(this.textBoxDFT_FTB_TextChanged);
            this.textBoxDFT_FTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // textBoxDFT_DISC
            // 
            this.textBoxDFT_DISC.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDFT_DISC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDFT_DISC.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDFT_DISC.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDFT_DISC.Location = new System.Drawing.Point(58, 127);
            this.textBoxDFT_DISC.Name = "textBoxDFT_DISC";
            this.textBoxDFT_DISC.Size = new System.Drawing.Size(234, 24);
            this.textBoxDFT_DISC.TabIndex = 87;
            this.textBoxDFT_DISC.TextChanged += new System.EventHandler(this.textBoxDFT_DISC_TextChanged);
            this.textBoxDFT_DISC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // checkBoxPro_DFT
            // 
            this.checkBoxPro_DFT.AutoSize = true;
            this.checkBoxPro_DFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPro_DFT.Location = new System.Drawing.Point(739, 171);
            this.checkBoxPro_DFT.Name = "checkBoxPro_DFT";
            this.checkBoxPro_DFT.Size = new System.Drawing.Size(70, 18);
            this.checkBoxPro_DFT.TabIndex = 158;
            this.checkBoxPro_DFT.Text = "Prorated";
            this.checkBoxPro_DFT.UseVisualStyleBackColor = true;
            // 
            // checkBoxAcc_DFT
            // 
            this.checkBoxAcc_DFT.AutoSize = true;
            this.checkBoxAcc_DFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAcc_DFT.Location = new System.Drawing.Point(641, 171);
            this.checkBoxAcc_DFT.Name = "checkBoxAcc_DFT";
            this.checkBoxAcc_DFT.Size = new System.Drawing.Size(93, 18);
            this.checkBoxAcc_DFT.TabIndex = 157;
            this.checkBoxAcc_DFT.Text = "Accumulative";
            this.checkBoxAcc_DFT.UseVisualStyleBackColor = true;
            // 
            // tb7
            // 
            this.tb7.AllowDrop = true;
            this.tb7.AutoScroll = true;
            this.tb7.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tb7.Controls.Add(this.panel6);
            this.tb7.Location = new System.Drawing.Point(4, 34);
            this.tb7.Name = "tb7";
            this.tb7.Size = new System.Drawing.Size(862, 565);
            this.tb7.TabIndex = 6;
            this.tb7.Text = "DistanceBasedFaresTable";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.buttonexpdbft);
            this.panel6.Controls.Add(this.panelDBFT);
            this.panel6.Controls.Add(this.checkBoxPro_DBFT);
            this.panel6.Controls.Add(this.checkBoxAcc_DBFT);
            this.panel6.Controls.Add(this.buttonSAVE_DBFT);
            this.panel6.Controls.Add(this.buttonDELDBFT);
            this.panel6.Controls.Add(this.label71);
            this.panel6.Controls.Add(this.label70);
            this.panel6.Controls.Add(this.dgvDBFT);
            this.panel6.Controls.Add(this.label68);
            this.panel6.Controls.Add(this.label69);
            this.panel6.Controls.Add(this.buttonDBFT_Create);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.textBoxDBFT_BFD);
            this.panel6.Controls.Add(this.label58);
            this.panel6.Controls.Add(this.metroDateTimeDBFT_T);
            this.panel6.Controls.Add(this.label59);
            this.panel6.Controls.Add(this.metroDateTimeDBFT_F);
            this.panel6.Controls.Add(this.checkBoxDBFT_A);
            this.panel6.Controls.Add(this.label61);
            this.panel6.Controls.Add(this.label62);
            this.panel6.Controls.Add(this.textBoxDBFT_FTI);
            this.panel6.Controls.Add(this.textBoxDBFT_FA);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(862, 565);
            this.panel6.TabIndex = 66;
            // 
            // buttonexpdbft
            // 
            this.buttonexpdbft.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpdbft.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpdbft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpdbft.Location = new System.Drawing.Point(711, 245);
            this.buttonexpdbft.Name = "buttonexpdbft";
            this.buttonexpdbft.Size = new System.Drawing.Size(133, 45);
            this.buttonexpdbft.TabIndex = 138;
            this.buttonexpdbft.Text = "Export";
            this.buttonexpdbft.UseVisualStyleBackColor = false;
            this.buttonexpdbft.Click += new System.EventHandler(this.buttonexpdbft_Click);
            // 
            // panelDBFT
            // 
            this.panelDBFT.Controls.Add(this.checkBoxPro_DBFT2);
            this.panelDBFT.Controls.Add(this.checkBoxAcc_DBFT2);
            this.panelDBFT.Controls.Add(this.label187);
            this.panelDBFT.Controls.Add(this.label188);
            this.panelDBFT.Controls.Add(this.label189);
            this.panelDBFT.Controls.Add(this.label190);
            this.panelDBFT.Controls.Add(this.label191);
            this.panelDBFT.Controls.Add(this.textBoxNBFD_DBFT);
            this.panelDBFT.Controls.Add(this.label192);
            this.panelDBFT.Controls.Add(this.metroDateTimeNTO_DBFT);
            this.panelDBFT.Controls.Add(this.label193);
            this.panelDBFT.Controls.Add(this.metroDateTimeNED_DBFT);
            this.panelDBFT.Controls.Add(this.checkBoxA_DBFT);
            this.panelDBFT.Controls.Add(this.label194);
            this.panelDBFT.Controls.Add(this.label195);
            this.panelDBFT.Controls.Add(this.textBoxNFTID_DBFT);
            this.panelDBFT.Controls.Add(this.textBoxNFA_DBFT);
            this.panelDBFT.Location = new System.Drawing.Point(63, 10);
            this.panelDBFT.Name = "panelDBFT";
            this.panelDBFT.Size = new System.Drawing.Size(773, 175);
            this.panelDBFT.TabIndex = 83;
            this.panelDBFT.Visible = false;
            // 
            // checkBoxPro_DBFT2
            // 
            this.checkBoxPro_DBFT2.AutoSize = true;
            this.checkBoxPro_DBFT2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPro_DBFT2.Location = new System.Drawing.Point(609, 125);
            this.checkBoxPro_DBFT2.Name = "checkBoxPro_DBFT2";
            this.checkBoxPro_DBFT2.Size = new System.Drawing.Size(70, 18);
            this.checkBoxPro_DBFT2.TabIndex = 138;
            this.checkBoxPro_DBFT2.Text = "Prorated";
            this.checkBoxPro_DBFT2.UseVisualStyleBackColor = true;
            // 
            // checkBoxAcc_DBFT2
            // 
            this.checkBoxAcc_DBFT2.AutoSize = true;
            this.checkBoxAcc_DBFT2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAcc_DBFT2.Location = new System.Drawing.Point(511, 125);
            this.checkBoxAcc_DBFT2.Name = "checkBoxAcc_DBFT2";
            this.checkBoxAcc_DBFT2.Size = new System.Drawing.Size(93, 18);
            this.checkBoxAcc_DBFT2.TabIndex = 137;
            this.checkBoxAcc_DBFT2.Text = "Accumulative";
            this.checkBoxAcc_DBFT2.UseVisualStyleBackColor = true;
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label187.ForeColor = System.Drawing.Color.Red;
            this.label187.Location = new System.Drawing.Point(661, 13);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(15, 18);
            this.label187.TabIndex = 136;
            this.label187.Text = "*";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label188.ForeColor = System.Drawing.Color.Red;
            this.label188.Location = new System.Drawing.Point(477, 83);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(15, 18);
            this.label188.TabIndex = 135;
            this.label188.Text = "*";
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label189.ForeColor = System.Drawing.Color.Red;
            this.label189.Location = new System.Drawing.Point(215, 79);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(15, 18);
            this.label189.TabIndex = 134;
            this.label189.Text = "*";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label190.ForeColor = System.Drawing.Color.Red;
            this.label190.Location = new System.Drawing.Point(215, 5);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(15, 18);
            this.label190.TabIndex = 133;
            this.label190.Text = "*";
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label191.Location = new System.Drawing.Point(264, 88);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(131, 14);
            this.label191.TabIndex = 131;
            this.label191.Text = "New Base Fare Distance:";
            // 
            // textBoxNBFD_DBFT
            // 
            this.textBoxNBFD_DBFT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNBFD_DBFT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNBFD_DBFT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNBFD_DBFT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNBFD_DBFT.Location = new System.Drawing.Point(269, 116);
            this.textBoxNBFD_DBFT.Name = "textBoxNBFD_DBFT";
            this.textBoxNBFD_DBFT.Size = new System.Drawing.Size(234, 24);
            this.textBoxNBFD_DBFT.TabIndex = 130;
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label192.Location = new System.Drawing.Point(471, 51);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(18, 14);
            this.label192.TabIndex = 129;
            this.label192.Text = "to";
            // 
            // metroDateTimeNTO_DBFT
            // 
            this.metroDateTimeNTO_DBFT.Location = new System.Drawing.Point(489, 42);
            this.metroDateTimeNTO_DBFT.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeNTO_DBFT.Name = "metroDateTimeNTO_DBFT";
            this.metroDateTimeNTO_DBFT.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeNTO_DBFT.TabIndex = 128;
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label193.Location = new System.Drawing.Point(264, 13);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(107, 14);
            this.label193.TabIndex = 127;
            this.label193.Text = "New Effective Date:";
            // 
            // metroDateTimeNED_DBFT
            // 
            this.metroDateTimeNED_DBFT.Location = new System.Drawing.Point(268, 42);
            this.metroDateTimeNED_DBFT.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeNED_DBFT.Name = "metroDateTimeNED_DBFT";
            this.metroDateTimeNED_DBFT.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeNED_DBFT.TabIndex = 126;
            // 
            // checkBoxA_DBFT
            // 
            this.checkBoxA_DBFT.AutoSize = true;
            this.checkBoxA_DBFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxA_DBFT.Location = new System.Drawing.Point(511, 92);
            this.checkBoxA_DBFT.Name = "checkBoxA_DBFT";
            this.checkBoxA_DBFT.Size = new System.Drawing.Size(57, 18);
            this.checkBoxA_DBFT.TabIndex = 125;
            this.checkBoxA_DBFT.Text = "Active";
            this.checkBoxA_DBFT.UseVisualStyleBackColor = true;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label194.Location = new System.Drawing.Point(3, 87);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(101, 14);
            this.label194.TabIndex = 124;
            this.label194.Text = "New Fare Amount:";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label195.Location = new System.Drawing.Point(3, 13);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(101, 14);
            this.label195.TabIndex = 123;
            this.label195.Text = "New Fare Table ID:";
            // 
            // textBoxNFTID_DBFT
            // 
            this.textBoxNFTID_DBFT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNFTID_DBFT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNFTID_DBFT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNFTID_DBFT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNFTID_DBFT.Location = new System.Drawing.Point(8, 42);
            this.textBoxNFTID_DBFT.Name = "textBoxNFTID_DBFT";
            this.textBoxNFTID_DBFT.Size = new System.Drawing.Size(234, 24);
            this.textBoxNFTID_DBFT.TabIndex = 121;
            // 
            // textBoxNFA_DBFT
            // 
            this.textBoxNFA_DBFT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNFA_DBFT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNFA_DBFT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNFA_DBFT.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNFA_DBFT.Location = new System.Drawing.Point(8, 115);
            this.textBoxNFA_DBFT.Name = "textBoxNFA_DBFT";
            this.textBoxNFA_DBFT.Size = new System.Drawing.Size(234, 24);
            this.textBoxNFA_DBFT.TabIndex = 122;
            // 
            // checkBoxPro_DBFT
            // 
            this.checkBoxPro_DBFT.AutoSize = true;
            this.checkBoxPro_DBFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPro_DBFT.Location = new System.Drawing.Point(708, 132);
            this.checkBoxPro_DBFT.Name = "checkBoxPro_DBFT";
            this.checkBoxPro_DBFT.Size = new System.Drawing.Size(70, 18);
            this.checkBoxPro_DBFT.TabIndex = 137;
            this.checkBoxPro_DBFT.Text = "Prorated";
            this.checkBoxPro_DBFT.UseVisualStyleBackColor = true;
            // 
            // checkBoxAcc_DBFT
            // 
            this.checkBoxAcc_DBFT.AutoSize = true;
            this.checkBoxAcc_DBFT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAcc_DBFT.Location = new System.Drawing.Point(597, 130);
            this.checkBoxAcc_DBFT.Name = "checkBoxAcc_DBFT";
            this.checkBoxAcc_DBFT.Size = new System.Drawing.Size(93, 18);
            this.checkBoxAcc_DBFT.TabIndex = 136;
            this.checkBoxAcc_DBFT.Text = "Accumulative";
            this.checkBoxAcc_DBFT.UseVisualStyleBackColor = true;
            // 
            // buttonSAVE_DBFT
            // 
            this.buttonSAVE_DBFT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVE_DBFT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVE_DBFT.Location = new System.Drawing.Point(572, 191);
            this.buttonSAVE_DBFT.Name = "buttonSAVE_DBFT";
            this.buttonSAVE_DBFT.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVE_DBFT.TabIndex = 135;
            this.buttonSAVE_DBFT.Text = "Save";
            this.buttonSAVE_DBFT.UseVisualStyleBackColor = true;
            this.buttonSAVE_DBFT.Visible = false;
            this.buttonSAVE_DBFT.Click += new System.EventHandler(this.buttonSAVE_DBFT_Click);
            // 
            // buttonDELDBFT
            // 
            this.buttonDELDBFT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELDBFT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELDBFT.Location = new System.Drawing.Point(1, 261);
            this.buttonDELDBFT.Name = "buttonDELDBFT";
            this.buttonDELDBFT.Size = new System.Drawing.Size(111, 41);
            this.buttonDELDBFT.TabIndex = 130;
            this.buttonDELDBFT.Text = "Delete";
            this.buttonDELDBFT.UseVisualStyleBackColor = true;
            this.buttonDELDBFT.Click += new System.EventHandler(this.buttonDELDBFT_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.Red;
            this.label71.Location = new System.Drawing.Point(724, 23);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(15, 18);
            this.label71.TabIndex = 120;
            this.label71.Text = "*";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.Red;
            this.label70.Location = new System.Drawing.Point(540, 93);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(15, 18);
            this.label70.TabIndex = 119;
            this.label70.Text = "*";
            // 
            // dgvDBFT
            // 
            this.dgvDBFT.AllowUserToAddRows = false;
            this.dgvDBFT.AllowUserToResizeRows = false;
            this.dgvDBFT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDBFT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBFT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDBFT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDBFT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle859.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle859.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle859.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle859.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle859.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle859.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle859.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBFT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle859;
            this.dgvDBFT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle860.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle860.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle860.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle860.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle860.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle860.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle860.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDBFT.DefaultCellStyle = dataGridViewCellStyle860;
            this.dgvDBFT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDBFT.EnableHeadersVisualStyles = false;
            this.dgvDBFT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDBFT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBFT.Location = new System.Drawing.Point(0, 279);
            this.dgvDBFT.MultiSelect = false;
            this.dgvDBFT.Name = "dgvDBFT";
            this.dgvDBFT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle861.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle861.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle861.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle861.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle861.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle861.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle861.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBFT.RowHeadersDefaultCellStyle = dataGridViewCellStyle861;
            this.dgvDBFT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDBFT.RowTemplate.Height = 33;
            this.dgvDBFT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDBFT.Size = new System.Drawing.Size(862, 286);
            this.dgvDBFT.TabIndex = 125;
            this.dgvDBFT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDBFT_CellDoubleClick);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Red;
            this.label68.Location = new System.Drawing.Point(278, 89);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(15, 18);
            this.label68.TabIndex = 118;
            this.label68.Text = "*";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Red;
            this.label69.Location = new System.Drawing.Point(278, 15);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(15, 18);
            this.label69.TabIndex = 117;
            this.label69.Text = "*";
            // 
            // buttonDBFT_Create
            // 
            this.buttonDBFT_Create.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonDBFT_Create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBFT_Create.Location = new System.Drawing.Point(711, 191);
            this.buttonDBFT_Create.Name = "buttonDBFT_Create";
            this.buttonDBFT_Create.Size = new System.Drawing.Size(133, 45);
            this.buttonDBFT_Create.TabIndex = 116;
            this.buttonDBFT_Create.Text = "Create";
            this.buttonDBFT_Create.UseVisualStyleBackColor = true;
            this.buttonDBFT_Create.Click += new System.EventHandler(this.buttonDBFT_Create_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(327, 98);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(105, 14);
            this.label57.TabIndex = 115;
            this.label57.Text = "Base Fare Distance:";
            // 
            // textBoxDBFT_BFD
            // 
            this.textBoxDBFT_BFD.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBFT_BFD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBFT_BFD.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBFT_BFD.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDBFT_BFD.Location = new System.Drawing.Point(332, 126);
            this.textBoxDBFT_BFD.Name = "textBoxDBFT_BFD";
            this.textBoxDBFT_BFD.Size = new System.Drawing.Size(234, 24);
            this.textBoxDBFT_BFD.TabIndex = 114;
            this.textBoxDBFT_BFD.TextChanged += new System.EventHandler(this.textBoxDBFT_BFD_TextChanged);
            this.textBoxDBFT_BFD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(534, 61);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(18, 14);
            this.label58.TabIndex = 113;
            this.label58.Text = "to";
            // 
            // metroDateTimeDBFT_T
            // 
            this.metroDateTimeDBFT_T.Location = new System.Drawing.Point(552, 52);
            this.metroDateTimeDBFT_T.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTimeDBFT_T.Name = "metroDateTimeDBFT_T";
            this.metroDateTimeDBFT_T.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeDBFT_T.TabIndex = 112;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(327, 23);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(78, 14);
            this.label59.TabIndex = 111;
            this.label59.Text = "Effective Date";
            // 
            // metroDateTimeDBFT_F
            // 
            this.metroDateTimeDBFT_F.Location = new System.Drawing.Point(331, 52);
            this.metroDateTimeDBFT_F.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTimeDBFT_F.Name = "metroDateTimeDBFT_F";
            this.metroDateTimeDBFT_F.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeDBFT_F.TabIndex = 110;
            this.metroDateTimeDBFT_F.ValueChanged += new System.EventHandler(this.metroDateTimeDBFT_F_ValueChanged);
            // 
            // checkBoxDBFT_A
            // 
            this.checkBoxDBFT_A.AutoSize = true;
            this.checkBoxDBFT_A.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDBFT_A.Location = new System.Drawing.Point(597, 98);
            this.checkBoxDBFT_A.Name = "checkBoxDBFT_A";
            this.checkBoxDBFT_A.Size = new System.Drawing.Size(57, 18);
            this.checkBoxDBFT_A.TabIndex = 109;
            this.checkBoxDBFT_A.Text = "Active";
            this.checkBoxDBFT_A.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(66, 97);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(75, 14);
            this.label61.TabIndex = 105;
            this.label61.Text = "Fare Amount:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(66, 23);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(75, 14);
            this.label62.TabIndex = 104;
            this.label62.Text = "Fare Table ID:";
            // 
            // textBoxDBFT_FTI
            // 
            this.textBoxDBFT_FTI.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBFT_FTI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBFT_FTI.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBFT_FTI.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDBFT_FTI.Location = new System.Drawing.Point(71, 52);
            this.textBoxDBFT_FTI.Name = "textBoxDBFT_FTI";
            this.textBoxDBFT_FTI.Size = new System.Drawing.Size(234, 24);
            this.textBoxDBFT_FTI.TabIndex = 102;
            this.textBoxDBFT_FTI.TextChanged += new System.EventHandler(this.textBoxDBFT_FTI_TextChanged);
            this.textBoxDBFT_FTI.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // textBoxDBFT_FA
            // 
            this.textBoxDBFT_FA.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBFT_FA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBFT_FA.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBFT_FA.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxDBFT_FA.Location = new System.Drawing.Point(71, 125);
            this.textBoxDBFT_FA.Name = "textBoxDBFT_FA";
            this.textBoxDBFT_FA.Size = new System.Drawing.Size(234, 24);
            this.textBoxDBFT_FA.TabIndex = 103;
            this.textBoxDBFT_FA.TextChanged += new System.EventHandler(this.textBoxDBFT_FA_TextChanged);
            this.textBoxDBFT_FA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // tb8
            // 
            this.tb8.Controls.Add(this.panel7);
            this.tb8.Location = new System.Drawing.Point(4, 34);
            this.tb8.Name = "tb8";
            this.tb8.Size = new System.Drawing.Size(862, 565);
            this.tb8.TabIndex = 7;
            this.tb8.Text = "Route Based Fares";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel7.Controls.Add(this.buttonexprbf);
            this.panel7.Controls.Add(this.panelRBF);
            this.panel7.Controls.Add(this.buttonSAVERBF);
            this.panel7.Controls.Add(this.buttonDELRBF);
            this.panel7.Controls.Add(this.label83);
            this.panel7.Controls.Add(this.label82);
            this.panel7.Controls.Add(this.dgvRBF);
            this.panel7.Controls.Add(this.metroComboBoxRBF_BFI);
            this.panel7.Controls.Add(this.metroComboBoxRBF_RID);
            this.panel7.Controls.Add(this.buttonRBF_Gen);
            this.panel7.Controls.Add(this.label66);
            this.panel7.Controls.Add(this.label67);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(862, 565);
            this.panel7.TabIndex = 79;
            // 
            // buttonexprbf
            // 
            this.buttonexprbf.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexprbf.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexprbf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexprbf.Location = new System.Drawing.Point(711, 200);
            this.buttonexprbf.Name = "buttonexprbf";
            this.buttonexprbf.Size = new System.Drawing.Size(133, 45);
            this.buttonexprbf.TabIndex = 137;
            this.buttonexprbf.Text = "Export";
            this.buttonexprbf.UseVisualStyleBackColor = false;
            this.buttonexprbf.Click += new System.EventHandler(this.buttonexprbf_Click);
            // 
            // panelRBF
            // 
            this.panelRBF.Controls.Add(this.label246);
            this.panelRBF.Controls.Add(this.label247);
            this.panelRBF.Controls.Add(this.metroComboBoxRBF_BFI2);
            this.panelRBF.Controls.Add(this.metroComboBoxRBF_RID2);
            this.panelRBF.Controls.Add(this.label248);
            this.panelRBF.Controls.Add(this.label249);
            this.panelRBF.Location = new System.Drawing.Point(29, 20);
            this.panelRBF.Name = "panelRBF";
            this.panelRBF.Size = new System.Drawing.Size(674, 117);
            this.panelRBF.TabIndex = 83;
            this.panelRBF.Visible = false;
            // 
            // label246
            // 
            this.label246.AutoSize = true;
            this.label246.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label246.ForeColor = System.Drawing.Color.Red;
            this.label246.Location = new System.Drawing.Point(640, 62);
            this.label246.Name = "label246";
            this.label246.Size = new System.Drawing.Size(15, 18);
            this.label246.TabIndex = 125;
            this.label246.Text = "*";
            // 
            // label247
            // 
            this.label247.AutoSize = true;
            this.label247.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label247.ForeColor = System.Drawing.Color.Red;
            this.label247.Location = new System.Drawing.Point(640, 0);
            this.label247.Name = "label247";
            this.label247.Size = new System.Drawing.Size(15, 18);
            this.label247.TabIndex = 124;
            this.label247.Text = "*";
            // 
            // metroComboBoxRBF_BFI2
            // 
            this.metroComboBoxRBF_BFI2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRBF_BFI2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRBF_BFI2.FormattingEnabled = true;
            this.metroComboBoxRBF_BFI2.ItemHeight = 23;
            this.metroComboBoxRBF_BFI2.Location = new System.Drawing.Point(0, 88);
            this.metroComboBoxRBF_BFI2.Name = "metroComboBoxRBF_BFI2";
            this.metroComboBoxRBF_BFI2.Size = new System.Drawing.Size(668, 29);
            this.metroComboBoxRBF_BFI2.Sorted = true;
            this.metroComboBoxRBF_BFI2.TabIndex = 123;
            this.metroComboBoxRBF_BFI2.UseSelectable = true;
            this.metroComboBoxRBF_BFI2.UseStyleColors = true;
            this.metroComboBoxRBF_BFI2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRBF_BFI2_SelectedIndexChanged);
            // 
            // metroComboBoxRBF_RID2
            // 
            this.metroComboBoxRBF_RID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRBF_RID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRBF_RID2.FormattingEnabled = true;
            this.metroComboBoxRBF_RID2.ItemHeight = 23;
            this.metroComboBoxRBF_RID2.Location = new System.Drawing.Point(0, 29);
            this.metroComboBoxRBF_RID2.Name = "metroComboBoxRBF_RID2";
            this.metroComboBoxRBF_RID2.Size = new System.Drawing.Size(668, 29);
            this.metroComboBoxRBF_RID2.Sorted = true;
            this.metroComboBoxRBF_RID2.TabIndex = 122;
            this.metroComboBoxRBF_RID2.UseSelectable = true;
            this.metroComboBoxRBF_RID2.UseStyleColors = true;
            this.metroComboBoxRBF_RID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRBF_RID2_SelectedIndexChanged);
            // 
            // label248
            // 
            this.label248.AutoSize = true;
            this.label248.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label248.Location = new System.Drawing.Point(-5, 61);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(99, 14);
            this.label248.TabIndex = 121;
            this.label248.Text = "New Base Fare ID:";
            // 
            // label249
            // 
            this.label249.AutoSize = true;
            this.label249.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label249.Location = new System.Drawing.Point(-5, 0);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(127, 14);
            this.label249.TabIndex = 120;
            this.label249.Text = "New Route Long Name:";
            // 
            // buttonSAVERBF
            // 
            this.buttonSAVERBF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVERBF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVERBF.Location = new System.Drawing.Point(544, 149);
            this.buttonSAVERBF.Name = "buttonSAVERBF";
            this.buttonSAVERBF.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVERBF.TabIndex = 136;
            this.buttonSAVERBF.Text = "Save";
            this.buttonSAVERBF.UseVisualStyleBackColor = true;
            this.buttonSAVERBF.Visible = false;
            this.buttonSAVERBF.Click += new System.EventHandler(this.buttonSAVERBF_Click);
            // 
            // buttonDELRBF
            // 
            this.buttonDELRBF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELRBF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELRBF.Location = new System.Drawing.Point(2, 206);
            this.buttonDELRBF.Name = "buttonDELRBF";
            this.buttonDELRBF.Size = new System.Drawing.Size(111, 41);
            this.buttonDELRBF.TabIndex = 130;
            this.buttonDELRBF.Text = "Delete";
            this.buttonDELRBF.UseVisualStyleBackColor = true;
            this.buttonDELRBF.Click += new System.EventHandler(this.buttonDELRBF_Click);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.Color.Red;
            this.label83.Location = new System.Drawing.Point(669, 82);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(15, 18);
            this.label83.TabIndex = 119;
            this.label83.Text = "*";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.Red;
            this.label82.Location = new System.Drawing.Point(669, 20);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(15, 18);
            this.label82.TabIndex = 118;
            this.label82.Text = "*";
            // 
            // dgvRBF
            // 
            this.dgvRBF.AllowUserToAddRows = false;
            this.dgvRBF.AllowUserToResizeRows = false;
            this.dgvRBF.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRBF.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvRBF.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRBF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRBF.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvRBF.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle862.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle862.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle862.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle862.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle862.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle862.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle862.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRBF.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle862;
            this.dgvRBF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle863.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle863.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle863.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle863.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle863.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle863.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle863.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRBF.DefaultCellStyle = dataGridViewCellStyle863;
            this.dgvRBF.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvRBF.EnableHeadersVisualStyles = false;
            this.dgvRBF.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvRBF.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRBF.Location = new System.Drawing.Point(0, 222);
            this.dgvRBF.MultiSelect = false;
            this.dgvRBF.Name = "dgvRBF";
            this.dgvRBF.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle864.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle864.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle864.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle864.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle864.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle864.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle864.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRBF.RowHeadersDefaultCellStyle = dataGridViewCellStyle864;
            this.dgvRBF.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvRBF.RowTemplate.Height = 33;
            this.dgvRBF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRBF.Size = new System.Drawing.Size(862, 343);
            this.dgvRBF.TabIndex = 126;
            this.dgvRBF.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRBF_CellDoubleClick);
            // 
            // metroComboBoxRBF_BFI
            // 
            this.metroComboBoxRBF_BFI.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRBF_BFI.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRBF_BFI.FormattingEnabled = true;
            this.metroComboBoxRBF_BFI.ItemHeight = 23;
            this.metroComboBoxRBF_BFI.Location = new System.Drawing.Point(29, 108);
            this.metroComboBoxRBF_BFI.Name = "metroComboBoxRBF_BFI";
            this.metroComboBoxRBF_BFI.Size = new System.Drawing.Size(668, 29);
            this.metroComboBoxRBF_BFI.Sorted = true;
            this.metroComboBoxRBF_BFI.TabIndex = 108;
            this.metroComboBoxRBF_BFI.UseSelectable = true;
            this.metroComboBoxRBF_BFI.UseStyleColors = true;
            this.metroComboBoxRBF_BFI.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRBF_BFI_SelectedIndexChanged);
            // 
            // metroComboBoxRBF_RID
            // 
            this.metroComboBoxRBF_RID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRBF_RID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRBF_RID.FormattingEnabled = true;
            this.metroComboBoxRBF_RID.ItemHeight = 23;
            this.metroComboBoxRBF_RID.Location = new System.Drawing.Point(29, 49);
            this.metroComboBoxRBF_RID.Name = "metroComboBoxRBF_RID";
            this.metroComboBoxRBF_RID.Size = new System.Drawing.Size(668, 29);
            this.metroComboBoxRBF_RID.Sorted = true;
            this.metroComboBoxRBF_RID.TabIndex = 107;
            this.metroComboBoxRBF_RID.UseSelectable = true;
            this.metroComboBoxRBF_RID.UseStyleColors = true;
            this.metroComboBoxRBF_RID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRBF_RID_SelectedIndexChanged);
            // 
            // buttonRBF_Gen
            // 
            this.buttonRBF_Gen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonRBF_Gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRBF_Gen.Location = new System.Drawing.Point(683, 149);
            this.buttonRBF_Gen.Name = "buttonRBF_Gen";
            this.buttonRBF_Gen.Size = new System.Drawing.Size(161, 45);
            this.buttonRBF_Gen.TabIndex = 106;
            this.buttonRBF_Gen.Text = "Generate";
            this.buttonRBF_Gen.UseVisualStyleBackColor = true;
            this.buttonRBF_Gen.Click += new System.EventHandler(this.buttonRBF_Gen_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(24, 81);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(73, 14);
            this.label66.TabIndex = 105;
            this.label66.Text = "Base Fare ID:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(24, 20);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(101, 14);
            this.label67.TabIndex = 103;
            this.label67.Text = "Route Long Name:";
            // 
            // tb9
            // 
            this.tb9.Controls.Add(this.panel8);
            this.tb9.Location = new System.Drawing.Point(4, 34);
            this.tb9.Name = "tb9";
            this.tb9.Size = new System.Drawing.Size(862, 565);
            this.tb9.TabIndex = 8;
            this.tb9.Text = "Route Discounted Fares";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel8.Controls.Add(this.buttonexprdf);
            this.panel8.Controls.Add(this.panelRDF);
            this.panel8.Controls.Add(this.buttonSAVERDF);
            this.panel8.Controls.Add(this.label84);
            this.panel8.Controls.Add(this.label85);
            this.panel8.Controls.Add(this.buttonDELRDF);
            this.panel8.Controls.Add(this.dgvRDF);
            this.panel8.Controls.Add(this.metroComboBoxRDBF_DID);
            this.panel8.Controls.Add(this.metroComboBoxRDBF_RID);
            this.panel8.Controls.Add(this.label75);
            this.panel8.Controls.Add(this.label76);
            this.panel8.Controls.Add(this.buttonRDBF_Gen);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(862, 565);
            this.panel8.TabIndex = 79;
            // 
            // buttonexprdf
            // 
            this.buttonexprdf.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexprdf.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexprdf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexprdf.Location = new System.Drawing.Point(717, 234);
            this.buttonexprdf.Name = "buttonexprdf";
            this.buttonexprdf.Size = new System.Drawing.Size(133, 45);
            this.buttonexprdf.TabIndex = 138;
            this.buttonexprdf.Text = "Export";
            this.buttonexprdf.UseVisualStyleBackColor = false;
            this.buttonexprdf.Click += new System.EventHandler(this.buttonexprdf_Click);
            // 
            // panelRDF
            // 
            this.panelRDF.Controls.Add(this.label250);
            this.panelRDF.Controls.Add(this.label251);
            this.panelRDF.Controls.Add(this.metroComboBoxRDBF_DID2);
            this.panelRDF.Controls.Add(this.metroComboBoxRDBF_RID2);
            this.panelRDF.Controls.Add(this.label252);
            this.panelRDF.Controls.Add(this.label253);
            this.panelRDF.Location = new System.Drawing.Point(17, 28);
            this.panelRDF.Name = "panelRDF";
            this.panelRDF.Size = new System.Drawing.Size(716, 137);
            this.panelRDF.TabIndex = 83;
            this.panelRDF.Visible = false;
            // 
            // label250
            // 
            this.label250.AutoSize = true;
            this.label250.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label250.ForeColor = System.Drawing.Color.Red;
            this.label250.Location = new System.Drawing.Point(664, 71);
            this.label250.Name = "label250";
            this.label250.Size = new System.Drawing.Size(15, 18);
            this.label250.TabIndex = 138;
            this.label250.Text = "*";
            // 
            // label251
            // 
            this.label251.AutoSize = true;
            this.label251.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label251.ForeColor = System.Drawing.Color.Red;
            this.label251.Location = new System.Drawing.Point(664, 0);
            this.label251.Name = "label251";
            this.label251.Size = new System.Drawing.Size(15, 18);
            this.label251.TabIndex = 137;
            this.label251.Text = "*";
            // 
            // metroComboBoxRDBF_DID2
            // 
            this.metroComboBoxRDBF_DID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRDBF_DID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRDBF_DID2.FormattingEnabled = true;
            this.metroComboBoxRDBF_DID2.ItemHeight = 23;
            this.metroComboBoxRDBF_DID2.Location = new System.Drawing.Point(8, 100);
            this.metroComboBoxRDBF_DID2.Name = "metroComboBoxRDBF_DID2";
            this.metroComboBoxRDBF_DID2.Size = new System.Drawing.Size(684, 29);
            this.metroComboBoxRDBF_DID2.Sorted = true;
            this.metroComboBoxRDBF_DID2.TabIndex = 136;
            this.metroComboBoxRDBF_DID2.UseSelectable = true;
            this.metroComboBoxRDBF_DID2.UseStyleColors = true;
            this.metroComboBoxRDBF_DID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRDBF_DID2_SelectedIndexChanged);
            // 
            // metroComboBoxRDBF_RID2
            // 
            this.metroComboBoxRDBF_RID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRDBF_RID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRDBF_RID2.FormattingEnabled = true;
            this.metroComboBoxRDBF_RID2.ItemHeight = 23;
            this.metroComboBoxRDBF_RID2.Location = new System.Drawing.Point(8, 29);
            this.metroComboBoxRDBF_RID2.Name = "metroComboBoxRDBF_RID2";
            this.metroComboBoxRDBF_RID2.Size = new System.Drawing.Size(684, 29);
            this.metroComboBoxRDBF_RID2.Sorted = true;
            this.metroComboBoxRDBF_RID2.TabIndex = 135;
            this.metroComboBoxRDBF_RID2.UseSelectable = true;
            this.metroComboBoxRDBF_RID2.UseStyleColors = true;
            this.metroComboBoxRDBF_RID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRDBF_RID2_SelectedIndexChanged);
            // 
            // label252
            // 
            this.label252.AutoSize = true;
            this.label252.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label252.Location = new System.Drawing.Point(3, 71);
            this.label252.Name = "label252";
            this.label252.Size = new System.Drawing.Size(98, 14);
            this.label252.TabIndex = 134;
            this.label252.Text = "New FareTable ID:";
            // 
            // label253
            // 
            this.label253.AutoSize = true;
            this.label253.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label253.Location = new System.Drawing.Point(3, 0);
            this.label253.Name = "label253";
            this.label253.Size = new System.Drawing.Size(122, 14);
            this.label253.TabIndex = 133;
            this.label253.Text = "New Route Longname:";
            // 
            // buttonSAVERDF
            // 
            this.buttonSAVERDF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVERDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVERDF.Location = new System.Drawing.Point(548, 177);
            this.buttonSAVERDF.Name = "buttonSAVERDF";
            this.buttonSAVERDF.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVERDF.TabIndex = 137;
            this.buttonSAVERDF.Text = "Save";
            this.buttonSAVERDF.UseVisualStyleBackColor = true;
            this.buttonSAVERDF.Visible = false;
            this.buttonSAVERDF.Click += new System.EventHandler(this.buttonSAVERDF_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.Color.Red;
            this.label84.Location = new System.Drawing.Point(681, 99);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(15, 18);
            this.label84.TabIndex = 132;
            this.label84.Text = "*";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.Color.Red;
            this.label85.Location = new System.Drawing.Point(681, 28);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(15, 18);
            this.label85.TabIndex = 131;
            this.label85.Text = "*";
            // 
            // buttonDELRDF
            // 
            this.buttonDELRDF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELRDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELRDF.Location = new System.Drawing.Point(2, 238);
            this.buttonDELRDF.Name = "buttonDELRDF";
            this.buttonDELRDF.Size = new System.Drawing.Size(111, 41);
            this.buttonDELRDF.TabIndex = 130;
            this.buttonDELRDF.Text = "Delete";
            this.buttonDELRDF.UseVisualStyleBackColor = true;
            this.buttonDELRDF.Click += new System.EventHandler(this.buttonDELRDF_Click);
            // 
            // dgvRDF
            // 
            this.dgvRDF.AllowUserToAddRows = false;
            this.dgvRDF.AllowUserToResizeRows = false;
            this.dgvRDF.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRDF.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvRDF.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRDF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRDF.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvRDF.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle865.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle865.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle865.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle865.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle865.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle865.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle865.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRDF.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle865;
            this.dgvRDF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle866.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle866.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle866.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle866.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle866.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle866.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle866.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRDF.DefaultCellStyle = dataGridViewCellStyle866;
            this.dgvRDF.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvRDF.EnableHeadersVisualStyles = false;
            this.dgvRDF.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvRDF.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRDF.Location = new System.Drawing.Point(0, 256);
            this.dgvRDF.MultiSelect = false;
            this.dgvRDF.Name = "dgvRDF";
            this.dgvRDF.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle867.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle867.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle867.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle867.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle867.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle867.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle867.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRDF.RowHeadersDefaultCellStyle = dataGridViewCellStyle867;
            this.dgvRDF.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvRDF.RowTemplate.Height = 33;
            this.dgvRDF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRDF.Size = new System.Drawing.Size(862, 309);
            this.dgvRDF.TabIndex = 127;
            this.dgvRDF.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRDF_CellDoubleClick);
            // 
            // metroComboBoxRDBF_DID
            // 
            this.metroComboBoxRDBF_DID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRDBF_DID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRDBF_DID.FormattingEnabled = true;
            this.metroComboBoxRDBF_DID.ItemHeight = 23;
            this.metroComboBoxRDBF_DID.Location = new System.Drawing.Point(25, 128);
            this.metroComboBoxRDBF_DID.Name = "metroComboBoxRDBF_DID";
            this.metroComboBoxRDBF_DID.Size = new System.Drawing.Size(684, 29);
            this.metroComboBoxRDBF_DID.Sorted = true;
            this.metroComboBoxRDBF_DID.TabIndex = 115;
            this.metroComboBoxRDBF_DID.UseSelectable = true;
            this.metroComboBoxRDBF_DID.UseStyleColors = true;
            this.metroComboBoxRDBF_DID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRDBF_DID_SelectedIndexChanged);
            // 
            // metroComboBoxRDBF_RID
            // 
            this.metroComboBoxRDBF_RID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxRDBF_RID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxRDBF_RID.FormattingEnabled = true;
            this.metroComboBoxRDBF_RID.ItemHeight = 23;
            this.metroComboBoxRDBF_RID.Location = new System.Drawing.Point(25, 57);
            this.metroComboBoxRDBF_RID.Name = "metroComboBoxRDBF_RID";
            this.metroComboBoxRDBF_RID.Size = new System.Drawing.Size(684, 29);
            this.metroComboBoxRDBF_RID.Sorted = true;
            this.metroComboBoxRDBF_RID.TabIndex = 114;
            this.metroComboBoxRDBF_RID.UseSelectable = true;
            this.metroComboBoxRDBF_RID.UseStyleColors = true;
            this.metroComboBoxRDBF_RID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxRDBF_RID_SelectedIndexChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(20, 99);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(72, 14);
            this.label75.TabIndex = 112;
            this.label75.Text = "FareTable ID:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(20, 28);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(96, 14);
            this.label76.TabIndex = 111;
            this.label76.Text = "Route Longname:";
            // 
            // buttonRDBF_Gen
            // 
            this.buttonRDBF_Gen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonRDBF_Gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRDBF_Gen.Location = new System.Drawing.Point(687, 177);
            this.buttonRDBF_Gen.Name = "buttonRDBF_Gen";
            this.buttonRDBF_Gen.Size = new System.Drawing.Size(161, 45);
            this.buttonRDBF_Gen.TabIndex = 113;
            this.buttonRDBF_Gen.Text = "Generate";
            this.buttonRDBF_Gen.UseVisualStyleBackColor = true;
            this.buttonRDBF_Gen.Click += new System.EventHandler(this.buttonRDBF_Gen_Click);
            // 
            // tb10
            // 
            this.tb10.Controls.Add(this.panel9);
            this.tb10.Location = new System.Drawing.Point(4, 34);
            this.tb10.Name = "tb10";
            this.tb10.Size = new System.Drawing.Size(862, 565);
            this.tb10.TabIndex = 9;
            this.tb10.Text = "Profile Routes";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel9.Controls.Add(this.buttonexppr);
            this.panel9.Controls.Add(this.panelPR);
            this.panel9.Controls.Add(this.buttonSavePR);
            this.panel9.Controls.Add(this.buttonDELPR);
            this.panel9.Controls.Add(this.label86);
            this.panel9.Controls.Add(this.label87);
            this.panel9.Controls.Add(this.dgvPR);
            this.panel9.Controls.Add(this.metroComboBoxPR_RID);
            this.panel9.Controls.Add(this.metroComboBoxPR_PID);
            this.panel9.Controls.Add(this.buttonPR_Gen);
            this.panel9.Controls.Add(this.label80);
            this.panel9.Controls.Add(this.label81);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(862, 565);
            this.panel9.TabIndex = 79;
            // 
            // buttonexppr
            // 
            this.buttonexppr.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexppr.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexppr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexppr.Location = new System.Drawing.Point(711, 220);
            this.buttonexppr.Name = "buttonexppr";
            this.buttonexppr.Size = new System.Drawing.Size(133, 45);
            this.buttonexppr.TabIndex = 138;
            this.buttonexppr.Text = "Export";
            this.buttonexppr.UseVisualStyleBackColor = false;
            this.buttonexppr.Click += new System.EventHandler(this.buttonexppr_Click);
            // 
            // panelPR
            // 
            this.panelPR.Controls.Add(this.label254);
            this.panelPR.Controls.Add(this.label255);
            this.panelPR.Controls.Add(this.metroComboBoxPR_RID2);
            this.panelPR.Controls.Add(this.metroComboBoxPR_PID2);
            this.panelPR.Controls.Add(this.label256);
            this.panelPR.Controls.Add(this.label257);
            this.panelPR.Location = new System.Drawing.Point(28, 17);
            this.panelPR.Name = "panelPR";
            this.panelPR.Size = new System.Drawing.Size(692, 150);
            this.panelPR.TabIndex = 83;
            this.panelPR.Visible = false;
            // 
            // label254
            // 
            this.label254.AutoSize = true;
            this.label254.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label254.ForeColor = System.Drawing.Color.Red;
            this.label254.Location = new System.Drawing.Point(654, 76);
            this.label254.Name = "label254";
            this.label254.Size = new System.Drawing.Size(15, 18);
            this.label254.TabIndex = 132;
            this.label254.Text = "*";
            // 
            // label255
            // 
            this.label255.AutoSize = true;
            this.label255.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label255.ForeColor = System.Drawing.Color.Red;
            this.label255.Location = new System.Drawing.Point(654, 8);
            this.label255.Name = "label255";
            this.label255.Size = new System.Drawing.Size(15, 18);
            this.label255.TabIndex = 131;
            this.label255.Text = "*";
            // 
            // metroComboBoxPR_RID2
            // 
            this.metroComboBoxPR_RID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPR_RID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPR_RID2.FormattingEnabled = true;
            this.metroComboBoxPR_RID2.ItemHeight = 23;
            this.metroComboBoxPR_RID2.Location = new System.Drawing.Point(8, 104);
            this.metroComboBoxPR_RID2.Name = "metroComboBoxPR_RID2";
            this.metroComboBoxPR_RID2.Size = new System.Drawing.Size(674, 29);
            this.metroComboBoxPR_RID2.Sorted = true;
            this.metroComboBoxPR_RID2.TabIndex = 130;
            this.metroComboBoxPR_RID2.UseSelectable = true;
            this.metroComboBoxPR_RID2.UseStyleColors = true;
            this.metroComboBoxPR_RID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPR_RID2_SelectedIndexChanged);
            // 
            // metroComboBoxPR_PID2
            // 
            this.metroComboBoxPR_PID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPR_PID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPR_PID2.FormattingEnabled = true;
            this.metroComboBoxPR_PID2.ItemHeight = 23;
            this.metroComboBoxPR_PID2.Location = new System.Drawing.Point(8, 37);
            this.metroComboBoxPR_PID2.Name = "metroComboBoxPR_PID2";
            this.metroComboBoxPR_PID2.Size = new System.Drawing.Size(674, 29);
            this.metroComboBoxPR_PID2.Sorted = true;
            this.metroComboBoxPR_PID2.TabIndex = 129;
            this.metroComboBoxPR_PID2.UseSelectable = true;
            this.metroComboBoxPR_PID2.UseStyleColors = true;
            this.metroComboBoxPR_PID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPR_PID2_SelectedIndexChanged);
            // 
            // label256
            // 
            this.label256.AutoSize = true;
            this.label256.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label256.Location = new System.Drawing.Point(3, 75);
            this.label256.Name = "label256";
            this.label256.Size = new System.Drawing.Size(122, 14);
            this.label256.TabIndex = 128;
            this.label256.Text = "New Route Longname:";
            // 
            // label257
            // 
            this.label257.AutoSize = true;
            this.label257.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label257.Location = new System.Drawing.Point(3, 8);
            this.label257.Name = "label257";
            this.label257.Size = new System.Drawing.Size(101, 14);
            this.label257.TabIndex = 127;
            this.label257.Text = "New Profile Name:";
            // 
            // buttonSavePR
            // 
            this.buttonSavePR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSavePR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSavePR.Location = new System.Drawing.Point(544, 169);
            this.buttonSavePR.Name = "buttonSavePR";
            this.buttonSavePR.Size = new System.Drawing.Size(133, 45);
            this.buttonSavePR.TabIndex = 137;
            this.buttonSavePR.Text = "Save";
            this.buttonSavePR.UseVisualStyleBackColor = true;
            this.buttonSavePR.Visible = false;
            this.buttonSavePR.Click += new System.EventHandler(this.buttonSavePR_Click);
            // 
            // buttonDELPR
            // 
            this.buttonDELPR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELPR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELPR.Location = new System.Drawing.Point(9, 222);
            this.buttonDELPR.Name = "buttonDELPR";
            this.buttonDELPR.Size = new System.Drawing.Size(111, 41);
            this.buttonDELPR.TabIndex = 130;
            this.buttonDELPR.Text = "Delete";
            this.buttonDELPR.UseVisualStyleBackColor = true;
            this.buttonDELPR.Click += new System.EventHandler(this.buttonDELPR_Click);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.Red;
            this.label86.Location = new System.Drawing.Point(682, 93);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(15, 18);
            this.label86.TabIndex = 126;
            this.label86.Text = "*";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.Color.Red;
            this.label87.Location = new System.Drawing.Point(682, 25);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(15, 18);
            this.label87.TabIndex = 125;
            this.label87.Text = "*";
            // 
            // dgvPR
            // 
            this.dgvPR.AllowUserToAddRows = false;
            this.dgvPR.AllowUserToResizeRows = false;
            this.dgvPR.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPR.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPR.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle868.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle868.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle868.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle868.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle868.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle868.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle868.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPR.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle868;
            this.dgvPR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle869.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle869.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle869.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle869.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle869.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle869.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle869.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPR.DefaultCellStyle = dataGridViewCellStyle869;
            this.dgvPR.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPR.EnableHeadersVisualStyles = false;
            this.dgvPR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPR.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPR.Location = new System.Drawing.Point(0, 244);
            this.dgvPR.MultiSelect = false;
            this.dgvPR.Name = "dgvPR";
            this.dgvPR.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle870.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle870.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle870.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle870.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle870.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle870.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle870.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPR.RowHeadersDefaultCellStyle = dataGridViewCellStyle870;
            this.dgvPR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPR.RowTemplate.Height = 33;
            this.dgvPR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPR.Size = new System.Drawing.Size(862, 321);
            this.dgvPR.TabIndex = 127;
            this.dgvPR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPR_CellDoubleClick);
            // 
            // metroComboBoxPR_RID
            // 
            this.metroComboBoxPR_RID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPR_RID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPR_RID.FormattingEnabled = true;
            this.metroComboBoxPR_RID.ItemHeight = 23;
            this.metroComboBoxPR_RID.Location = new System.Drawing.Point(36, 121);
            this.metroComboBoxPR_RID.Name = "metroComboBoxPR_RID";
            this.metroComboBoxPR_RID.Size = new System.Drawing.Size(674, 29);
            this.metroComboBoxPR_RID.Sorted = true;
            this.metroComboBoxPR_RID.TabIndex = 122;
            this.metroComboBoxPR_RID.UseSelectable = true;
            this.metroComboBoxPR_RID.UseStyleColors = true;
            this.metroComboBoxPR_RID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPR_RID_SelectedIndexChanged);
            // 
            // metroComboBoxPR_PID
            // 
            this.metroComboBoxPR_PID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPR_PID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPR_PID.FormattingEnabled = true;
            this.metroComboBoxPR_PID.ItemHeight = 23;
            this.metroComboBoxPR_PID.Location = new System.Drawing.Point(36, 54);
            this.metroComboBoxPR_PID.Name = "metroComboBoxPR_PID";
            this.metroComboBoxPR_PID.Size = new System.Drawing.Size(674, 29);
            this.metroComboBoxPR_PID.Sorted = true;
            this.metroComboBoxPR_PID.TabIndex = 121;
            this.metroComboBoxPR_PID.UseSelectable = true;
            this.metroComboBoxPR_PID.UseStyleColors = true;
            this.metroComboBoxPR_PID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPR_PID_SelectedIndexChanged);
            // 
            // buttonPR_Gen
            // 
            this.buttonPR_Gen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonPR_Gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPR_Gen.Location = new System.Drawing.Point(683, 169);
            this.buttonPR_Gen.Name = "buttonPR_Gen";
            this.buttonPR_Gen.Size = new System.Drawing.Size(161, 45);
            this.buttonPR_Gen.TabIndex = 120;
            this.buttonPR_Gen.Text = "Generate";
            this.buttonPR_Gen.UseVisualStyleBackColor = true;
            this.buttonPR_Gen.Click += new System.EventHandler(this.buttonPR_Gen_Click);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(31, 92);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(96, 14);
            this.label80.TabIndex = 119;
            this.label80.Text = "Route Longname:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(31, 25);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(75, 14);
            this.label81.TabIndex = 118;
            this.label81.Text = "Profile Name:";
            // 
            // tb11
            // 
            this.tb11.Controls.Add(this.panel10);
            this.tb11.Location = new System.Drawing.Point(4, 34);
            this.tb11.Name = "tb11";
            this.tb11.Size = new System.Drawing.Size(862, 565);
            this.tb11.TabIndex = 10;
            this.tb11.Text = "ProfileDistanceBaseds";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel10.Controls.Add(this.buttonexppdb);
            this.panel10.Controls.Add(this.panelPDB);
            this.panel10.Controls.Add(this.buttonSAVEPDB);
            this.panel10.Controls.Add(this.buttonDELPDB);
            this.panel10.Controls.Add(this.dgvPDB);
            this.panel10.Controls.Add(this.label35);
            this.panel10.Controls.Add(this.label96);
            this.panel10.Controls.Add(this.metroComboBoxPDB_BID);
            this.panel10.Controls.Add(this.metroComboBoxPDB_PID);
            this.panel10.Controls.Add(this.buttonPDB_Gen);
            this.panel10.Controls.Add(this.label98);
            this.panel10.Controls.Add(this.label99);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(862, 565);
            this.panel10.TabIndex = 77;
            // 
            // buttonexppdb
            // 
            this.buttonexppdb.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexppdb.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexppdb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexppdb.Location = new System.Drawing.Point(711, 208);
            this.buttonexppdb.Name = "buttonexppdb";
            this.buttonexppdb.Size = new System.Drawing.Size(133, 45);
            this.buttonexppdb.TabIndex = 139;
            this.buttonexppdb.Text = "Export";
            this.buttonexppdb.UseVisualStyleBackColor = false;
            this.buttonexppdb.Click += new System.EventHandler(this.buttonexppdb_Click);
            // 
            // panelPDB
            // 
            this.panelPDB.Controls.Add(this.label258);
            this.panelPDB.Controls.Add(this.label259);
            this.panelPDB.Controls.Add(this.metroComboBoxPDB_BID2);
            this.panelPDB.Controls.Add(this.metroComboBoxPDB_PID2);
            this.panelPDB.Controls.Add(this.label260);
            this.panelPDB.Controls.Add(this.label261);
            this.panelPDB.Location = new System.Drawing.Point(19, 29);
            this.panelPDB.Name = "panelPDB";
            this.panelPDB.Size = new System.Drawing.Size(696, 124);
            this.panelPDB.TabIndex = 83;
            this.panelPDB.Visible = false;
            // 
            // label258
            // 
            this.label258.AutoSize = true;
            this.label258.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label258.ForeColor = System.Drawing.Color.Red;
            this.label258.Location = new System.Drawing.Point(660, 63);
            this.label258.Name = "label258";
            this.label258.Size = new System.Drawing.Size(15, 18);
            this.label258.TabIndex = 141;
            this.label258.Text = "*";
            // 
            // label259
            // 
            this.label259.AutoSize = true;
            this.label259.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label259.ForeColor = System.Drawing.Color.Red;
            this.label259.Location = new System.Drawing.Point(660, 0);
            this.label259.Name = "label259";
            this.label259.Size = new System.Drawing.Size(15, 18);
            this.label259.TabIndex = 140;
            this.label259.Text = "*";
            // 
            // metroComboBoxPDB_BID2
            // 
            this.metroComboBoxPDB_BID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPDB_BID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPDB_BID2.FormattingEnabled = true;
            this.metroComboBoxPDB_BID2.ItemHeight = 23;
            this.metroComboBoxPDB_BID2.Location = new System.Drawing.Point(8, 90);
            this.metroComboBoxPDB_BID2.Name = "metroComboBoxPDB_BID2";
            this.metroComboBoxPDB_BID2.Size = new System.Drawing.Size(680, 29);
            this.metroComboBoxPDB_BID2.Sorted = true;
            this.metroComboBoxPDB_BID2.TabIndex = 139;
            this.metroComboBoxPDB_BID2.UseSelectable = true;
            this.metroComboBoxPDB_BID2.UseStyleColors = true;
            this.metroComboBoxPDB_BID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPDB_BID2_SelectedIndexChanged);
            // 
            // metroComboBoxPDB_PID2
            // 
            this.metroComboBoxPDB_PID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPDB_PID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPDB_PID2.FormattingEnabled = true;
            this.metroComboBoxPDB_PID2.ItemHeight = 23;
            this.metroComboBoxPDB_PID2.Location = new System.Drawing.Point(8, 29);
            this.metroComboBoxPDB_PID2.Name = "metroComboBoxPDB_PID2";
            this.metroComboBoxPDB_PID2.Size = new System.Drawing.Size(680, 29);
            this.metroComboBoxPDB_PID2.Sorted = true;
            this.metroComboBoxPDB_PID2.TabIndex = 138;
            this.metroComboBoxPDB_PID2.UseSelectable = true;
            this.metroComboBoxPDB_PID2.UseStyleColors = true;
            this.metroComboBoxPDB_PID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPDB_PID2_SelectedIndexChanged);
            // 
            // label260
            // 
            this.label260.AutoSize = true;
            this.label260.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label260.Location = new System.Drawing.Point(3, 61);
            this.label260.Name = "label260";
            this.label260.Size = new System.Drawing.Size(98, 14);
            this.label260.TabIndex = 137;
            this.label260.Text = "New FareTable ID:";
            // 
            // label261
            // 
            this.label261.AutoSize = true;
            this.label261.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label261.Location = new System.Drawing.Point(3, 0);
            this.label261.Name = "label261";
            this.label261.Size = new System.Drawing.Size(101, 14);
            this.label261.TabIndex = 136;
            this.label261.Text = "New Profile Name:";
            // 
            // buttonSAVEPDB
            // 
            this.buttonSAVEPDB.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVEPDB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVEPDB.Location = new System.Drawing.Point(547, 154);
            this.buttonSAVEPDB.Name = "buttonSAVEPDB";
            this.buttonSAVEPDB.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVEPDB.TabIndex = 138;
            this.buttonSAVEPDB.Text = "Save";
            this.buttonSAVEPDB.UseVisualStyleBackColor = true;
            this.buttonSAVEPDB.Visible = false;
            this.buttonSAVEPDB.Click += new System.EventHandler(this.buttonSAVEPDB_Click);
            // 
            // buttonDELPDB
            // 
            this.buttonDELPDB.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELPDB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELPDB.Location = new System.Drawing.Point(1, 222);
            this.buttonDELPDB.Name = "buttonDELPDB";
            this.buttonDELPDB.Size = new System.Drawing.Size(111, 41);
            this.buttonDELPDB.TabIndex = 137;
            this.buttonDELPDB.Text = "Delete";
            this.buttonDELPDB.UseVisualStyleBackColor = true;
            this.buttonDELPDB.Click += new System.EventHandler(this.buttonDELPDB_Click);
            // 
            // dgvPDB
            // 
            this.dgvPDB.AllowUserToAddRows = false;
            this.dgvPDB.AllowUserToResizeRows = false;
            this.dgvPDB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPDB.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPDB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPDB.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPDB.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle871.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle871.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle871.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle871.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle871.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle871.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle871.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPDB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle871;
            this.dgvPDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle872.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle872.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle872.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle872.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle872.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle872.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle872.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPDB.DefaultCellStyle = dataGridViewCellStyle872;
            this.dgvPDB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPDB.EnableHeadersVisualStyles = false;
            this.dgvPDB.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPDB.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPDB.Location = new System.Drawing.Point(0, 241);
            this.dgvPDB.MultiSelect = false;
            this.dgvPDB.Name = "dgvPDB";
            this.dgvPDB.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle873.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle873.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle873.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle873.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle873.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle873.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle873.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPDB.RowHeadersDefaultCellStyle = dataGridViewCellStyle873;
            this.dgvPDB.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPDB.RowTemplate.Height = 33;
            this.dgvPDB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPDB.Size = new System.Drawing.Size(862, 324);
            this.dgvPDB.TabIndex = 136;
            this.dgvPDB.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPDB_CellDoubleClick);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(679, 92);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(15, 18);
            this.label35.TabIndex = 135;
            this.label35.Text = "*";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.ForeColor = System.Drawing.Color.Red;
            this.label96.Location = new System.Drawing.Point(679, 29);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(15, 18);
            this.label96.TabIndex = 134;
            this.label96.Text = "*";
            // 
            // metroComboBoxPDB_BID
            // 
            this.metroComboBoxPDB_BID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPDB_BID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPDB_BID.FormattingEnabled = true;
            this.metroComboBoxPDB_BID.ItemHeight = 23;
            this.metroComboBoxPDB_BID.Location = new System.Drawing.Point(27, 119);
            this.metroComboBoxPDB_BID.Name = "metroComboBoxPDB_BID";
            this.metroComboBoxPDB_BID.Size = new System.Drawing.Size(680, 29);
            this.metroComboBoxPDB_BID.Sorted = true;
            this.metroComboBoxPDB_BID.TabIndex = 132;
            this.metroComboBoxPDB_BID.UseSelectable = true;
            this.metroComboBoxPDB_BID.UseStyleColors = true;
            this.metroComboBoxPDB_BID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPDB_BID_SelectedIndexChanged);
            // 
            // metroComboBoxPDB_PID
            // 
            this.metroComboBoxPDB_PID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPDB_PID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPDB_PID.FormattingEnabled = true;
            this.metroComboBoxPDB_PID.ItemHeight = 23;
            this.metroComboBoxPDB_PID.Location = new System.Drawing.Point(27, 58);
            this.metroComboBoxPDB_PID.Name = "metroComboBoxPDB_PID";
            this.metroComboBoxPDB_PID.Size = new System.Drawing.Size(680, 29);
            this.metroComboBoxPDB_PID.Sorted = true;
            this.metroComboBoxPDB_PID.TabIndex = 131;
            this.metroComboBoxPDB_PID.UseSelectable = true;
            this.metroComboBoxPDB_PID.UseStyleColors = true;
            this.metroComboBoxPDB_PID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPDB_PID_SelectedIndexChanged);
            // 
            // buttonPDB_Gen
            // 
            this.buttonPDB_Gen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonPDB_Gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPDB_Gen.Location = new System.Drawing.Point(686, 154);
            this.buttonPDB_Gen.Name = "buttonPDB_Gen";
            this.buttonPDB_Gen.Size = new System.Drawing.Size(161, 45);
            this.buttonPDB_Gen.TabIndex = 130;
            this.buttonPDB_Gen.Text = "Generate";
            this.buttonPDB_Gen.UseVisualStyleBackColor = true;
            this.buttonPDB_Gen.Click += new System.EventHandler(this.buttonPDB_Gen_Click);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(22, 90);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(72, 14);
            this.label98.TabIndex = 129;
            this.label98.Text = "FareTable ID:";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(22, 29);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(75, 14);
            this.label99.TabIndex = 128;
            this.label99.Text = "Profile Name:";
            // 
            // tb12
            // 
            this.tb12.Controls.Add(this.panel11);
            this.tb12.Location = new System.Drawing.Point(4, 34);
            this.tb12.Name = "tb12";
            this.tb12.Size = new System.Drawing.Size(862, 565);
            this.tb12.TabIndex = 11;
            this.tb12.Text = "ProfileParams";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel11.Controls.Add(this.panelPP);
            this.panel11.Controls.Add(this.buttonexppp);
            this.panel11.Controls.Add(this.labelSSVAL);
            this.panel11.Controls.Add(this.buttonsavePP);
            this.panel11.Controls.Add(this.buttonDELPP);
            this.panel11.Controls.Add(this.label14);
            this.panel11.Controls.Add(this.label53);
            this.panel11.Controls.Add(this.dgvPP);
            this.panel11.Controls.Add(this.metroComboBoxPP_SPI);
            this.panel11.Controls.Add(this.metroComboBoxPP_PID);
            this.panel11.Controls.Add(this.buttonGenPP);
            this.panel11.Controls.Add(this.label63);
            this.panel11.Controls.Add(this.label64);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(862, 565);
            this.panel11.TabIndex = 78;
            // 
            // panelPP
            // 
            this.panelPP.Controls.Add(this.labelSSVAL2);
            this.panelPP.Controls.Add(this.label262);
            this.panelPP.Controls.Add(this.label263);
            this.panelPP.Controls.Add(this.metroComboBoxPP_SPI2);
            this.panelPP.Controls.Add(this.metroComboBoxPP_PID2);
            this.panelPP.Controls.Add(this.label264);
            this.panelPP.Controls.Add(this.label265);
            this.panelPP.Location = new System.Drawing.Point(13, 23);
            this.panelPP.Name = "panelPP";
            this.panelPP.Size = new System.Drawing.Size(675, 88);
            this.panelPP.TabIndex = 83;
            this.panelPP.Visible = false;
            // 
            // labelSSVAL2
            // 
            this.labelSSVAL2.AutoSize = true;
            this.labelSSVAL2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSSVAL2.Location = new System.Drawing.Point(318, 62);
            this.labelSSVAL2.Name = "labelSSVAL2";
            this.labelSSVAL2.Size = new System.Drawing.Size(0, 14);
            this.labelSSVAL2.TabIndex = 159;
            // 
            // label262
            // 
            this.label262.AutoSize = true;
            this.label262.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label262.ForeColor = System.Drawing.Color.Red;
            this.label262.Location = new System.Drawing.Point(599, 5);
            this.label262.Name = "label262";
            this.label262.Size = new System.Drawing.Size(15, 18);
            this.label262.TabIndex = 150;
            this.label262.Text = "*";
            // 
            // label263
            // 
            this.label263.AutoSize = true;
            this.label263.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label263.ForeColor = System.Drawing.Color.Red;
            this.label263.Location = new System.Drawing.Point(284, 1);
            this.label263.Name = "label263";
            this.label263.Size = new System.Drawing.Size(15, 18);
            this.label263.TabIndex = 149;
            this.label263.Text = "*";
            // 
            // metroComboBoxPP_SPI2
            // 
            this.metroComboBoxPP_SPI2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPP_SPI2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPP_SPI2.FormattingEnabled = true;
            this.metroComboBoxPP_SPI2.ItemHeight = 23;
            this.metroComboBoxPP_SPI2.Location = new System.Drawing.Point(323, 29);
            this.metroComboBoxPP_SPI2.Name = "metroComboBoxPP_SPI2";
            this.metroComboBoxPP_SPI2.Size = new System.Drawing.Size(349, 29);
            this.metroComboBoxPP_SPI2.Sorted = true;
            this.metroComboBoxPP_SPI2.TabIndex = 148;
            this.metroComboBoxPP_SPI2.UseSelectable = true;
            this.metroComboBoxPP_SPI2.UseStyleColors = true;
            this.metroComboBoxPP_SPI2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPP_SPI2_SelectedIndexChanged);
            // 
            // metroComboBoxPP_PID2
            // 
            this.metroComboBoxPP_PID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPP_PID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPP_PID2.FormattingEnabled = true;
            this.metroComboBoxPP_PID2.ItemHeight = 23;
            this.metroComboBoxPP_PID2.Location = new System.Drawing.Point(8, 29);
            this.metroComboBoxPP_PID2.Name = "metroComboBoxPP_PID2";
            this.metroComboBoxPP_PID2.Size = new System.Drawing.Size(304, 29);
            this.metroComboBoxPP_PID2.Sorted = true;
            this.metroComboBoxPP_PID2.TabIndex = 147;
            this.metroComboBoxPP_PID2.UseSelectable = true;
            this.metroComboBoxPP_PID2.UseStyleColors = true;
            this.metroComboBoxPP_PID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPP_PID2_SelectedIndexChanged);
            // 
            // label264
            // 
            this.label264.AutoSize = true;
            this.label264.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label264.Location = new System.Drawing.Point(318, 0);
            this.label264.Name = "label264";
            this.label264.Size = new System.Drawing.Size(144, 14);
            this.label264.TabIndex = 146;
            this.label264.Text = "New SystemParameters ID:";
            // 
            // label265
            // 
            this.label265.AutoSize = true;
            this.label265.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label265.Location = new System.Drawing.Point(3, 0);
            this.label265.Name = "label265";
            this.label265.Size = new System.Drawing.Size(82, 14);
            this.label265.TabIndex = 145;
            this.label265.Text = "New Profile ID:";
            // 
            // buttonexppp
            // 
            this.buttonexppp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexppp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexppp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexppp.Location = new System.Drawing.Point(722, 146);
            this.buttonexppp.Name = "buttonexppp";
            this.buttonexppp.Size = new System.Drawing.Size(133, 45);
            this.buttonexppp.TabIndex = 159;
            this.buttonexppp.Text = "Export";
            this.buttonexppp.UseVisualStyleBackColor = false;
            this.buttonexppp.Click += new System.EventHandler(this.buttonexppp_Click);
            // 
            // labelSSVAL
            // 
            this.labelSSVAL.AutoSize = true;
            this.labelSSVAL.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSSVAL.Location = new System.Drawing.Point(331, 84);
            this.labelSSVAL.Name = "labelSSVAL";
            this.labelSSVAL.Size = new System.Drawing.Size(0, 14);
            this.labelSSVAL.TabIndex = 158;
            // 
            // buttonsavePP
            // 
            this.buttonsavePP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonsavePP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsavePP.Location = new System.Drawing.Point(694, 95);
            this.buttonsavePP.Name = "buttonsavePP";
            this.buttonsavePP.Size = new System.Drawing.Size(161, 45);
            this.buttonsavePP.TabIndex = 147;
            this.buttonsavePP.Text = "Save";
            this.buttonsavePP.UseVisualStyleBackColor = true;
            this.buttonsavePP.Visible = false;
            this.buttonsavePP.Click += new System.EventHandler(this.buttonsavePP_Click);
            // 
            // buttonDELPP
            // 
            this.buttonDELPP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELPP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELPP.Location = new System.Drawing.Point(3, 144);
            this.buttonDELPP.Name = "buttonDELPP";
            this.buttonDELPP.Size = new System.Drawing.Size(111, 41);
            this.buttonDELPP.TabIndex = 146;
            this.buttonDELPP.Text = "Delete";
            this.buttonDELPP.UseVisualStyleBackColor = true;
            this.buttonDELPP.Click += new System.EventHandler(this.buttonDELPP_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(612, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 18);
            this.label14.TabIndex = 144;
            this.label14.Text = "*";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.Red;
            this.label53.Location = new System.Drawing.Point(297, 24);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(15, 18);
            this.label53.TabIndex = 143;
            this.label53.Text = "*";
            // 
            // dgvPP
            // 
            this.dgvPP.AllowUserToAddRows = false;
            this.dgvPP.AllowUserToResizeRows = false;
            this.dgvPP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPP.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle874.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle874.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle874.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle874.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle874.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle874.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle874.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle874;
            this.dgvPP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle875.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle875.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle875.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle875.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle875.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle875.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle875.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPP.DefaultCellStyle = dataGridViewCellStyle875;
            this.dgvPP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPP.EnableHeadersVisualStyles = false;
            this.dgvPP.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPP.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPP.Location = new System.Drawing.Point(0, 164);
            this.dgvPP.MultiSelect = false;
            this.dgvPP.Name = "dgvPP";
            this.dgvPP.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle876.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle876.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle876.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle876.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle876.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle876.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle876.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPP.RowHeadersDefaultCellStyle = dataGridViewCellStyle876;
            this.dgvPP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPP.RowTemplate.Height = 33;
            this.dgvPP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPP.Size = new System.Drawing.Size(862, 401);
            this.dgvPP.TabIndex = 145;
            this.dgvPP.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPP_CellDoubleClick);
            // 
            // metroComboBoxPP_SPI
            // 
            this.metroComboBoxPP_SPI.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPP_SPI.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPP_SPI.FormattingEnabled = true;
            this.metroComboBoxPP_SPI.ItemHeight = 23;
            this.metroComboBoxPP_SPI.Location = new System.Drawing.Point(336, 52);
            this.metroComboBoxPP_SPI.Name = "metroComboBoxPP_SPI";
            this.metroComboBoxPP_SPI.Size = new System.Drawing.Size(349, 29);
            this.metroComboBoxPP_SPI.Sorted = true;
            this.metroComboBoxPP_SPI.TabIndex = 141;
            this.metroComboBoxPP_SPI.UseSelectable = true;
            this.metroComboBoxPP_SPI.UseStyleColors = true;
            this.metroComboBoxPP_SPI.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPP_SPI_SelectedIndexChanged);
            // 
            // metroComboBoxPP_PID
            // 
            this.metroComboBoxPP_PID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxPP_PID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxPP_PID.FormattingEnabled = true;
            this.metroComboBoxPP_PID.ItemHeight = 23;
            this.metroComboBoxPP_PID.Location = new System.Drawing.Point(21, 52);
            this.metroComboBoxPP_PID.Name = "metroComboBoxPP_PID";
            this.metroComboBoxPP_PID.Size = new System.Drawing.Size(304, 29);
            this.metroComboBoxPP_PID.Sorted = true;
            this.metroComboBoxPP_PID.TabIndex = 140;
            this.metroComboBoxPP_PID.UseSelectable = true;
            this.metroComboBoxPP_PID.UseStyleColors = true;
            this.metroComboBoxPP_PID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxPP_PID_SelectedIndexChanged);
            // 
            // buttonGenPP
            // 
            this.buttonGenPP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonGenPP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGenPP.Location = new System.Drawing.Point(694, 44);
            this.buttonGenPP.Name = "buttonGenPP";
            this.buttonGenPP.Size = new System.Drawing.Size(161, 45);
            this.buttonGenPP.TabIndex = 139;
            this.buttonGenPP.Text = "Generate";
            this.buttonGenPP.UseVisualStyleBackColor = true;
            this.buttonGenPP.Click += new System.EventHandler(this.buttonGenPP_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(331, 23);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(118, 14);
            this.label63.TabIndex = 138;
            this.label63.Text = "SystemParameters ID:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(16, 23);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(56, 14);
            this.label64.TabIndex = 137;
            this.label64.Text = "Profile ID:";
            // 
            // tb13
            // 
            this.tb13.Controls.Add(this.panel12);
            this.tb13.Location = new System.Drawing.Point(4, 34);
            this.tb13.Name = "tb13";
            this.tb13.Size = new System.Drawing.Size(862, 565);
            this.tb13.TabIndex = 12;
            this.tb13.Text = "System parameters";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel12.Controls.Add(this.panelSP);
            this.panel12.Controls.Add(this.buttonRemoveSP);
            this.panel12.Controls.Add(this.buttonexpsp);
            this.panel12.Controls.Add(this.buttonSaveSP);
            this.panel12.Controls.Add(this.buttonDELSP);
            this.panel12.Controls.Add(this.metroComboBoxSP_P);
            this.panel12.Controls.Add(this.buttonSP_Gen);
            this.panel12.Controls.Add(this.label101);
            this.panel12.Controls.Add(this.dgvSP);
            this.panel12.Controls.Add(this.label102);
            this.panel12.Controls.Add(this.metroComboBoxSP_T);
            this.panel12.Controls.Add(this.textBoxSP_V);
            this.panel12.Controls.Add(this.label72);
            this.panel12.Controls.Add(this.label65);
            this.panel12.Controls.Add(this.label300);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(862, 565);
            this.panel12.TabIndex = 80;
            // 
            // panelSP
            // 
            this.panelSP.Controls.Add(this.label301);
            this.panelSP.Controls.Add(this.metroComboBoxSP_T2);
            this.panelSP.Controls.Add(this.metroComboBoxSP_P2);
            this.panelSP.Controls.Add(this.label205);
            this.panelSP.Controls.Add(this.textBoxSP_V2);
            this.panelSP.Controls.Add(this.label206);
            this.panelSP.Controls.Add(this.label207);
            this.panelSP.Location = new System.Drawing.Point(9, 14);
            this.panelSP.Name = "panelSP";
            this.panelSP.Size = new System.Drawing.Size(816, 133);
            this.panelSP.TabIndex = 155;
            this.panelSP.Visible = false;
            // 
            // metroComboBoxSP_T2
            // 
            this.metroComboBoxSP_T2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxSP_T2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxSP_T2.FormattingEnabled = true;
            this.metroComboBoxSP_T2.ItemHeight = 23;
            this.metroComboBoxSP_T2.Items.AddRange(new object[] {
            "Int64",
            "string"});
            this.metroComboBoxSP_T2.Location = new System.Drawing.Point(473, 88);
            this.metroComboBoxSP_T2.Name = "metroComboBoxSP_T2";
            this.metroComboBoxSP_T2.Size = new System.Drawing.Size(328, 29);
            this.metroComboBoxSP_T2.Sorted = true;
            this.metroComboBoxSP_T2.TabIndex = 159;
            this.metroComboBoxSP_T2.UseSelectable = true;
            this.metroComboBoxSP_T2.UseStyleColors = true;
            // 
            // metroComboBoxSP_P2
            // 
            this.metroComboBoxSP_P2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxSP_P2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxSP_P2.FormattingEnabled = true;
            this.metroComboBoxSP_P2.ItemHeight = 23;
            this.metroComboBoxSP_P2.Location = new System.Drawing.Point(473, 36);
            this.metroComboBoxSP_P2.Name = "metroComboBoxSP_P2";
            this.metroComboBoxSP_P2.Size = new System.Drawing.Size(328, 29);
            this.metroComboBoxSP_P2.Sorted = true;
            this.metroComboBoxSP_P2.TabIndex = 158;
            this.metroComboBoxSP_P2.UseSelectable = true;
            this.metroComboBoxSP_P2.UseStyleColors = true;
            this.metroComboBoxSP_P2.TextChanged += new System.EventHandler(this.metroComboBoxSP_P2_TextChanged);
            // 
            // label205
            // 
            this.label205.AutoSize = true;
            this.label205.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label205.Location = new System.Drawing.Point(3, 7);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(62, 14);
            this.label205.TabIndex = 157;
            this.label205.Text = "New Value:";
            // 
            // textBoxSP_V2
            // 
            this.textBoxSP_V2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSP_V2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSP_V2.Font = new System.Drawing.Font("Google Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSP_V2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxSP_V2.Location = new System.Drawing.Point(2, 38);
            this.textBoxSP_V2.Name = "textBoxSP_V2";
            this.textBoxSP_V2.Size = new System.Drawing.Size(457, 27);
            this.textBoxSP_V2.TabIndex = 156;
            // 
            // label206
            // 
            this.label206.AutoSize = true;
            this.label206.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label206.ForeColor = System.Drawing.Color.Red;
            this.label206.Location = new System.Drawing.Point(773, 4);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(15, 18);
            this.label206.TabIndex = 155;
            this.label206.Text = "*";
            // 
            // label207
            // 
            this.label207.AutoSize = true;
            this.label207.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label207.Location = new System.Drawing.Point(468, 7);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(88, 14);
            this.label207.TabIndex = 154;
            this.label207.Text = "New Parameter:";
            // 
            // buttonRemoveSP
            // 
            this.buttonRemoveSP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonRemoveSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRemoveSP.Location = new System.Drawing.Point(117, 210);
            this.buttonRemoveSP.Name = "buttonRemoveSP";
            this.buttonRemoveSP.Size = new System.Drawing.Size(187, 41);
            this.buttonRemoveSP.TabIndex = 158;
            this.buttonRemoveSP.Text = "Remove Redundancies";
            this.buttonRemoveSP.UseVisualStyleBackColor = true;
            this.buttonRemoveSP.Visible = false;
            this.buttonRemoveSP.Click += new System.EventHandler(this.buttonRemoveSP_Click);
            // 
            // buttonexpsp
            // 
            this.buttonexpsp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpsp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpsp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpsp.Location = new System.Drawing.Point(677, 208);
            this.buttonexpsp.Name = "buttonexpsp";
            this.buttonexpsp.Size = new System.Drawing.Size(133, 45);
            this.buttonexpsp.TabIndex = 157;
            this.buttonexpsp.Text = "Export";
            this.buttonexpsp.UseVisualStyleBackColor = false;
            this.buttonexpsp.Click += new System.EventHandler(this.buttonexpsp_Click);
            // 
            // buttonSaveSP
            // 
            this.buttonSaveSP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveSP.Location = new System.Drawing.Point(510, 153);
            this.buttonSaveSP.Name = "buttonSaveSP";
            this.buttonSaveSP.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveSP.TabIndex = 156;
            this.buttonSaveSP.Text = "Save";
            this.buttonSaveSP.UseVisualStyleBackColor = true;
            this.buttonSaveSP.Visible = false;
            this.buttonSaveSP.Click += new System.EventHandler(this.buttonSaveSP_Click);
            // 
            // buttonDELSP
            // 
            this.buttonDELSP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELSP.Location = new System.Drawing.Point(0, 210);
            this.buttonDELSP.Name = "buttonDELSP";
            this.buttonDELSP.Size = new System.Drawing.Size(111, 41);
            this.buttonDELSP.TabIndex = 154;
            this.buttonDELSP.Text = "Delete";
            this.buttonDELSP.UseVisualStyleBackColor = true;
            this.buttonDELSP.Click += new System.EventHandler(this.buttonDELSP_Click);
            // 
            // metroComboBoxSP_P
            // 
            this.metroComboBoxSP_P.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxSP_P.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxSP_P.FormattingEnabled = true;
            this.metroComboBoxSP_P.ItemHeight = 23;
            this.metroComboBoxSP_P.Location = new System.Drawing.Point(481, 48);
            this.metroComboBoxSP_P.Name = "metroComboBoxSP_P";
            this.metroComboBoxSP_P.Size = new System.Drawing.Size(328, 29);
            this.metroComboBoxSP_P.Sorted = true;
            this.metroComboBoxSP_P.TabIndex = 153;
            this.metroComboBoxSP_P.UseSelectable = true;
            this.metroComboBoxSP_P.UseStyleColors = true;
            this.metroComboBoxSP_P.TextChanged += new System.EventHandler(this.metroComboBoxSP_P_TextChanged);
            // 
            // buttonSP_Gen
            // 
            this.buttonSP_Gen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSP_Gen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSP_Gen.Location = new System.Drawing.Point(649, 153);
            this.buttonSP_Gen.Name = "buttonSP_Gen";
            this.buttonSP_Gen.Size = new System.Drawing.Size(161, 44);
            this.buttonSP_Gen.TabIndex = 152;
            this.buttonSP_Gen.Text = "Generate";
            this.buttonSP_Gen.UseVisualStyleBackColor = true;
            this.buttonSP_Gen.Click += new System.EventHandler(this.buttonSP_Gen_Click);
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.ForeColor = System.Drawing.Color.Red;
            this.label101.Location = new System.Drawing.Point(867, 19);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(15, 18);
            this.label101.TabIndex = 149;
            this.label101.Text = "*";
            // 
            // dgvSP
            // 
            this.dgvSP.AllowUserToAddRows = false;
            this.dgvSP.AllowUserToResizeRows = false;
            this.dgvSP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSP.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvSP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle838.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle838.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle838.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle838.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle838.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle838.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle838.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle838;
            this.dgvSP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle839.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle839.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle839.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle839.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle839.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle839.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle839.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSP.DefaultCellStyle = dataGridViewCellStyle839;
            this.dgvSP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvSP.EnableHeadersVisualStyles = false;
            this.dgvSP.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvSP.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSP.Location = new System.Drawing.Point(0, 237);
            this.dgvSP.MultiSelect = false;
            this.dgvSP.Name = "dgvSP";
            this.dgvSP.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle840.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle840.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle840.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle840.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle840.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle840.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle840.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSP.RowHeadersDefaultCellStyle = dataGridViewCellStyle840;
            this.dgvSP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSP.RowTemplate.Height = 33;
            this.dgvSP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSP.Size = new System.Drawing.Size(862, 328);
            this.dgvSP.TabIndex = 151;
            this.dgvSP.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSP_CellDoubleClick);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(18, 19);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(36, 14);
            this.label102.TabIndex = 148;
            this.label102.Text = "Value:";
            // 
            // metroComboBoxSP_T
            // 
            this.metroComboBoxSP_T.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxSP_T.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxSP_T.FormattingEnabled = true;
            this.metroComboBoxSP_T.ItemHeight = 23;
            this.metroComboBoxSP_T.Items.AddRange(new object[] {
            "Int64",
            "string"});
            this.metroComboBoxSP_T.Location = new System.Drawing.Point(482, 102);
            this.metroComboBoxSP_T.Name = "metroComboBoxSP_T";
            this.metroComboBoxSP_T.Size = new System.Drawing.Size(326, 29);
            this.metroComboBoxSP_T.Sorted = true;
            this.metroComboBoxSP_T.TabIndex = 145;
            this.metroComboBoxSP_T.UseSelectable = true;
            this.metroComboBoxSP_T.UseStyleColors = true;
            // 
            // textBoxSP_V
            // 
            this.textBoxSP_V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSP_V.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSP_V.Font = new System.Drawing.Font("Google Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSP_V.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxSP_V.Location = new System.Drawing.Point(17, 50);
            this.textBoxSP_V.Name = "textBoxSP_V";
            this.textBoxSP_V.Size = new System.Drawing.Size(457, 27);
            this.textBoxSP_V.TabIndex = 147;
            this.textBoxSP_V.TextChanged += new System.EventHandler(this.textBoxSP_V_TextChanged);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(476, 19);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(62, 14);
            this.label72.TabIndex = 119;
            this.label72.Text = "Parameter:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Red;
            this.label65.Location = new System.Drawing.Point(781, 16);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(15, 18);
            this.label65.TabIndex = 120;
            this.label65.Text = "*";
            // 
            // tb14
            // 
            this.tb14.Controls.Add(this.panel13);
            this.tb14.Location = new System.Drawing.Point(4, 34);
            this.tb14.Name = "tb14";
            this.tb14.Size = new System.Drawing.Size(862, 565);
            this.tb14.TabIndex = 13;
            this.tb14.Text = "Distance Based Increment Fares";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel13.Controls.Add(this.panelDBIF);
            this.panel13.Controls.Add(this.buttonexpdbif);
            this.panel13.Controls.Add(this.buttonSAVE_DBIF);
            this.panel13.Controls.Add(this.buttonDELDBIF);
            this.panel13.Controls.Add(this.DBIF_ftid);
            this.panel13.Controls.Add(this.label111);
            this.panel13.Controls.Add(this.label110);
            this.panel13.Controls.Add(this.label109);
            this.panel13.Controls.Add(this.buttonCreate_DBIF);
            this.panel13.Controls.Add(this.label104);
            this.panel13.Controls.Add(this.DBIF_ifd);
            this.panel13.Controls.Add(this.label105);
            this.panel13.Controls.Add(this.label106);
            this.panel13.Controls.Add(this.DBIF_sd);
            this.panel13.Controls.Add(this.DBIF_ifa);
            this.panel13.Controls.Add(this.label108);
            this.panel13.Controls.Add(this.dgvDBIF);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(862, 565);
            this.panel13.TabIndex = 80;
            // 
            // panelDBIF
            // 
            this.panelDBIF.Controls.Add(this.checkBoxOneDBIF);
            this.panelDBIF.Controls.Add(this.cbxNewFTIDDBIF);
            this.panelDBIF.Controls.Add(this.label196);
            this.panelDBIF.Controls.Add(this.label197);
            this.panelDBIF.Controls.Add(this.label198);
            this.panelDBIF.Controls.Add(this.label199);
            this.panelDBIF.Controls.Add(this.textBoxNIFD_DBIF);
            this.panelDBIF.Controls.Add(this.label201);
            this.panelDBIF.Controls.Add(this.textBoxNSDDBIF);
            this.panelDBIF.Controls.Add(this.textBoxNIF_DBIF);
            this.panelDBIF.Controls.Add(this.label202);
            this.panelDBIF.Location = new System.Drawing.Point(32, 36);
            this.panelDBIF.Name = "panelDBIF";
            this.panelDBIF.Size = new System.Drawing.Size(640, 157);
            this.panelDBIF.TabIndex = 83;
            this.panelDBIF.Visible = false;
            // 
            // checkBoxOneDBIF
            // 
            this.checkBoxOneDBIF.AutoSize = true;
            this.checkBoxOneDBIF.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxOneDBIF.Location = new System.Drawing.Point(8, 79);
            this.checkBoxOneDBIF.Name = "checkBoxOneDBIF";
            this.checkBoxOneDBIF.Size = new System.Drawing.Size(99, 18);
            this.checkBoxOneDBIF.TabIndex = 170;
            this.checkBoxOneDBIF.Text = "1:1 Relationship";
            this.checkBoxOneDBIF.UseVisualStyleBackColor = true;
            // 
            // cbxNewFTIDDBIF
            // 
            this.cbxNewFTIDDBIF.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.cbxNewFTIDDBIF.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbxNewFTIDDBIF.FormattingEnabled = true;
            this.cbxNewFTIDDBIF.ItemHeight = 23;
            this.cbxNewFTIDDBIF.Location = new System.Drawing.Point(8, 37);
            this.cbxNewFTIDDBIF.Name = "cbxNewFTIDDBIF";
            this.cbxNewFTIDDBIF.Size = new System.Drawing.Size(200, 29);
            this.cbxNewFTIDDBIF.Sorted = true;
            this.cbxNewFTIDDBIF.TabIndex = 169;
            this.cbxNewFTIDDBIF.UseSelectable = true;
            this.cbxNewFTIDDBIF.UseStyleColors = true;
            this.cbxNewFTIDDBIF.SelectedIndexChanged += new System.EventHandler(this.cbxNewFTIDDBIF_SelectedIndexChanged);
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label196.ForeColor = System.Drawing.Color.Red;
            this.label196.Location = new System.Drawing.Point(614, 9);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(15, 18);
            this.label196.TabIndex = 168;
            this.label196.Text = "*";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label197.ForeColor = System.Drawing.Color.Red;
            this.label197.Location = new System.Drawing.Point(397, 9);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(15, 18);
            this.label197.TabIndex = 167;
            this.label197.Text = "*";
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label198.ForeColor = System.Drawing.Color.Red;
            this.label198.Location = new System.Drawing.Point(180, 9);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(15, 18);
            this.label198.TabIndex = 166;
            this.label198.Text = "*";
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label199.Location = new System.Drawing.Point(431, 9);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(166, 14);
            this.label199.TabIndex = 164;
            this.label199.Text = "New Incremental Fare Distance:";
            // 
            // textBoxNIFD_DBIF
            // 
            this.textBoxNIFD_DBIF.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNIFD_DBIF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNIFD_DBIF.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNIFD_DBIF.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNIFD_DBIF.Location = new System.Drawing.Point(436, 38);
            this.textBoxNIFD_DBIF.Name = "textBoxNIFD_DBIF";
            this.textBoxNIFD_DBIF.Size = new System.Drawing.Size(200, 24);
            this.textBoxNIFD_DBIF.TabIndex = 163;
            this.textBoxNIFD_DBIF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label201.Location = new System.Drawing.Point(220, 9);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(163, 14);
            this.label201.TabIndex = 161;
            this.label201.Text = "New Incremental Fare Amount:";
            // 
            // textBoxNSDDBIF
            // 
            this.textBoxNSDDBIF.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNSDDBIF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNSDDBIF.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNSDDBIF.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNSDDBIF.Location = new System.Drawing.Point(8, 113);
            this.textBoxNSDDBIF.Name = "textBoxNSDDBIF";
            this.textBoxNSDDBIF.Size = new System.Drawing.Size(206, 24);
            this.textBoxNSDDBIF.TabIndex = 160;
            this.textBoxNSDDBIF.Visible = false;
            // 
            // textBoxNIF_DBIF
            // 
            this.textBoxNIF_DBIF.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxNIF_DBIF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNIF_DBIF.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNIF_DBIF.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBoxNIF_DBIF.Location = new System.Drawing.Point(225, 38);
            this.textBoxNIF_DBIF.Name = "textBoxNIF_DBIF";
            this.textBoxNIF_DBIF.Size = new System.Drawing.Size(200, 24);
            this.textBoxNIF_DBIF.TabIndex = 159;
            this.textBoxNIF_DBIF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label202
            // 
            this.label202.AutoSize = true;
            this.label202.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label202.Location = new System.Drawing.Point(3, 0);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(101, 14);
            this.label202.TabIndex = 158;
            this.label202.Text = "New Fare Table ID:";
            // 
            // buttonexpdbif
            // 
            this.buttonexpdbif.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpdbif.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpdbif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpdbif.Location = new System.Drawing.Point(680, 245);
            this.buttonexpdbif.Name = "buttonexpdbif";
            this.buttonexpdbif.Size = new System.Drawing.Size(133, 45);
            this.buttonexpdbif.TabIndex = 160;
            this.buttonexpdbif.Text = "Export";
            this.buttonexpdbif.UseVisualStyleBackColor = false;
            this.buttonexpdbif.Click += new System.EventHandler(this.buttonexpdbif_Click);
            // 
            // buttonSAVE_DBIF
            // 
            this.buttonSAVE_DBIF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVE_DBIF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVE_DBIF.Location = new System.Drawing.Point(680, 115);
            this.buttonSAVE_DBIF.Name = "buttonSAVE_DBIF";
            this.buttonSAVE_DBIF.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVE_DBIF.TabIndex = 159;
            this.buttonSAVE_DBIF.Text = "Save";
            this.buttonSAVE_DBIF.UseVisualStyleBackColor = true;
            this.buttonSAVE_DBIF.Visible = false;
            this.buttonSAVE_DBIF.Click += new System.EventHandler(this.buttonSAVE_DBIF_Click);
            // 
            // buttonDELDBIF
            // 
            this.buttonDELDBIF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELDBIF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELDBIF.Location = new System.Drawing.Point(0, 259);
            this.buttonDELDBIF.Name = "buttonDELDBIF";
            this.buttonDELDBIF.Size = new System.Drawing.Size(111, 41);
            this.buttonDELDBIF.TabIndex = 158;
            this.buttonDELDBIF.Text = "Delete";
            this.buttonDELDBIF.UseVisualStyleBackColor = true;
            this.buttonDELDBIF.Click += new System.EventHandler(this.buttonDELDBIF_Click);
            // 
            // DBIF_ftid
            // 
            this.DBIF_ftid.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.DBIF_ftid.ForeColor = System.Drawing.SystemColors.WindowText;
            this.DBIF_ftid.FormattingEnabled = true;
            this.DBIF_ftid.ItemHeight = 23;
            this.DBIF_ftid.Location = new System.Drawing.Point(40, 73);
            this.DBIF_ftid.Name = "DBIF_ftid";
            this.DBIF_ftid.Size = new System.Drawing.Size(200, 29);
            this.DBIF_ftid.Sorted = true;
            this.DBIF_ftid.TabIndex = 157;
            this.DBIF_ftid.UseSelectable = true;
            this.DBIF_ftid.UseStyleColors = true;
            this.DBIF_ftid.SelectedIndexChanged += new System.EventHandler(this.DBIF_ftid_SelectedIndexChanged);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.ForeColor = System.Drawing.Color.Red;
            this.label111.Location = new System.Drawing.Point(646, 45);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(15, 18);
            this.label111.TabIndex = 155;
            this.label111.Text = "*";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.ForeColor = System.Drawing.Color.Red;
            this.label110.Location = new System.Drawing.Point(429, 45);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(15, 18);
            this.label110.TabIndex = 154;
            this.label110.Text = "*";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.ForeColor = System.Drawing.Color.Red;
            this.label109.Location = new System.Drawing.Point(212, 45);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(15, 18);
            this.label109.TabIndex = 153;
            this.label109.Text = "*";
            // 
            // buttonCreate_DBIF
            // 
            this.buttonCreate_DBIF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonCreate_DBIF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreate_DBIF.Location = new System.Drawing.Point(680, 64);
            this.buttonCreate_DBIF.Name = "buttonCreate_DBIF";
            this.buttonCreate_DBIF.Size = new System.Drawing.Size(133, 45);
            this.buttonCreate_DBIF.TabIndex = 152;
            this.buttonCreate_DBIF.Text = "Create";
            this.buttonCreate_DBIF.UseVisualStyleBackColor = true;
            this.buttonCreate_DBIF.Click += new System.EventHandler(this.buttonCreate_DBIF_Click);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(463, 45);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(140, 14);
            this.label104.TabIndex = 151;
            this.label104.Text = "Incremental Fare Distance:";
            // 
            // DBIF_ifd
            // 
            this.DBIF_ifd.BackColor = System.Drawing.SystemColors.HighlightText;
            this.DBIF_ifd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DBIF_ifd.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DBIF_ifd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.DBIF_ifd.Location = new System.Drawing.Point(468, 74);
            this.DBIF_ifd.Name = "DBIF_ifd";
            this.DBIF_ifd.Size = new System.Drawing.Size(200, 24);
            this.DBIF_ifd.TabIndex = 150;
            this.DBIF_ifd.TextChanged += new System.EventHandler(this.DBIF_ifd_TextChanged);
            this.DBIF_ifd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(35, 120);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(80, 14);
            this.label105.TabIndex = 149;
            this.label105.Text = "Start Distance:";
            this.label105.Visible = false;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(252, 45);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(137, 14);
            this.label106.TabIndex = 148;
            this.label106.Text = "Incremental Fare Amount:";
            // 
            // DBIF_sd
            // 
            this.DBIF_sd.BackColor = System.Drawing.SystemColors.HighlightText;
            this.DBIF_sd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DBIF_sd.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DBIF_sd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.DBIF_sd.Location = new System.Drawing.Point(40, 149);
            this.DBIF_sd.Name = "DBIF_sd";
            this.DBIF_sd.Size = new System.Drawing.Size(206, 24);
            this.DBIF_sd.TabIndex = 147;
            this.DBIF_sd.Visible = false;
            this.DBIF_sd.TextChanged += new System.EventHandler(this.DBIF_sd_TextChanged);
            this.DBIF_sd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // DBIF_ifa
            // 
            this.DBIF_ifa.BackColor = System.Drawing.SystemColors.HighlightText;
            this.DBIF_ifa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DBIF_ifa.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DBIF_ifa.ForeColor = System.Drawing.SystemColors.MenuText;
            this.DBIF_ifa.Location = new System.Drawing.Point(257, 74);
            this.DBIF_ifa.Name = "DBIF_ifa";
            this.DBIF_ifa.Size = new System.Drawing.Size(200, 24);
            this.DBIF_ifa.TabIndex = 146;
            this.DBIF_ifa.TextChanged += new System.EventHandler(this.DBIF_ifa_TextChanged);
            this.DBIF_ifa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(35, 36);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(75, 14);
            this.label108.TabIndex = 143;
            this.label108.Text = "Fare Table ID:";
            // 
            // dgvDBIF
            // 
            this.dgvDBIF.AllowUserToAddRows = false;
            this.dgvDBIF.AllowUserToResizeRows = false;
            this.dgvDBIF.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDBIF.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBIF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDBIF.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDBIF.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle877.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle877.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle877.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle877.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle877.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle877.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle877.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBIF.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle877;
            this.dgvDBIF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle878.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle878.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle878.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle878.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle878.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle878.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle878.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDBIF.DefaultCellStyle = dataGridViewCellStyle878;
            this.dgvDBIF.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDBIF.EnableHeadersVisualStyles = false;
            this.dgvDBIF.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDBIF.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBIF.Location = new System.Drawing.Point(0, 279);
            this.dgvDBIF.MultiSelect = false;
            this.dgvDBIF.Name = "dgvDBIF";
            this.dgvDBIF.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle879.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle879.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle879.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle879.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle879.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle879.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle879.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBIF.RowHeadersDefaultCellStyle = dataGridViewCellStyle879;
            this.dgvDBIF.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDBIF.RowTemplate.Height = 33;
            this.dgvDBIF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDBIF.Size = new System.Drawing.Size(862, 286);
            this.dgvDBIF.TabIndex = 145;
            this.dgvDBIF.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDBIF_CellDoubleClick);
            // 
            // tb15
            // 
            this.tb15.Controls.Add(this.panel15);
            this.tb15.Location = new System.Drawing.Point(4, 34);
            this.tb15.Name = "tb15";
            this.tb15.Size = new System.Drawing.Size(862, 565);
            this.tb15.TabIndex = 14;
            this.tb15.Text = "User Accounts";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel15.Controls.Add(this.buttonexpua);
            this.panel15.Controls.Add(this.panelUA);
            this.panel15.Controls.Add(this.buttonSaveUA);
            this.panel15.Controls.Add(this.label20);
            this.panel15.Controls.Add(this.buttonDELUA);
            this.panel15.Controls.Add(this.buttonUP_UA);
            this.panel15.Controls.Add(this.label121);
            this.panel15.Controls.Add(this.metroDateTimeEDUA2);
            this.panel15.Controls.Add(this.label122);
            this.panel15.Controls.Add(this.dgvUA);
            this.panel15.Controls.Add(this.metroDateTimeEDUA);
            this.panel15.Controls.Add(this.label119);
            this.panel15.Controls.Add(this.label120);
            this.panel15.Controls.Add(this.textBox_UA_SN);
            this.panel15.Controls.Add(this.label117);
            this.panel15.Controls.Add(this.label118);
            this.panel15.Controls.Add(this.textBox_UA_LN);
            this.panel15.Controls.Add(this.label115);
            this.panel15.Controls.Add(this.label116);
            this.panel15.Controls.Add(this.textBoxUA_CID);
            this.panel15.Controls.Add(this.metroComboBoxUA_MN);
            this.panel15.Controls.Add(this.label113);
            this.panel15.Controls.Add(this.label114);
            this.panel15.Controls.Add(this.label17);
            this.panel15.Controls.Add(this.label41);
            this.panel15.Controls.Add(this.textBox_UA_UID);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(862, 565);
            this.panel15.TabIndex = 83;
            // 
            // buttonexpua
            // 
            this.buttonexpua.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpua.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpua.Location = new System.Drawing.Point(717, 312);
            this.buttonexpua.Name = "buttonexpua";
            this.buttonexpua.Size = new System.Drawing.Size(133, 45);
            this.buttonexpua.TabIndex = 208;
            this.buttonexpua.Text = "Export";
            this.buttonexpua.UseVisualStyleBackColor = false;
            this.buttonexpua.Click += new System.EventHandler(this.buttonexpua_Click);
            // 
            // panelUA
            // 
            this.panelUA.Controls.Add(this.label226);
            this.panelUA.Controls.Add(this.label227);
            this.panelUA.Controls.Add(this.metroDateTimeEDUA2second);
            this.panelUA.Controls.Add(this.label236);
            this.panelUA.Controls.Add(this.metroDateTimeEDUAsecond);
            this.panelUA.Controls.Add(this.label237);
            this.panelUA.Controls.Add(this.textBox_UA_SN2);
            this.panelUA.Controls.Add(this.label238);
            this.panelUA.Controls.Add(this.label239);
            this.panelUA.Controls.Add(this.textBox_UA_LN2);
            this.panelUA.Controls.Add(this.label240);
            this.panelUA.Controls.Add(this.label241);
            this.panelUA.Controls.Add(this.textBoxUA_CID2);
            this.panelUA.Controls.Add(this.metroComboBoxUA_MN2);
            this.panelUA.Controls.Add(this.label242);
            this.panelUA.Controls.Add(this.label243);
            this.panelUA.Controls.Add(this.label244);
            this.panelUA.Controls.Add(this.label245);
            this.panelUA.Controls.Add(this.textBox_UA_UID2);
            this.panelUA.Location = new System.Drawing.Point(19, 19);
            this.panelUA.Name = "panelUA";
            this.panelUA.Size = new System.Drawing.Size(838, 236);
            this.panelUA.TabIndex = 83;
            this.panelUA.Visible = false;
            // 
            // label226
            // 
            this.label226.AutoSize = true;
            this.label226.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label226.ForeColor = System.Drawing.Color.Red;
            this.label226.Location = new System.Drawing.Point(804, 5);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(15, 18);
            this.label226.TabIndex = 197;
            this.label226.Text = "*";
            // 
            // label227
            // 
            this.label227.AutoSize = true;
            this.label227.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label227.Location = new System.Drawing.Point(213, 194);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(18, 14);
            this.label227.TabIndex = 196;
            this.label227.Text = "to";
            // 
            // metroDateTimeEDUA2second
            // 
            this.metroDateTimeEDUA2second.Location = new System.Drawing.Point(231, 185);
            this.metroDateTimeEDUA2second.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeEDUA2second.Name = "metroDateTimeEDUA2second";
            this.metroDateTimeEDUA2second.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeEDUA2second.TabIndex = 195;
            // 
            // label236
            // 
            this.label236.AutoSize = true;
            this.label236.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label236.Location = new System.Drawing.Point(6, 156);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(78, 14);
            this.label236.TabIndex = 194;
            this.label236.Text = "Effective Date";
            // 
            // metroDateTimeEDUAsecond
            // 
            this.metroDateTimeEDUAsecond.Location = new System.Drawing.Point(10, 185);
            this.metroDateTimeEDUAsecond.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeEDUAsecond.Name = "metroDateTimeEDUAsecond";
            this.metroDateTimeEDUAsecond.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeEDUAsecond.TabIndex = 193;
            // 
            // label237
            // 
            this.label237.AutoSize = true;
            this.label237.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label237.Location = new System.Drawing.Point(571, 4);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(70, 14);
            this.label237.TabIndex = 192;
            this.label237.Text = "Short Name:";
            // 
            // textBox_UA_SN2
            // 
            this.textBox_UA_SN2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_SN2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_SN2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_SN2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_SN2.Location = new System.Drawing.Point(576, 33);
            this.textBox_UA_SN2.MaxLength = 10;
            this.textBox_UA_SN2.Name = "textBox_UA_SN2";
            this.textBox_UA_SN2.Size = new System.Drawing.Size(255, 24);
            this.textBox_UA_SN2.TabIndex = 191;
            // 
            // label238
            // 
            this.label238.AutoSize = true;
            this.label238.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label238.ForeColor = System.Drawing.Color.Red;
            this.label238.Location = new System.Drawing.Point(537, 4);
            this.label238.Name = "label238";
            this.label238.Size = new System.Drawing.Size(15, 18);
            this.label238.TabIndex = 190;
            this.label238.Text = "*";
            // 
            // label239
            // 
            this.label239.AutoSize = true;
            this.label239.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label239.Location = new System.Drawing.Point(195, 4);
            this.label239.Name = "label239";
            this.label239.Size = new System.Drawing.Size(69, 14);
            this.label239.TabIndex = 189;
            this.label239.Text = "Long Name:";
            // 
            // textBox_UA_LN2
            // 
            this.textBox_UA_LN2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_LN2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_LN2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_LN2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_LN2.Location = new System.Drawing.Point(200, 33);
            this.textBox_UA_LN2.MaxLength = 80;
            this.textBox_UA_LN2.Name = "textBox_UA_LN2";
            this.textBox_UA_LN2.Size = new System.Drawing.Size(370, 24);
            this.textBox_UA_LN2.TabIndex = 188;
            // 
            // label240
            // 
            this.label240.AutoSize = true;
            this.label240.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label240.ForeColor = System.Drawing.Color.Red;
            this.label240.Location = new System.Drawing.Point(803, 86);
            this.label240.Name = "label240";
            this.label240.Size = new System.Drawing.Size(15, 18);
            this.label240.TabIndex = 187;
            this.label240.Text = "*";
            // 
            // label241
            // 
            this.label241.AutoSize = true;
            this.label241.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label241.Location = new System.Drawing.Point(459, 86);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(74, 14);
            this.label241.TabIndex = 186;
            this.label241.Text = "Company ID:";
            // 
            // textBoxUA_CID2
            // 
            this.textBoxUA_CID2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxUA_CID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUA_CID2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUA_CID2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxUA_CID2.Location = new System.Drawing.Point(464, 116);
            this.textBoxUA_CID2.Name = "textBoxUA_CID2";
            this.textBoxUA_CID2.Size = new System.Drawing.Size(367, 24);
            this.textBoxUA_CID2.TabIndex = 185;
            // 
            // metroComboBoxUA_MN2
            // 
            this.metroComboBoxUA_MN2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxUA_MN2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxUA_MN2.FormattingEnabled = true;
            this.metroComboBoxUA_MN2.ItemHeight = 23;
            this.metroComboBoxUA_MN2.Location = new System.Drawing.Point(8, 114);
            this.metroComboBoxUA_MN2.Name = "metroComboBoxUA_MN2";
            this.metroComboBoxUA_MN2.Size = new System.Drawing.Size(450, 29);
            this.metroComboBoxUA_MN2.Sorted = true;
            this.metroComboBoxUA_MN2.TabIndex = 184;
            this.metroComboBoxUA_MN2.UseSelectable = true;
            this.metroComboBoxUA_MN2.UseStyleColors = true;
            this.metroComboBoxUA_MN2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxUA_MN2_SelectedIndexChanged);
            // 
            // label242
            // 
            this.label242.AutoSize = true;
            this.label242.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label242.ForeColor = System.Drawing.Color.Red;
            this.label242.Location = new System.Drawing.Point(430, 88);
            this.label242.Name = "label242";
            this.label242.Size = new System.Drawing.Size(15, 18);
            this.label242.TabIndex = 183;
            this.label242.Text = "*";
            // 
            // label243
            // 
            this.label243.AutoSize = true;
            this.label243.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label243.Location = new System.Drawing.Point(3, 87);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(91, 14);
            this.label243.TabIndex = 182;
            this.label243.Text = "Merchant Name:";
            // 
            // label244
            // 
            this.label244.AutoSize = true;
            this.label244.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label244.ForeColor = System.Drawing.Color.Red;
            this.label244.Location = new System.Drawing.Point(175, 4);
            this.label244.Name = "label244";
            this.label244.Size = new System.Drawing.Size(15, 18);
            this.label244.TabIndex = 181;
            this.label244.Text = "*";
            // 
            // label245
            // 
            this.label245.AutoSize = true;
            this.label245.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label245.Location = new System.Drawing.Point(3, 4);
            this.label245.Name = "label245";
            this.label245.Size = new System.Drawing.Size(72, 14);
            this.label245.TabIndex = 180;
            this.label245.Text = "New User ID:";
            // 
            // textBox_UA_UID2
            // 
            this.textBox_UA_UID2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_UID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_UID2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_UID2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_UID2.Location = new System.Drawing.Point(8, 33);
            this.textBox_UA_UID2.MaxLength = 10;
            this.textBox_UA_UID2.Name = "textBox_UA_UID2";
            this.textBox_UA_UID2.Size = new System.Drawing.Size(188, 24);
            this.textBox_UA_UID2.TabIndex = 179;
            this.textBox_UA_UID2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // buttonSaveUA
            // 
            this.buttonSaveUA.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveUA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveUA.Location = new System.Drawing.Point(578, 262);
            this.buttonSaveUA.Name = "buttonSaveUA";
            this.buttonSaveUA.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveUA.TabIndex = 207;
            this.buttonSaveUA.Text = "Save";
            this.buttonSaveUA.UseVisualStyleBackColor = true;
            this.buttonSaveUA.Visible = false;
            this.buttonSaveUA.Click += new System.EventHandler(this.buttonSaveUA_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(823, 24);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 18);
            this.label20.TabIndex = 178;
            this.label20.Text = "*";
            // 
            // buttonDELUA
            // 
            this.buttonDELUA.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELUA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELUA.Location = new System.Drawing.Point(9, 314);
            this.buttonDELUA.Name = "buttonDELUA";
            this.buttonDELUA.Size = new System.Drawing.Size(111, 41);
            this.buttonDELUA.TabIndex = 177;
            this.buttonDELUA.Text = "Delete";
            this.buttonDELUA.UseVisualStyleBackColor = true;
            this.buttonDELUA.Visible = false;
            this.buttonDELUA.Click += new System.EventHandler(this.buttonDELUA_Click);
            // 
            // buttonUP_UA
            // 
            this.buttonUP_UA.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUP_UA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUP_UA.Location = new System.Drawing.Point(717, 261);
            this.buttonUP_UA.Name = "buttonUP_UA";
            this.buttonUP_UA.Size = new System.Drawing.Size(133, 45);
            this.buttonUP_UA.TabIndex = 176;
            this.buttonUP_UA.Text = "Add";
            this.buttonUP_UA.UseVisualStyleBackColor = true;
            this.buttonUP_UA.Click += new System.EventHandler(this.buttonUP_UA_Click);
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(232, 213);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(18, 14);
            this.label121.TabIndex = 173;
            this.label121.Text = "to";
            // 
            // metroDateTimeEDUA2
            // 
            this.metroDateTimeEDUA2.Location = new System.Drawing.Point(250, 204);
            this.metroDateTimeEDUA2.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeEDUA2.Name = "metroDateTimeEDUA2";
            this.metroDateTimeEDUA2.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeEDUA2.TabIndex = 172;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(25, 175);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(78, 14);
            this.label122.TabIndex = 171;
            this.label122.Text = "Effective Date";
            // 
            // dgvUA
            // 
            this.dgvUA.AllowUserToAddRows = false;
            this.dgvUA.AllowUserToResizeRows = false;
            this.dgvUA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUA.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvUA.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvUA.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle880.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle880.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle880.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle880.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle880.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle880.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle880.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle880;
            this.dgvUA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle881.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle881.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle881.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle881.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle881.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle881.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle881.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUA.DefaultCellStyle = dataGridViewCellStyle881;
            this.dgvUA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvUA.EnableHeadersVisualStyles = false;
            this.dgvUA.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvUA.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUA.Location = new System.Drawing.Point(0, 333);
            this.dgvUA.MultiSelect = false;
            this.dgvUA.Name = "dgvUA";
            this.dgvUA.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle882.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle882.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle882.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle882.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle882.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle882.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle882.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUA.RowHeadersDefaultCellStyle = dataGridViewCellStyle882;
            this.dgvUA.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUA.RowTemplate.Height = 33;
            this.dgvUA.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUA.Size = new System.Drawing.Size(862, 232);
            this.dgvUA.TabIndex = 174;
            this.dgvUA.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUA_CellDoubleClick);
            // 
            // metroDateTimeEDUA
            // 
            this.metroDateTimeEDUA.Location = new System.Drawing.Point(29, 204);
            this.metroDateTimeEDUA.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeEDUA.Name = "metroDateTimeEDUA";
            this.metroDateTimeEDUA.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeEDUA.TabIndex = 170;
            this.metroDateTimeEDUA.ValueChanged += new System.EventHandler(this.metroDateTimeEDUA_ValueChanged);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.ForeColor = System.Drawing.Color.Red;
            this.label119.Location = new System.Drawing.Point(877, 23);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(15, 18);
            this.label119.TabIndex = 169;
            this.label119.Text = "*";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(590, 23);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(70, 14);
            this.label120.TabIndex = 168;
            this.label120.Text = "Short Name:";
            // 
            // textBox_UA_SN
            // 
            this.textBox_UA_SN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_SN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_SN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_SN.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_SN.Location = new System.Drawing.Point(595, 52);
            this.textBox_UA_SN.MaxLength = 10;
            this.textBox_UA_SN.Name = "textBox_UA_SN";
            this.textBox_UA_SN.Size = new System.Drawing.Size(255, 24);
            this.textBox_UA_SN.TabIndex = 167;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.ForeColor = System.Drawing.Color.Red;
            this.label117.Location = new System.Drawing.Point(556, 23);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(15, 18);
            this.label117.TabIndex = 166;
            this.label117.Text = "*";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(214, 23);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(69, 14);
            this.label118.TabIndex = 165;
            this.label118.Text = "Long Name:";
            // 
            // textBox_UA_LN
            // 
            this.textBox_UA_LN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_LN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_LN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_LN.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_LN.Location = new System.Drawing.Point(219, 52);
            this.textBox_UA_LN.MaxLength = 80;
            this.textBox_UA_LN.Name = "textBox_UA_LN";
            this.textBox_UA_LN.Size = new System.Drawing.Size(370, 24);
            this.textBox_UA_LN.TabIndex = 164;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.ForeColor = System.Drawing.Color.Red;
            this.label115.Location = new System.Drawing.Point(822, 105);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(15, 18);
            this.label115.TabIndex = 163;
            this.label115.Text = "*";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(478, 105);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(74, 14);
            this.label116.TabIndex = 162;
            this.label116.Text = "Company ID:";
            // 
            // textBoxUA_CID
            // 
            this.textBoxUA_CID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxUA_CID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUA_CID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUA_CID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxUA_CID.Location = new System.Drawing.Point(483, 135);
            this.textBoxUA_CID.Name = "textBoxUA_CID";
            this.textBoxUA_CID.Size = new System.Drawing.Size(367, 24);
            this.textBoxUA_CID.TabIndex = 161;
            // 
            // metroComboBoxUA_MN
            // 
            this.metroComboBoxUA_MN.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxUA_MN.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxUA_MN.FormattingEnabled = true;
            this.metroComboBoxUA_MN.ItemHeight = 23;
            this.metroComboBoxUA_MN.Location = new System.Drawing.Point(27, 133);
            this.metroComboBoxUA_MN.Name = "metroComboBoxUA_MN";
            this.metroComboBoxUA_MN.Size = new System.Drawing.Size(450, 29);
            this.metroComboBoxUA_MN.Sorted = true;
            this.metroComboBoxUA_MN.TabIndex = 160;
            this.metroComboBoxUA_MN.UseSelectable = true;
            this.metroComboBoxUA_MN.UseStyleColors = true;
            this.metroComboBoxUA_MN.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxUA_MN_SelectedIndexChanged);
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.ForeColor = System.Drawing.Color.Red;
            this.label113.Location = new System.Drawing.Point(449, 107);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(15, 18);
            this.label113.TabIndex = 159;
            this.label113.Text = "*";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(22, 106);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(91, 14);
            this.label114.TabIndex = 158;
            this.label114.Text = "Merchant Name:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(194, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 18);
            this.label17.TabIndex = 84;
            this.label17.Text = "*";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(22, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(46, 14);
            this.label41.TabIndex = 83;
            this.label41.Text = "User ID:";
            // 
            // textBox_UA_UID
            // 
            this.textBox_UA_UID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_UA_UID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_UA_UID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_UA_UID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_UA_UID.Location = new System.Drawing.Point(27, 52);
            this.textBox_UA_UID.MaxLength = 10;
            this.textBox_UA_UID.Name = "textBox_UA_UID";
            this.textBox_UA_UID.Size = new System.Drawing.Size(188, 24);
            this.textBox_UA_UID.TabIndex = 82;
            this.textBox_UA_UID.TextChanged += new System.EventHandler(this.textBox_UA_UID_TextChanged);
            this.textBox_UA_UID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // tb16
            // 
            this.tb16.Controls.Add(this.panel16);
            this.tb16.Location = new System.Drawing.Point(4, 34);
            this.tb16.Name = "tb16";
            this.tb16.Size = new System.Drawing.Size(862, 565);
            this.tb16.TabIndex = 15;
            this.tb16.Text = "User Cards";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel16.Controls.Add(this.buttonexpuc);
            this.panel16.Controls.Add(this.panelUC);
            this.panel16.Controls.Add(this.buttonSaveUC);
            this.panel16.Controls.Add(this.labelPID);
            this.panel16.Controls.Add(this.metroComboBoxVID);
            this.panel16.Controls.Add(this.label133);
            this.panel16.Controls.Add(this.label134);
            this.panel16.Controls.Add(this.label131);
            this.panel16.Controls.Add(this.label132);
            this.panel16.Controls.Add(this.radioButtonDISPATCHER);
            this.panel16.Controls.Add(this.radioButtonDRIVER);
            this.panel16.Controls.Add(this.buttonUC_DEL);
            this.panel16.Controls.Add(this.buttonUCADD);
            this.panel16.Controls.Add(this.dgvUC);
            this.panel16.Controls.Add(this.label125);
            this.panel16.Controls.Add(this.metroComboBoxUC_UN);
            this.panel16.Controls.Add(this.label126);
            this.panel16.Controls.Add(this.metroDateTimeUCED2);
            this.panel16.Controls.Add(this.label127);
            this.panel16.Controls.Add(this.metroDateTimeUCED);
            this.panel16.Controls.Add(this.label128);
            this.panel16.Controls.Add(this.label129);
            this.panel16.Controls.Add(this.label130);
            this.panel16.Controls.Add(this.textBoxUC_UID);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(862, 565);
            this.panel16.TabIndex = 83;
            // 
            // buttonexpuc
            // 
            this.buttonexpuc.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpuc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpuc.Location = new System.Drawing.Point(709, 232);
            this.buttonexpuc.Name = "buttonexpuc";
            this.buttonexpuc.Size = new System.Drawing.Size(133, 45);
            this.buttonexpuc.TabIndex = 207;
            this.buttonexpuc.Text = "Export";
            this.buttonexpuc.UseVisualStyleBackColor = false;
            this.buttonexpuc.Click += new System.EventHandler(this.buttonexpuc_Click);
            // 
            // panelUC
            // 
            this.panelUC.Controls.Add(this.label228);
            this.panelUC.Controls.Add(this.label229);
            this.panelUC.Controls.Add(this.radioButtonDISPATCHER2);
            this.panelUC.Controls.Add(this.radioButtonDRIVER2);
            this.panelUC.Controls.Add(this.label230);
            this.panelUC.Controls.Add(this.metroComboBoxUC_UN2);
            this.panelUC.Controls.Add(this.label231);
            this.panelUC.Controls.Add(this.metroDateTimeUCED2second);
            this.panelUC.Controls.Add(this.label232);
            this.panelUC.Controls.Add(this.metroDateTimeUCEDsecond);
            this.panelUC.Controls.Add(this.label233);
            this.panelUC.Controls.Add(this.label234);
            this.panelUC.Controls.Add(this.label235);
            this.panelUC.Controls.Add(this.textBoxUC_UID2);
            this.panelUC.Location = new System.Drawing.Point(20, 23);
            this.panelUC.Name = "panelUC";
            this.panelUC.Size = new System.Drawing.Size(802, 150);
            this.panelUC.TabIndex = 83;
            this.panelUC.Visible = false;
            // 
            // label228
            // 
            this.label228.AutoSize = true;
            this.label228.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label228.ForeColor = System.Drawing.Color.Red;
            this.label228.Location = new System.Drawing.Point(686, -3);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(15, 18);
            this.label228.TabIndex = 212;
            this.label228.Text = "*";
            // 
            // label229
            // 
            this.label229.AutoSize = true;
            this.label229.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label229.Location = new System.Drawing.Point(656, -3);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(31, 14);
            this.label229.TabIndex = 211;
            this.label229.Text = "Role:";
            // 
            // radioButtonDISPATCHER2
            // 
            this.radioButtonDISPATCHER2.AutoSize = true;
            this.radioButtonDISPATCHER2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDISPATCHER2.Location = new System.Drawing.Point(661, 58);
            this.radioButtonDISPATCHER2.Name = "radioButtonDISPATCHER2";
            this.radioButtonDISPATCHER2.Size = new System.Drawing.Size(79, 18);
            this.radioButtonDISPATCHER2.TabIndex = 210;
            this.radioButtonDISPATCHER2.TabStop = true;
            this.radioButtonDISPATCHER2.Text = "Dispatcher";
            this.radioButtonDISPATCHER2.UseVisualStyleBackColor = true;
            // 
            // radioButtonDRIVER2
            // 
            this.radioButtonDRIVER2.AutoSize = true;
            this.radioButtonDRIVER2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDRIVER2.Location = new System.Drawing.Point(661, 26);
            this.radioButtonDRIVER2.Name = "radioButtonDRIVER2";
            this.radioButtonDRIVER2.Size = new System.Drawing.Size(55, 18);
            this.radioButtonDRIVER2.TabIndex = 209;
            this.radioButtonDRIVER2.TabStop = true;
            this.radioButtonDRIVER2.Text = "Driver";
            this.radioButtonDRIVER2.UseVisualStyleBackColor = true;
            // 
            // label230
            // 
            this.label230.AutoSize = true;
            this.label230.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label230.Location = new System.Drawing.Point(425, 35);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(18, 14);
            this.label230.TabIndex = 208;
            this.label230.Text = "to";
            // 
            // metroComboBoxUC_UN2
            // 
            this.metroComboBoxUC_UN2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxUC_UN2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxUC_UN2.FormattingEnabled = true;
            this.metroComboBoxUC_UN2.ItemHeight = 23;
            this.metroComboBoxUC_UN2.Location = new System.Drawing.Point(8, 112);
            this.metroComboBoxUC_UN2.Name = "metroComboBoxUC_UN2";
            this.metroComboBoxUC_UN2.Size = new System.Drawing.Size(332, 29);
            this.metroComboBoxUC_UN2.Sorted = true;
            this.metroComboBoxUC_UN2.TabIndex = 204;
            this.metroComboBoxUC_UN2.UseSelectable = true;
            this.metroComboBoxUC_UN2.UseStyleColors = true;
            this.metroComboBoxUC_UN2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxUC_UN2_SelectedIndexChanged);
            // 
            // label231
            // 
            this.label231.AutoSize = true;
            this.label231.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label231.Location = new System.Drawing.Point(218, -3);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(78, 14);
            this.label231.TabIndex = 206;
            this.label231.Text = "Effective Date";
            // 
            // metroDateTimeUCED2second
            // 
            this.metroDateTimeUCED2second.Location = new System.Drawing.Point(443, 26);
            this.metroDateTimeUCED2second.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeUCED2second.Name = "metroDateTimeUCED2second";
            this.metroDateTimeUCED2second.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeUCED2second.TabIndex = 207;
            // 
            // label232
            // 
            this.label232.AutoSize = true;
            this.label232.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label232.ForeColor = System.Drawing.Color.Red;
            this.label232.Location = new System.Drawing.Point(312, 83);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(15, 18);
            this.label232.TabIndex = 203;
            this.label232.Text = "*";
            // 
            // metroDateTimeUCEDsecond
            // 
            this.metroDateTimeUCEDsecond.Location = new System.Drawing.Point(222, 26);
            this.metroDateTimeUCEDsecond.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeUCEDsecond.Name = "metroDateTimeUCEDsecond";
            this.metroDateTimeUCEDsecond.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeUCEDsecond.TabIndex = 205;
            // 
            // label233
            // 
            this.label233.AutoSize = true;
            this.label233.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label233.Location = new System.Drawing.Point(2, 83);
            this.label233.Name = "label233";
            this.label233.Size = new System.Drawing.Size(43, 14);
            this.label233.TabIndex = 202;
            this.label233.Text = "UserID:";
            // 
            // label234
            // 
            this.label234.AutoSize = true;
            this.label234.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label234.ForeColor = System.Drawing.Color.Red;
            this.label234.Location = new System.Drawing.Point(184, 2);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(15, 18);
            this.label234.TabIndex = 201;
            this.label234.Text = "*";
            // 
            // label235
            // 
            this.label235.AutoSize = true;
            this.label235.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label235.Location = new System.Drawing.Point(3, 0);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(54, 14);
            this.label235.TabIndex = 200;
            this.label235.Text = "New UID:";
            // 
            // textBoxUC_UID2
            // 
            this.textBoxUC_UID2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxUC_UID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUC_UID2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUC_UID2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxUC_UID2.Location = new System.Drawing.Point(8, 29);
            this.textBoxUC_UID2.MaxLength = 10;
            this.textBoxUC_UID2.Name = "textBoxUC_UID2";
            this.textBoxUC_UID2.Size = new System.Drawing.Size(204, 24);
            this.textBoxUC_UID2.TabIndex = 199;
            this.textBoxUC_UID2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // buttonSaveUC
            // 
            this.buttonSaveUC.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveUC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveUC.Location = new System.Drawing.Point(570, 177);
            this.buttonSaveUC.Name = "buttonSaveUC";
            this.buttonSaveUC.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveUC.TabIndex = 206;
            this.buttonSaveUC.Text = "Save";
            this.buttonSaveUC.UseVisualStyleBackColor = true;
            this.buttonSaveUC.Visible = false;
            this.buttonSaveUC.Click += new System.EventHandler(this.buttonSaveUC_Click);
            // 
            // labelPID
            // 
            this.labelPID.AutoSize = true;
            this.labelPID.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPID.Location = new System.Drawing.Point(23, 165);
            this.labelPID.Name = "labelPID";
            this.labelPID.Size = new System.Drawing.Size(0, 14);
            this.labelPID.TabIndex = 201;
            // 
            // metroComboBoxVID
            // 
            this.metroComboBoxVID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxVID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxVID.FormattingEnabled = true;
            this.metroComboBoxVID.ItemHeight = 23;
            this.metroComboBoxVID.Location = new System.Drawing.Point(371, 134);
            this.metroComboBoxVID.Name = "metroComboBoxVID";
            this.metroComboBoxVID.Size = new System.Drawing.Size(332, 29);
            this.metroComboBoxVID.Sorted = true;
            this.metroComboBoxVID.TabIndex = 198;
            this.metroComboBoxVID.UseSelectable = true;
            this.metroComboBoxVID.UseStyleColors = true;
            this.metroComboBoxVID.Visible = false;
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.ForeColor = System.Drawing.Color.Red;
            this.label133.Location = new System.Drawing.Point(675, 107);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(15, 18);
            this.label133.TabIndex = 197;
            this.label133.Text = "*";
            this.label133.Visible = false;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(366, 107);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(86, 14);
            this.label134.TabIndex = 196;
            this.label134.Text = "Vehicle Card ID:";
            this.label134.Visible = false;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.ForeColor = System.Drawing.Color.Red;
            this.label131.Location = new System.Drawing.Point(706, 20);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(15, 18);
            this.label131.TabIndex = 195;
            this.label131.Text = "*";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(676, 20);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(31, 14);
            this.label132.TabIndex = 194;
            this.label132.Text = "Role:";
            // 
            // radioButtonDISPATCHER
            // 
            this.radioButtonDISPATCHER.AutoSize = true;
            this.radioButtonDISPATCHER.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDISPATCHER.Location = new System.Drawing.Point(681, 81);
            this.radioButtonDISPATCHER.Name = "radioButtonDISPATCHER";
            this.radioButtonDISPATCHER.Size = new System.Drawing.Size(79, 18);
            this.radioButtonDISPATCHER.TabIndex = 193;
            this.radioButtonDISPATCHER.TabStop = true;
            this.radioButtonDISPATCHER.Text = "Dispatcher";
            this.radioButtonDISPATCHER.UseVisualStyleBackColor = true;
            // 
            // radioButtonDRIVER
            // 
            this.radioButtonDRIVER.AutoSize = true;
            this.radioButtonDRIVER.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDRIVER.Location = new System.Drawing.Point(681, 49);
            this.radioButtonDRIVER.Name = "radioButtonDRIVER";
            this.radioButtonDRIVER.Size = new System.Drawing.Size(55, 18);
            this.radioButtonDRIVER.TabIndex = 192;
            this.radioButtonDRIVER.TabStop = true;
            this.radioButtonDRIVER.Text = "Driver";
            this.radioButtonDRIVER.UseVisualStyleBackColor = true;
            // 
            // buttonUC_DEL
            // 
            this.buttonUC_DEL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonUC_DEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUC_DEL.Location = new System.Drawing.Point(1, 234);
            this.buttonUC_DEL.Name = "buttonUC_DEL";
            this.buttonUC_DEL.Size = new System.Drawing.Size(111, 41);
            this.buttonUC_DEL.TabIndex = 191;
            this.buttonUC_DEL.Text = "Delete";
            this.buttonUC_DEL.UseVisualStyleBackColor = true;
            this.buttonUC_DEL.Visible = false;
            this.buttonUC_DEL.Click += new System.EventHandler(this.buttonUC_DEL_Click);
            // 
            // buttonUCADD
            // 
            this.buttonUCADD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUCADD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUCADD.Location = new System.Drawing.Point(709, 177);
            this.buttonUCADD.Name = "buttonUCADD";
            this.buttonUCADD.Size = new System.Drawing.Size(133, 45);
            this.buttonUCADD.TabIndex = 190;
            this.buttonUCADD.Text = "Add";
            this.buttonUCADD.UseVisualStyleBackColor = true;
            this.buttonUCADD.Click += new System.EventHandler(this.buttonUCADD_Click);
            // 
            // dgvUC
            // 
            this.dgvUC.AllowUserToAddRows = false;
            this.dgvUC.AllowUserToResizeRows = false;
            this.dgvUC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvUC.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvUC.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle883.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle883.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle883.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle883.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle883.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle883.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle883.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle883;
            this.dgvUC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle884.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle884.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle884.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle884.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle884.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle884.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle884.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUC.DefaultCellStyle = dataGridViewCellStyle884;
            this.dgvUC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvUC.EnableHeadersVisualStyles = false;
            this.dgvUC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvUC.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUC.Location = new System.Drawing.Point(0, 252);
            this.dgvUC.MultiSelect = false;
            this.dgvUC.Name = "dgvUC";
            this.dgvUC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle885.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle885.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle885.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle885.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle885.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle885.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle885.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUC.RowHeadersDefaultCellStyle = dataGridViewCellStyle885;
            this.dgvUC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUC.RowTemplate.Height = 33;
            this.dgvUC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUC.Size = new System.Drawing.Size(862, 313);
            this.dgvUC.TabIndex = 188;
            this.dgvUC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUC_CellDoubleClick);
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(445, 58);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(18, 14);
            this.label125.TabIndex = 187;
            this.label125.Text = "to";
            // 
            // metroComboBoxUC_UN
            // 
            this.metroComboBoxUC_UN.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxUC_UN.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxUC_UN.FormattingEnabled = true;
            this.metroComboBoxUC_UN.ItemHeight = 23;
            this.metroComboBoxUC_UN.Location = new System.Drawing.Point(28, 135);
            this.metroComboBoxUC_UN.Name = "metroComboBoxUC_UN";
            this.metroComboBoxUC_UN.Size = new System.Drawing.Size(332, 29);
            this.metroComboBoxUC_UN.Sorted = true;
            this.metroComboBoxUC_UN.TabIndex = 183;
            this.metroComboBoxUC_UN.UseSelectable = true;
            this.metroComboBoxUC_UN.UseStyleColors = true;
            this.metroComboBoxUC_UN.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxUC_UN_SelectedIndexChanged);
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(238, 20);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(78, 14);
            this.label126.TabIndex = 185;
            this.label126.Text = "Effective Date";
            // 
            // metroDateTimeUCED2
            // 
            this.metroDateTimeUCED2.Location = new System.Drawing.Point(463, 49);
            this.metroDateTimeUCED2.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTimeUCED2.Name = "metroDateTimeUCED2";
            this.metroDateTimeUCED2.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeUCED2.TabIndex = 186;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.ForeColor = System.Drawing.Color.Red;
            this.label127.Location = new System.Drawing.Point(332, 106);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(15, 18);
            this.label127.TabIndex = 182;
            this.label127.Text = "*";
            // 
            // metroDateTimeUCED
            // 
            this.metroDateTimeUCED.Location = new System.Drawing.Point(242, 49);
            this.metroDateTimeUCED.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTimeUCED.Name = "metroDateTimeUCED";
            this.metroDateTimeUCED.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeUCED.TabIndex = 184;
            this.metroDateTimeUCED.ValueChanged += new System.EventHandler(this.metroDateTimeUCED_ValueChanged);
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(22, 106);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(43, 14);
            this.label128.TabIndex = 181;
            this.label128.Text = "UserID:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.ForeColor = System.Drawing.Color.Red;
            this.label129.Location = new System.Drawing.Point(204, 25);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(15, 18);
            this.label129.TabIndex = 180;
            this.label129.Text = "*";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(23, 23);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(28, 14);
            this.label130.TabIndex = 179;
            this.label130.Text = "UID:";
            // 
            // textBoxUC_UID
            // 
            this.textBoxUC_UID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxUC_UID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUC_UID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUC_UID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxUC_UID.Location = new System.Drawing.Point(28, 52);
            this.textBoxUC_UID.MaxLength = 10;
            this.textBoxUC_UID.Name = "textBoxUC_UID";
            this.textBoxUC_UID.Size = new System.Drawing.Size(204, 24);
            this.textBoxUC_UID.TabIndex = 178;
            this.textBoxUC_UID.TextChanged += new System.EventHandler(this.textBoxUC_UID_TextChanged);
            // 
            // tb17
            // 
            this.tb17.Controls.Add(this.panel17);
            this.tb17.Location = new System.Drawing.Point(4, 34);
            this.tb17.Name = "tb17";
            this.tb17.Size = new System.Drawing.Size(862, 565);
            this.tb17.TabIndex = 16;
            this.tb17.Text = "InsertSQL";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel17.Controls.Add(this.textBoxINS);
            this.panel17.Controls.Add(this.buttonOpenINS);
            this.panel17.Controls.Add(this.labelINSfile);
            this.panel17.Controls.Add(this.buttonPlayIns);
            this.panel17.Controls.Add(this.label155);
            this.panel17.Controls.Add(this.label154);
            this.panel17.Controls.Add(this.dgvINSERT);
            this.panel17.Controls.Add(this.label153);
            this.panel17.Controls.Add(this.label152);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(862, 565);
            this.panel17.TabIndex = 84;
            // 
            // textBoxINS
            // 
            this.textBoxINS.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.textBoxINS.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxINS.FormattingEnabled = true;
            this.textBoxINS.ItemHeight = 23;
            this.textBoxINS.Location = new System.Drawing.Point(25, 146);
            this.textBoxINS.Name = "textBoxINS";
            this.textBoxINS.Size = new System.Drawing.Size(276, 29);
            this.textBoxINS.Sorted = true;
            this.textBoxINS.TabIndex = 196;
            this.textBoxINS.UseSelectable = true;
            this.textBoxINS.UseStyleColors = true;
            this.textBoxINS.SelectedIndexChanged += new System.EventHandler(this.textBoxINS_SelectedIndexChanged);
            // 
            // buttonOpenINS
            // 
            this.buttonOpenINS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonOpenINS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenINS.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOpenINS.Location = new System.Drawing.Point(26, 58);
            this.buttonOpenINS.Name = "buttonOpenINS";
            this.buttonOpenINS.Size = new System.Drawing.Size(109, 33);
            this.buttonOpenINS.TabIndex = 195;
            this.buttonOpenINS.Text = "Open File";
            this.buttonOpenINS.UseVisualStyleBackColor = true;
            this.buttonOpenINS.Click += new System.EventHandler(this.buttonOpenINS_Click);
            // 
            // labelINSfile
            // 
            this.labelINSfile.AutoSize = true;
            this.labelINSfile.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelINSfile.Location = new System.Drawing.Point(136, 67);
            this.labelINSfile.Name = "labelINSfile";
            this.labelINSfile.Size = new System.Drawing.Size(88, 14);
            this.labelINSfile.TabIndex = 194;
            this.labelINSfile.Text = "No file selected.";
            // 
            // buttonPlayIns
            // 
            this.buttonPlayIns.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPlayIns.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonPlayIns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayIns.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPlayIns.FlatAppearance.BorderSize = 0;
            this.buttonPlayIns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonPlayIns.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlayIns.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPlayIns.Location = new System.Drawing.Point(311, 135);
            this.buttonPlayIns.Name = "buttonPlayIns";
            this.buttonPlayIns.Size = new System.Drawing.Size(24, 25);
            this.buttonPlayIns.TabIndex = 193;
            this.buttonPlayIns.UseVisualStyleBackColor = true;
            this.buttonPlayIns.Click += new System.EventHandler(this.buttonRUNins_Click);
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label155.Location = new System.Drawing.Point(21, 26);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(59, 14);
            this.label155.TabIndex = 192;
            this.label155.Text = "Select File:";
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label154.Location = new System.Drawing.Point(21, 218);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(39, 14);
            this.label154.TabIndex = 190;
            this.label154.Text = "Result:";
            // 
            // dgvINSERT
            // 
            this.dgvINSERT.AllowUserToAddRows = false;
            this.dgvINSERT.AllowUserToResizeRows = false;
            this.dgvINSERT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvINSERT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvINSERT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvINSERT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvINSERT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle886.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle886.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle886.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle886.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle886.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle886.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle886.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvINSERT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle886;
            this.dgvINSERT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle887.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle887.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle887.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle887.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle887.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle887.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle887.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvINSERT.DefaultCellStyle = dataGridViewCellStyle887;
            this.dgvINSERT.EnableHeadersVisualStyles = false;
            this.dgvINSERT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvINSERT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvINSERT.Location = new System.Drawing.Point(26, 242);
            this.dgvINSERT.MultiSelect = false;
            this.dgvINSERT.Name = "dgvINSERT";
            this.dgvINSERT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle888.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle888.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle888.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle888.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle888.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle888.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle888.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvINSERT.RowHeadersDefaultCellStyle = dataGridViewCellStyle888;
            this.dgvINSERT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvINSERT.RowTemplate.Height = 33;
            this.dgvINSERT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvINSERT.Size = new System.Drawing.Size(756, 292);
            this.dgvINSERT.TabIndex = 189;
            this.dgvINSERT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvINSERT_CellClick);
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Font = new System.Drawing.Font("Google Sans", 7.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label153.Location = new System.Drawing.Point(21, 181);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(0, 13);
            this.label153.TabIndex = 181;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label152.Location = new System.Drawing.Point(21, 105);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(69, 14);
            this.label152.TabIndex = 180;
            this.label152.Text = "Table Name:";
            // 
            // tb18
            // 
            this.tb18.Controls.Add(this.panel18);
            this.tb18.Location = new System.Drawing.Point(4, 34);
            this.tb18.Name = "tb18";
            this.tb18.Size = new System.Drawing.Size(862, 565);
            this.tb18.TabIndex = 17;
            this.tb18.Text = "updateSQL";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel18.Controls.Add(this.label162);
            this.panel18.Controls.Add(this.textBoxSETUP);
            this.panel18.Controls.Add(this.textBoxVALUP);
            this.panel18.Controls.Add(this.label157);
            this.panel18.Controls.Add(this.buttonUp);
            this.panel18.Controls.Add(this.label159);
            this.panel18.Controls.Add(this.label156);
            this.panel18.Controls.Add(this.mcbxColUP);
            this.panel18.Controls.Add(this.mcbxTB);
            this.panel18.Controls.Add(this.label158);
            this.panel18.Controls.Add(this.dgvUPDATE);
            this.panel18.Controls.Add(this.label160);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(862, 565);
            this.panel18.TabIndex = 85;
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Font = new System.Drawing.Font("Google Sans", 7.125F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label162.Location = new System.Drawing.Point(26, 183);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(210, 13);
            this.label162.TabIndex = 219;
            this.label162.Text = "Example: Column1 = \'VAR1\',  Column2 = \'VAR2\'";
            // 
            // textBoxSETUP
            // 
            this.textBoxSETUP.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSETUP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSETUP.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSETUP.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSETUP.Location = new System.Drawing.Point(31, 135);
            this.textBoxSETUP.MaxLength = 80;
            this.textBoxSETUP.Name = "textBoxSETUP";
            this.textBoxSETUP.Size = new System.Drawing.Size(726, 24);
            this.textBoxSETUP.TabIndex = 218;
            // 
            // textBoxVALUP
            // 
            this.textBoxVALUP.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxVALUP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxVALUP.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxVALUP.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxVALUP.Location = new System.Drawing.Point(553, 61);
            this.textBoxVALUP.MaxLength = 80;
            this.textBoxVALUP.Name = "textBoxVALUP";
            this.textBoxVALUP.Size = new System.Drawing.Size(249, 24);
            this.textBoxVALUP.TabIndex = 218;
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label157.Location = new System.Drawing.Point(26, 106);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(88, 14);
            this.label157.TabIndex = 210;
            this.label157.Text = "SET Parameters:";
            // 
            // buttonUp
            // 
            this.buttonUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUp.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonUp.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUp.FlatAppearance.BorderSize = 0;
            this.buttonUp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUp.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUp.Location = new System.Drawing.Point(766, 122);
            this.buttonUp.Name = "buttonUp";
            this.buttonUp.Size = new System.Drawing.Size(24, 25);
            this.buttonUp.TabIndex = 217;
            this.buttonUp.Text = ".";
            this.buttonUp.UseVisualStyleBackColor = true;
            this.buttonUp.Click += new System.EventHandler(this.buttonUp_Click_1);
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label159.Location = new System.Drawing.Point(550, 17);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(113, 14);
            this.label159.TabIndex = 210;
            this.label159.Text = "Value (Where clause):";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label156.Location = new System.Drawing.Point(308, 17);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(126, 14);
            this.label156.TabIndex = 208;
            this.label156.Text = "Column (Where clause):";
            // 
            // mcbxColUP
            // 
            this.mcbxColUP.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxColUP.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxColUP.FormattingEnabled = true;
            this.mcbxColUP.ItemHeight = 23;
            this.mcbxColUP.Location = new System.Drawing.Point(313, 58);
            this.mcbxColUP.Name = "mcbxColUP";
            this.mcbxColUP.Size = new System.Drawing.Size(234, 29);
            this.mcbxColUP.Sorted = true;
            this.mcbxColUP.TabIndex = 207;
            this.mcbxColUP.UseSelectable = true;
            this.mcbxColUP.UseStyleColors = true;
            // 
            // mcbxTB
            // 
            this.mcbxTB.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxTB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxTB.FormattingEnabled = true;
            this.mcbxTB.ItemHeight = 23;
            this.mcbxTB.Location = new System.Drawing.Point(31, 58);
            this.mcbxTB.Name = "mcbxTB";
            this.mcbxTB.Size = new System.Drawing.Size(276, 29);
            this.mcbxTB.Sorted = true;
            this.mcbxTB.TabIndex = 206;
            this.mcbxTB.UseSelectable = true;
            this.mcbxTB.UseStyleColors = true;
            this.mcbxTB.SelectedIndexChanged += new System.EventHandler(this.mcbxTB_SelectedIndexChanged);
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label158.Location = new System.Drawing.Point(26, 276);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(39, 14);
            this.label158.TabIndex = 200;
            this.label158.Text = "Result:";
            // 
            // dgvUPDATE
            // 
            this.dgvUPDATE.AllowUserToAddRows = false;
            this.dgvUPDATE.AllowUserToResizeRows = false;
            this.dgvUPDATE.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUPDATE.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUPDATE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvUPDATE.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvUPDATE.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle889.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle889.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle889.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle889.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle889.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle889.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle889.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUPDATE.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle889;
            this.dgvUPDATE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle890.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle890.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle890.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle890.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle890.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle890.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle890.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUPDATE.DefaultCellStyle = dataGridViewCellStyle890;
            this.dgvUPDATE.EnableHeadersVisualStyles = false;
            this.dgvUPDATE.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvUPDATE.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvUPDATE.Location = new System.Drawing.Point(31, 313);
            this.dgvUPDATE.MultiSelect = false;
            this.dgvUPDATE.Name = "dgvUPDATE";
            this.dgvUPDATE.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle891.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle891.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle891.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle891.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle891.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle891.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle891.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUPDATE.RowHeadersDefaultCellStyle = dataGridViewCellStyle891;
            this.dgvUPDATE.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUPDATE.RowTemplate.Height = 33;
            this.dgvUPDATE.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUPDATE.Size = new System.Drawing.Size(756, 216);
            this.dgvUPDATE.TabIndex = 199;
            this.dgvUPDATE.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUPDATE_CellClick);
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label160.Location = new System.Drawing.Point(26, 17);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(69, 14);
            this.label160.TabIndex = 197;
            this.label160.Text = "Table Name:";
            // 
            // tb19
            // 
            this.tb19.Controls.Add(this.panel19);
            this.tb19.Location = new System.Drawing.Point(4, 34);
            this.tb19.Name = "tb19";
            this.tb19.Size = new System.Drawing.Size(862, 565);
            this.tb19.TabIndex = 18;
            this.tb19.Text = "DELETE SQL";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel19.Controls.Add(this.label161);
            this.panel19.Controls.Add(this.mcbxVALDEL);
            this.panel19.Controls.Add(this.label164);
            this.panel19.Controls.Add(this.mcbxCOLDEL);
            this.panel19.Controls.Add(this.mcbxTBDEL);
            this.panel19.Controls.Add(this.buttonDEL);
            this.panel19.Controls.Add(this.label165);
            this.panel19.Controls.Add(this.label163);
            this.panel19.Controls.Add(this.dgvDEL);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(862, 565);
            this.panel19.TabIndex = 85;
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label161.Location = new System.Drawing.Point(27, 108);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(113, 14);
            this.label161.TabIndex = 217;
            this.label161.Text = "Value (Where clause):";
            // 
            // mcbxVALDEL
            // 
            this.mcbxVALDEL.BackColor = System.Drawing.SystemColors.HighlightText;
            this.mcbxVALDEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mcbxVALDEL.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcbxVALDEL.ForeColor = System.Drawing.SystemColors.InfoText;
            this.mcbxVALDEL.Location = new System.Drawing.Point(32, 137);
            this.mcbxVALDEL.MaxLength = 80;
            this.mcbxVALDEL.Name = "mcbxVALDEL";
            this.mcbxVALDEL.Size = new System.Drawing.Size(275, 24);
            this.mcbxVALDEL.TabIndex = 216;
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label164.Location = new System.Drawing.Point(308, 17);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(126, 14);
            this.label164.TabIndex = 215;
            this.label164.Text = "Column (Where clause):";
            // 
            // mcbxCOLDEL
            // 
            this.mcbxCOLDEL.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxCOLDEL.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxCOLDEL.FormattingEnabled = true;
            this.mcbxCOLDEL.ItemHeight = 23;
            this.mcbxCOLDEL.Location = new System.Drawing.Point(313, 58);
            this.mcbxCOLDEL.Name = "mcbxCOLDEL";
            this.mcbxCOLDEL.Size = new System.Drawing.Size(216, 29);
            this.mcbxCOLDEL.Sorted = true;
            this.mcbxCOLDEL.TabIndex = 214;
            this.mcbxCOLDEL.UseSelectable = true;
            this.mcbxCOLDEL.UseStyleColors = true;
            // 
            // mcbxTBDEL
            // 
            this.mcbxTBDEL.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxTBDEL.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxTBDEL.FormattingEnabled = true;
            this.mcbxTBDEL.ItemHeight = 23;
            this.mcbxTBDEL.Location = new System.Drawing.Point(31, 58);
            this.mcbxTBDEL.Name = "mcbxTBDEL";
            this.mcbxTBDEL.Size = new System.Drawing.Size(276, 29);
            this.mcbxTBDEL.Sorted = true;
            this.mcbxTBDEL.TabIndex = 213;
            this.mcbxTBDEL.UseSelectable = true;
            this.mcbxTBDEL.UseStyleColors = true;
            this.mcbxTBDEL.SelectedIndexChanged += new System.EventHandler(this.mcbxTBDEL_SelectedIndexChanged);
            // 
            // buttonDEL
            // 
            this.buttonDEL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDEL.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonDEL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDEL.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonDEL.FlatAppearance.BorderSize = 0;
            this.buttonDEL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonDEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDEL.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDEL.Location = new System.Drawing.Point(317, 122);
            this.buttonDEL.Name = "buttonDEL";
            this.buttonDEL.Size = new System.Drawing.Size(24, 25);
            this.buttonDEL.TabIndex = 212;
            this.buttonDEL.UseVisualStyleBackColor = true;
            this.buttonDEL.Click += new System.EventHandler(this.buttonUp_Click);
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label165.Location = new System.Drawing.Point(26, 17);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(69, 14);
            this.label165.TabIndex = 211;
            this.label165.Text = "Table Name:";
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label163.Location = new System.Drawing.Point(27, 198);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(39, 14);
            this.label163.TabIndex = 200;
            this.label163.Text = "Result:";
            // 
            // dgvDEL
            // 
            this.dgvDEL.AllowUserToAddRows = false;
            this.dgvDEL.AllowUserToResizeRows = false;
            this.dgvDEL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDEL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDEL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDEL.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDEL.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle892.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle892.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle892.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle892.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle892.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle892.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle892.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDEL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle892;
            this.dgvDEL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle893.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle893.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle893.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle893.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle893.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle893.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle893.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDEL.DefaultCellStyle = dataGridViewCellStyle893;
            this.dgvDEL.EnableHeadersVisualStyles = false;
            this.dgvDEL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDEL.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDEL.Location = new System.Drawing.Point(31, 227);
            this.dgvDEL.MultiSelect = false;
            this.dgvDEL.Name = "dgvDEL";
            this.dgvDEL.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle894.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle894.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle894.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle894.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle894.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle894.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle894.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDEL.RowHeadersDefaultCellStyle = dataGridViewCellStyle894;
            this.dgvDEL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDEL.RowTemplate.Height = 33;
            this.dgvDEL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDEL.Size = new System.Drawing.Size(756, 302);
            this.dgvDEL.TabIndex = 199;
            this.dgvDEL.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDEL_CellClick);
            // 
            // tb20
            // 
            this.tb20.Controls.Add(this.panel20);
            this.tb20.Location = new System.Drawing.Point(4, 34);
            this.tb20.Name = "tb20";
            this.tb20.Size = new System.Drawing.Size(862, 565);
            this.tb20.TabIndex = 19;
            this.tb20.Text = "BusJeepneySettings";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel20.Controls.Add(this.buttonexpbjs);
            this.panel20.Controls.Add(this.panelBJS);
            this.panel20.Controls.Add(this.buttonSaveBJS);
            this.panel20.Controls.Add(this.buttonDELBS);
            this.panel20.Controls.Add(this.buttonUPBS);
            this.panel20.Controls.Add(this.dgvBS);
            this.panel20.Controls.Add(this.label175);
            this.panel20.Controls.Add(this.label176);
            this.panel20.Controls.Add(this.DTBSTO);
            this.panel20.Controls.Add(this.DTBSFROM);
            this.panel20.Controls.Add(this.label173);
            this.panel20.Controls.Add(this.label174);
            this.panel20.Controls.Add(this.SIBS);
            this.panel20.Controls.Add(this.label171);
            this.panel20.Controls.Add(this.label172);
            this.panel20.Controls.Add(this.LNBS);
            this.panel20.Controls.Add(this.label169);
            this.panel20.Controls.Add(this.label170);
            this.panel20.Controls.Add(this.VIDBS);
            this.panel20.Controls.Add(this.TIDBS);
            this.panel20.Controls.Add(this.label167);
            this.panel20.Controls.Add(this.label168);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(862, 565);
            this.panel20.TabIndex = 84;
            // 
            // buttonexpbjs
            // 
            this.buttonexpbjs.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpbjs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpbjs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpbjs.Location = new System.Drawing.Point(717, 271);
            this.buttonexpbjs.Name = "buttonexpbjs";
            this.buttonexpbjs.Size = new System.Drawing.Size(133, 45);
            this.buttonexpbjs.TabIndex = 199;
            this.buttonexpbjs.Text = "Export";
            this.buttonexpbjs.UseVisualStyleBackColor = false;
            this.buttonexpbjs.Click += new System.EventHandler(this.buttonexpbjs_Click);
            // 
            // panelBJS
            // 
            this.panelBJS.Controls.Add(this.label200);
            this.panelBJS.Controls.Add(this.label203);
            this.panelBJS.Controls.Add(this.DTBSTO2);
            this.panelBJS.Controls.Add(this.DTBSFROM2);
            this.panelBJS.Controls.Add(this.label204);
            this.panelBJS.Controls.Add(this.label208);
            this.panelBJS.Controls.Add(this.SIBS2);
            this.panelBJS.Controls.Add(this.label209);
            this.panelBJS.Controls.Add(this.label210);
            this.panelBJS.Controls.Add(this.LNBS2);
            this.panelBJS.Controls.Add(this.label211);
            this.panelBJS.Controls.Add(this.VIDBS2);
            this.panelBJS.Controls.Add(this.TIDBS2);
            this.panelBJS.Controls.Add(this.label212);
            this.panelBJS.Controls.Add(this.label213);
            this.panelBJS.Location = new System.Drawing.Point(19, 25);
            this.panelBJS.Name = "panelBJS";
            this.panelBJS.Size = new System.Drawing.Size(832, 144);
            this.panelBJS.TabIndex = 83;
            this.panelBJS.Visible = false;
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label200.Location = new System.Drawing.Point(530, 40);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(18, 14);
            this.label200.TabIndex = 208;
            this.label200.Text = "to";
            // 
            // label203
            // 
            this.label203.AutoSize = true;
            this.label203.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label203.Location = new System.Drawing.Point(323, 2);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(78, 14);
            this.label203.TabIndex = 206;
            this.label203.Text = "Effective Date";
            // 
            // DTBSTO2
            // 
            this.DTBSTO2.Location = new System.Drawing.Point(548, 31);
            this.DTBSTO2.MinimumSize = new System.Drawing.Size(0, 29);
            this.DTBSTO2.Name = "DTBSTO2";
            this.DTBSTO2.Size = new System.Drawing.Size(200, 29);
            this.DTBSTO2.TabIndex = 207;
            // 
            // DTBSFROM2
            // 
            this.DTBSFROM2.Location = new System.Drawing.Point(327, 31);
            this.DTBSFROM2.MinimumSize = new System.Drawing.Size(0, 29);
            this.DTBSFROM2.Name = "DTBSFROM2";
            this.DTBSFROM2.Size = new System.Drawing.Size(200, 29);
            this.DTBSFROM2.TabIndex = 205;
            this.DTBSFROM2.ValueChanged += new System.EventHandler(this.DTBSFROM2_ValueChanged);
            // 
            // label204
            // 
            this.label204.AutoSize = true;
            this.label204.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label204.ForeColor = System.Drawing.Color.Red;
            this.label204.Location = new System.Drawing.Point(643, 77);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(15, 18);
            this.label204.TabIndex = 204;
            this.label204.Text = "*";
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label208.Location = new System.Drawing.Point(342, 74);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(82, 14);
            this.label208.TabIndex = 203;
            this.label208.Text = "ShortIdentifier:";
            // 
            // SIBS2
            // 
            this.SIBS2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.SIBS2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SIBS2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SIBS2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.SIBS2.Location = new System.Drawing.Point(347, 103);
            this.SIBS2.Name = "SIBS2";
            this.SIBS2.Size = new System.Drawing.Size(324, 24);
            this.SIBS2.TabIndex = 202;
            this.SIBS2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // label209
            // 
            this.label209.AutoSize = true;
            this.label209.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label209.ForeColor = System.Drawing.Color.Red;
            this.label209.Location = new System.Drawing.Point(300, 77);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(15, 18);
            this.label209.TabIndex = 201;
            this.label209.Text = "*";
            // 
            // label210
            // 
            this.label210.AutoSize = true;
            this.label210.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label210.Location = new System.Drawing.Point(-1, 74);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(66, 14);
            this.label210.TabIndex = 200;
            this.label210.Text = "LongName:";
            // 
            // LNBS2
            // 
            this.LNBS2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.LNBS2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LNBS2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNBS2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.LNBS2.Location = new System.Drawing.Point(4, 103);
            this.LNBS2.Name = "LNBS2";
            this.LNBS2.Size = new System.Drawing.Size(324, 24);
            this.LNBS2.TabIndex = 199;
            this.LNBS2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // label211
            // 
            this.label211.AutoSize = true;
            this.label211.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label211.Location = new System.Drawing.Point(677, 74);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(58, 14);
            this.label211.TabIndex = 198;
            this.label211.Text = "Vehicle ID:";
            // 
            // VIDBS2
            // 
            this.VIDBS2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.VIDBS2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.VIDBS2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VIDBS2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.VIDBS2.Location = new System.Drawing.Point(682, 103);
            this.VIDBS2.Name = "VIDBS2";
            this.VIDBS2.Size = new System.Drawing.Size(149, 24);
            this.VIDBS2.TabIndex = 197;
            this.VIDBS2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // TIDBS2
            // 
            this.TIDBS2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.TIDBS2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TIDBS2.FormattingEnabled = true;
            this.TIDBS2.ItemHeight = 23;
            this.TIDBS2.Location = new System.Drawing.Point(4, 29);
            this.TIDBS2.Name = "TIDBS2";
            this.TIDBS2.Size = new System.Drawing.Size(295, 29);
            this.TIDBS2.Sorted = true;
            this.TIDBS2.TabIndex = 196;
            this.TIDBS2.UseSelectable = true;
            this.TIDBS2.UseStyleColors = true;
            this.TIDBS2.SelectedIndexChanged += new System.EventHandler(this.TIDBS2_SelectedIndexChanged);
            // 
            // label212
            // 
            this.label212.AutoSize = true;
            this.label212.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label212.ForeColor = System.Drawing.Color.Red;
            this.label212.Location = new System.Drawing.Point(271, 2);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(15, 18);
            this.label212.TabIndex = 195;
            this.label212.Text = "*";
            // 
            // label213
            // 
            this.label213.AutoSize = true;
            this.label213.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label213.Location = new System.Drawing.Point(-1, 2);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(91, 14);
            this.label213.TabIndex = 194;
            this.label213.Text = "New Terminal ID:";
            // 
            // buttonSaveBJS
            // 
            this.buttonSaveBJS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveBJS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveBJS.Location = new System.Drawing.Point(578, 175);
            this.buttonSaveBJS.Name = "buttonSaveBJS";
            this.buttonSaveBJS.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveBJS.TabIndex = 198;
            this.buttonSaveBJS.Text = "Save";
            this.buttonSaveBJS.UseVisualStyleBackColor = true;
            this.buttonSaveBJS.Visible = false;
            this.buttonSaveBJS.Click += new System.EventHandler(this.buttonSaveBJS_Click);
            // 
            // buttonDELBS
            // 
            this.buttonDELBS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELBS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELBS.Location = new System.Drawing.Point(0, 272);
            this.buttonDELBS.Name = "buttonDELBS";
            this.buttonDELBS.Size = new System.Drawing.Size(111, 41);
            this.buttonDELBS.TabIndex = 197;
            this.buttonDELBS.Text = "Delete";
            this.buttonDELBS.UseVisualStyleBackColor = true;
            this.buttonDELBS.Visible = false;
            this.buttonDELBS.Click += new System.EventHandler(this.buttonDELBS_Click);
            // 
            // buttonUPBS
            // 
            this.buttonUPBS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUPBS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUPBS.Location = new System.Drawing.Point(717, 175);
            this.buttonUPBS.Name = "buttonUPBS";
            this.buttonUPBS.Size = new System.Drawing.Size(133, 45);
            this.buttonUPBS.TabIndex = 196;
            this.buttonUPBS.Text = "Create";
            this.buttonUPBS.UseVisualStyleBackColor = true;
            this.buttonUPBS.Click += new System.EventHandler(this.buttonUPBS_Click);
            // 
            // dgvBS
            // 
            this.dgvBS.AllowUserToAddRows = false;
            this.dgvBS.AllowUserToResizeRows = false;
            this.dgvBS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBS.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvBS.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBS.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvBS.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle895.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle895.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle895.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle895.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle895.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle895.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle895.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle895;
            this.dgvBS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle896.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle896.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle896.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle896.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle896.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle896.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle896.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBS.DefaultCellStyle = dataGridViewCellStyle896;
            this.dgvBS.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvBS.EnableHeadersVisualStyles = false;
            this.dgvBS.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvBS.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBS.Location = new System.Drawing.Point(0, 292);
            this.dgvBS.MultiSelect = false;
            this.dgvBS.Name = "dgvBS";
            this.dgvBS.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle897.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle897.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle897.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle897.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle897.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle897.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle897.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBS.RowHeadersDefaultCellStyle = dataGridViewCellStyle897;
            this.dgvBS.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBS.RowTemplate.Height = 33;
            this.dgvBS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBS.Size = new System.Drawing.Size(862, 273);
            this.dgvBS.TabIndex = 195;
            this.dgvBS.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBS_CellDoubleClick);
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label175.Location = new System.Drawing.Point(549, 65);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(18, 14);
            this.label175.TabIndex = 193;
            this.label175.Text = "to";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label176.Location = new System.Drawing.Point(342, 27);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(78, 14);
            this.label176.TabIndex = 191;
            this.label176.Text = "Effective Date";
            // 
            // DTBSTO
            // 
            this.DTBSTO.Location = new System.Drawing.Point(567, 56);
            this.DTBSTO.MinimumSize = new System.Drawing.Size(4, 29);
            this.DTBSTO.Name = "DTBSTO";
            this.DTBSTO.Size = new System.Drawing.Size(200, 29);
            this.DTBSTO.TabIndex = 192;
            // 
            // DTBSFROM
            // 
            this.DTBSFROM.Location = new System.Drawing.Point(346, 56);
            this.DTBSFROM.MinimumSize = new System.Drawing.Size(4, 29);
            this.DTBSFROM.Name = "DTBSFROM";
            this.DTBSFROM.Size = new System.Drawing.Size(200, 29);
            this.DTBSFROM.TabIndex = 190;
            this.DTBSFROM.ValueChanged += new System.EventHandler(this.DTBSFROM_ValueChanged);
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label173.ForeColor = System.Drawing.Color.Red;
            this.label173.Location = new System.Drawing.Point(662, 102);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(15, 18);
            this.label173.TabIndex = 189;
            this.label173.Text = "*";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label174.Location = new System.Drawing.Point(361, 99);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(82, 14);
            this.label174.TabIndex = 188;
            this.label174.Text = "ShortIdentifier:";
            // 
            // SIBS
            // 
            this.SIBS.BackColor = System.Drawing.SystemColors.HighlightText;
            this.SIBS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SIBS.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SIBS.ForeColor = System.Drawing.SystemColors.InfoText;
            this.SIBS.Location = new System.Drawing.Point(366, 128);
            this.SIBS.Name = "SIBS";
            this.SIBS.Size = new System.Drawing.Size(324, 24);
            this.SIBS.TabIndex = 187;
            this.SIBS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label171.ForeColor = System.Drawing.Color.Red;
            this.label171.Location = new System.Drawing.Point(319, 102);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(15, 18);
            this.label171.TabIndex = 186;
            this.label171.Text = "*";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label172.Location = new System.Drawing.Point(18, 99);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(66, 14);
            this.label172.TabIndex = 185;
            this.label172.Text = "LongName:";
            // 
            // LNBS
            // 
            this.LNBS.BackColor = System.Drawing.SystemColors.HighlightText;
            this.LNBS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LNBS.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNBS.ForeColor = System.Drawing.SystemColors.InfoText;
            this.LNBS.Location = new System.Drawing.Point(23, 128);
            this.LNBS.Name = "LNBS";
            this.LNBS.Size = new System.Drawing.Size(324, 24);
            this.LNBS.TabIndex = 184;
            this.LNBS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label169.ForeColor = System.Drawing.Color.Red;
            this.label169.Location = new System.Drawing.Point(868, 99);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(15, 18);
            this.label169.TabIndex = 183;
            this.label169.Text = "*";
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label170.Location = new System.Drawing.Point(696, 99);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(58, 14);
            this.label170.TabIndex = 182;
            this.label170.Text = "Vehicle ID:";
            // 
            // VIDBS
            // 
            this.VIDBS.BackColor = System.Drawing.SystemColors.HighlightText;
            this.VIDBS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.VIDBS.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VIDBS.ForeColor = System.Drawing.SystemColors.InfoText;
            this.VIDBS.Location = new System.Drawing.Point(701, 128);
            this.VIDBS.Name = "VIDBS";
            this.VIDBS.Size = new System.Drawing.Size(149, 24);
            this.VIDBS.TabIndex = 181;
            this.VIDBS.TextChanged += new System.EventHandler(this.VIDBS_TextChanged);
            this.VIDBS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // TIDBS
            // 
            this.TIDBS.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.TIDBS.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TIDBS.FormattingEnabled = true;
            this.TIDBS.ItemHeight = 23;
            this.TIDBS.Location = new System.Drawing.Point(23, 54);
            this.TIDBS.Name = "TIDBS";
            this.TIDBS.Size = new System.Drawing.Size(295, 29);
            this.TIDBS.Sorted = true;
            this.TIDBS.TabIndex = 166;
            this.TIDBS.UseSelectable = true;
            this.TIDBS.UseStyleColors = true;
            this.TIDBS.SelectedIndexChanged += new System.EventHandler(this.TIDBS_SelectedIndexChanged);
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label167.ForeColor = System.Drawing.Color.Red;
            this.label167.Location = new System.Drawing.Point(290, 27);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(15, 18);
            this.label167.TabIndex = 165;
            this.label167.Text = "*";
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label168.Location = new System.Drawing.Point(18, 27);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(65, 14);
            this.label168.TabIndex = 164;
            this.label168.Text = "Terminal ID:";
            // 
            // tb21
            // 
            this.tb21.Controls.Add(this.panel21);
            this.tb21.Location = new System.Drawing.Point(4, 34);
            this.tb21.Name = "tb21";
            this.tb21.Size = new System.Drawing.Size(862, 565);
            this.tb21.TabIndex = 20;
            this.tb21.Text = "Query Runner";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel21.Controls.Add(this.labelAlert);
            this.panel21.Controls.Add(this.dgvQUERY);
            this.panel21.Controls.Add(this.button3);
            this.panel21.Controls.Add(this.label180);
            this.panel21.Controls.Add(this.textBoxQuery);
            this.panel21.Controls.Add(this.buttonQuery);
            this.panel21.Controls.Add(this.labelQuery);
            this.panel21.Controls.Add(this.label178);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(862, 565);
            this.panel21.TabIndex = 84;
            // 
            // labelAlert
            // 
            this.labelAlert.AutoSize = true;
            this.labelAlert.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAlert.Location = new System.Drawing.Point(4, 407);
            this.labelAlert.Name = "labelAlert";
            this.labelAlert.Size = new System.Drawing.Size(0, 14);
            this.labelAlert.TabIndex = 215;
            // 
            // dgvQUERY
            // 
            this.dgvQUERY.AllowUserToAddRows = false;
            this.dgvQUERY.AllowUserToResizeRows = false;
            this.dgvQUERY.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvQUERY.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvQUERY.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvQUERY.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvQUERY.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvQUERY.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle898.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle898.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle898.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle898.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle898.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle898.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle898.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQUERY.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle898;
            this.dgvQUERY.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle899.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle899.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle899.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle899.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle899.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle899.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle899.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQUERY.DefaultCellStyle = dataGridViewCellStyle899;
            this.dgvQUERY.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQUERY.EnableHeadersVisualStyles = false;
            this.dgvQUERY.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvQUERY.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvQUERY.Location = new System.Drawing.Point(0, 430);
            this.dgvQUERY.MultiSelect = false;
            this.dgvQUERY.Name = "dgvQUERY";
            this.dgvQUERY.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle900.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle900.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle900.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle900.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle900.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle900.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle900.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQUERY.RowHeadersDefaultCellStyle = dataGridViewCellStyle900;
            this.dgvQUERY.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvQUERY.RowTemplate.Height = 33;
            this.dgvQUERY.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQUERY.Size = new System.Drawing.Size(862, 135);
            this.dgvQUERY.TabIndex = 214;
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(790, 83);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(34, 36);
            this.button3.TabIndex = 213;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label180.Location = new System.Drawing.Point(4, 112);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(41, 14);
            this.label180.TabIndex = 202;
            this.label180.Text = "Query:";
            // 
            // textBoxQuery
            // 
            this.textBoxQuery.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxQuery.Location = new System.Drawing.Point(10, 144);
            this.textBoxQuery.Multiline = true;
            this.textBoxQuery.Name = "textBoxQuery";
            this.textBoxQuery.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxQuery.Size = new System.Drawing.Size(810, 266);
            this.textBoxQuery.TabIndex = 201;
            // 
            // buttonQuery
            // 
            this.buttonQuery.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonQuery.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQuery.Location = new System.Drawing.Point(9, 30);
            this.buttonQuery.Name = "buttonQuery";
            this.buttonQuery.Size = new System.Drawing.Size(109, 33);
            this.buttonQuery.TabIndex = 198;
            this.buttonQuery.Text = "Open File";
            this.buttonQuery.UseVisualStyleBackColor = true;
            this.buttonQuery.Click += new System.EventHandler(this.buttonQuery_Click);
            // 
            // labelQuery
            // 
            this.labelQuery.AutoSize = true;
            this.labelQuery.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelQuery.Location = new System.Drawing.Point(119, 39);
            this.labelQuery.Name = "labelQuery";
            this.labelQuery.Size = new System.Drawing.Size(88, 14);
            this.labelQuery.TabIndex = 197;
            this.labelQuery.Text = "No file selected.";
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label178.Location = new System.Drawing.Point(4, 1);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(59, 14);
            this.label178.TabIndex = 196;
            this.label178.Text = "Select File:";
            // 
            // tb22
            // 
            this.tb22.Controls.Add(this.panel22);
            this.tb22.Location = new System.Drawing.Point(4, 34);
            this.tb22.Name = "tb22";
            this.tb22.Size = new System.Drawing.Size(862, 565);
            this.tb22.TabIndex = 21;
            this.tb22.Text = "SingleFixFare";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel22.Controls.Add(this.panelSFF);
            this.panel22.Controls.Add(this.SFFacc);
            this.panel22.Controls.Add(this.SFFPro);
            this.panel22.Controls.Add(this.buttonexpsff);
            this.panel22.Controls.Add(this.buttonSaveSFF);
            this.panel22.Controls.Add(this.buttonSFFDEL);
            this.panel22.Controls.Add(this.dgvSFF);
            this.panel22.Controls.Add(this.checkBoxSFF_A);
            this.panel22.Controls.Add(this.label78);
            this.panel22.Controls.Add(this.label79);
            this.panel22.Controls.Add(this.textBoxSFF_FA);
            this.panel22.Controls.Add(this.buttonSFFADD);
            this.panel22.Controls.Add(this.label49);
            this.panel22.Controls.Add(this.label60);
            this.panel22.Controls.Add(this.metroDateTimeSFF_TO);
            this.panel22.Controls.Add(this.metroDateTimeSFF_FROM);
            this.panel22.Controls.Add(this.label73);
            this.panel22.Controls.Add(this.label74);
            this.panel22.Controls.Add(this.textBoxSFF_FTID);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(862, 565);
            this.panel22.TabIndex = 84;
            // 
            // panelSFF
            // 
            this.panelSFF.Controls.Add(this.SFFPro2);
            this.panelSFF.Controls.Add(this.SFFacc2);
            this.panelSFF.Controls.Add(this.checkBoxSFF_A2);
            this.panelSFF.Controls.Add(this.label214);
            this.panelSFF.Controls.Add(this.label215);
            this.panelSFF.Controls.Add(this.textBoxSFF_FA2);
            this.panelSFF.Controls.Add(this.label216);
            this.panelSFF.Controls.Add(this.label217);
            this.panelSFF.Controls.Add(this.metroDateTimeSFF_TO2);
            this.panelSFF.Controls.Add(this.metroDateTimeSFF_FROM2);
            this.panelSFF.Controls.Add(this.label218);
            this.panelSFF.Controls.Add(this.label219);
            this.panelSFF.Controls.Add(this.textBoxSFF_FTID2);
            this.panelSFF.Location = new System.Drawing.Point(17, 15);
            this.panelSFF.Name = "panelSFF";
            this.panelSFF.Size = new System.Drawing.Size(678, 145);
            this.panelSFF.TabIndex = 83;
            this.panelSFF.Visible = false;
            // 
            // SFFPro2
            // 
            this.SFFPro2.AutoSize = true;
            this.SFFPro2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SFFPro2.Location = new System.Drawing.Point(405, 106);
            this.SFFPro2.Name = "SFFPro2";
            this.SFFPro2.Size = new System.Drawing.Size(70, 18);
            this.SFFPro2.TabIndex = 215;
            this.SFFPro2.Text = "Prorated";
            this.SFFPro2.UseVisualStyleBackColor = true;
            // 
            // SFFacc2
            // 
            this.SFFacc2.AutoSize = true;
            this.SFFacc2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SFFacc2.Location = new System.Drawing.Point(307, 106);
            this.SFFacc2.Name = "SFFacc2";
            this.SFFacc2.Size = new System.Drawing.Size(93, 18);
            this.SFFacc2.TabIndex = 214;
            this.SFFacc2.Text = "Accumulative";
            this.SFFacc2.UseVisualStyleBackColor = true;
            // 
            // checkBoxSFF_A2
            // 
            this.checkBoxSFF_A2.AutoSize = true;
            this.checkBoxSFF_A2.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSFF_A2.Location = new System.Drawing.Point(254, 106);
            this.checkBoxSFF_A2.Name = "checkBoxSFF_A2";
            this.checkBoxSFF_A2.Size = new System.Drawing.Size(57, 18);
            this.checkBoxSFF_A2.TabIndex = 213;
            this.checkBoxSFF_A2.Text = "Active";
            this.checkBoxSFF_A2.UseVisualStyleBackColor = true;
            // 
            // label214
            // 
            this.label214.AutoSize = true;
            this.label214.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label214.ForeColor = System.Drawing.Color.Red;
            this.label214.Location = new System.Drawing.Point(184, 75);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(15, 18);
            this.label214.TabIndex = 212;
            this.label214.Text = "*";
            // 
            // label215
            // 
            this.label215.AutoSize = true;
            this.label215.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label215.Location = new System.Drawing.Point(3, 73);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(75, 14);
            this.label215.TabIndex = 211;
            this.label215.Text = "Fare Amount:";
            // 
            // textBoxSFF_FA2
            // 
            this.textBoxSFF_FA2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSFF_FA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSFF_FA2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSFF_FA2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSFF_FA2.Location = new System.Drawing.Point(8, 102);
            this.textBoxSFF_FA2.MaxLength = 10;
            this.textBoxSFF_FA2.Name = "textBoxSFF_FA2";
            this.textBoxSFF_FA2.Size = new System.Drawing.Size(204, 24);
            this.textBoxSFF_FA2.TabIndex = 210;
            this.textBoxSFF_FA2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label216
            // 
            this.label216.AutoSize = true;
            this.label216.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label216.Location = new System.Drawing.Point(457, 35);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(18, 14);
            this.label216.TabIndex = 209;
            this.label216.Text = "to";
            // 
            // label217
            // 
            this.label217.AutoSize = true;
            this.label217.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label217.Location = new System.Drawing.Point(250, -3);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(78, 14);
            this.label217.TabIndex = 207;
            this.label217.Text = "Effective Date";
            // 
            // metroDateTimeSFF_TO2
            // 
            this.metroDateTimeSFF_TO2.Location = new System.Drawing.Point(475, 26);
            this.metroDateTimeSFF_TO2.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeSFF_TO2.Name = "metroDateTimeSFF_TO2";
            this.metroDateTimeSFF_TO2.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeSFF_TO2.TabIndex = 208;
            // 
            // metroDateTimeSFF_FROM2
            // 
            this.metroDateTimeSFF_FROM2.Location = new System.Drawing.Point(254, 26);
            this.metroDateTimeSFF_FROM2.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeSFF_FROM2.Name = "metroDateTimeSFF_FROM2";
            this.metroDateTimeSFF_FROM2.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeSFF_FROM2.TabIndex = 206;
            this.metroDateTimeSFF_FROM2.ValueChanged += new System.EventHandler(this.metroDateTimeSFF_FROM2_ValueChanged);
            // 
            // label218
            // 
            this.label218.AutoSize = true;
            this.label218.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label218.ForeColor = System.Drawing.Color.Red;
            this.label218.Location = new System.Drawing.Point(184, 2);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(15, 18);
            this.label218.TabIndex = 205;
            this.label218.Text = "*";
            // 
            // label219
            // 
            this.label219.AutoSize = true;
            this.label219.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label219.Location = new System.Drawing.Point(3, 0);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(101, 14);
            this.label219.TabIndex = 204;
            this.label219.Text = "New Fare Table ID:";
            // 
            // textBoxSFF_FTID2
            // 
            this.textBoxSFF_FTID2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSFF_FTID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSFF_FTID2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSFF_FTID2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSFF_FTID2.Location = new System.Drawing.Point(8, 29);
            this.textBoxSFF_FTID2.MaxLength = 10;
            this.textBoxSFF_FTID2.Name = "textBoxSFF_FTID2";
            this.textBoxSFF_FTID2.Size = new System.Drawing.Size(204, 24);
            this.textBoxSFF_FTID2.TabIndex = 203;
            this.textBoxSFF_FTID2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // SFFacc
            // 
            this.SFFacc.AutoSize = true;
            this.SFFacc.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SFFacc.Location = new System.Drawing.Point(326, 123);
            this.SFFacc.Name = "SFFacc";
            this.SFFacc.Size = new System.Drawing.Size(93, 18);
            this.SFFacc.TabIndex = 207;
            this.SFFacc.Text = "Accumulative";
            this.SFFacc.UseVisualStyleBackColor = true;
            // 
            // SFFPro
            // 
            this.SFFPro.AutoSize = true;
            this.SFFPro.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SFFPro.Location = new System.Drawing.Point(425, 123);
            this.SFFPro.Name = "SFFPro";
            this.SFFPro.Size = new System.Drawing.Size(70, 18);
            this.SFFPro.TabIndex = 208;
            this.SFFPro.Text = "Prorated";
            this.SFFPro.UseVisualStyleBackColor = true;
            // 
            // buttonexpsff
            // 
            this.buttonexpsff.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpsff.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpsff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpsff.Location = new System.Drawing.Point(711, 234);
            this.buttonexpsff.Name = "buttonexpsff";
            this.buttonexpsff.Size = new System.Drawing.Size(133, 45);
            this.buttonexpsff.TabIndex = 206;
            this.buttonexpsff.Text = "Export";
            this.buttonexpsff.UseVisualStyleBackColor = false;
            this.buttonexpsff.Click += new System.EventHandler(this.buttonexpsff_Click);
            // 
            // buttonSaveSFF
            // 
            this.buttonSaveSFF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveSFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveSFF.Location = new System.Drawing.Point(703, 93);
            this.buttonSaveSFF.Name = "buttonSaveSFF";
            this.buttonSaveSFF.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveSFF.TabIndex = 205;
            this.buttonSaveSFF.Text = "Save";
            this.buttonSaveSFF.UseVisualStyleBackColor = true;
            this.buttonSaveSFF.Visible = false;
            this.buttonSaveSFF.Click += new System.EventHandler(this.buttonSaveSFF_Click_1);
            // 
            // buttonSFFDEL
            // 
            this.buttonSFFDEL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonSFFDEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSFFDEL.Location = new System.Drawing.Point(0, 238);
            this.buttonSFFDEL.Name = "buttonSFFDEL";
            this.buttonSFFDEL.Size = new System.Drawing.Size(111, 41);
            this.buttonSFFDEL.TabIndex = 204;
            this.buttonSFFDEL.Text = "Delete";
            this.buttonSFFDEL.UseVisualStyleBackColor = true;
            this.buttonSFFDEL.Visible = false;
            this.buttonSFFDEL.Click += new System.EventHandler(this.buttonSFFDEL_Click);
            // 
            // dgvSFF
            // 
            this.dgvSFF.AllowUserToAddRows = false;
            this.dgvSFF.AllowUserToResizeRows = false;
            this.dgvSFF.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSFF.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSFF.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSFF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSFF.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvSFF.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle901.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle901.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle901.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle901.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle901.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle901.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle901.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSFF.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle901;
            this.dgvSFF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle902.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle902.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle902.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle902.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle902.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle902.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle902.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSFF.DefaultCellStyle = dataGridViewCellStyle902;
            this.dgvSFF.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvSFF.EnableHeadersVisualStyles = false;
            this.dgvSFF.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvSFF.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSFF.Location = new System.Drawing.Point(0, 256);
            this.dgvSFF.MultiSelect = false;
            this.dgvSFF.Name = "dgvSFF";
            this.dgvSFF.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle903.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle903.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle903.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle903.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle903.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle903.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle903.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSFF.RowHeadersDefaultCellStyle = dataGridViewCellStyle903;
            this.dgvSFF.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSFF.RowTemplate.Height = 33;
            this.dgvSFF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSFF.Size = new System.Drawing.Size(862, 309);
            this.dgvSFF.TabIndex = 203;
            this.dgvSFF.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSFF_CellDoubleClick);
            // 
            // checkBoxSFF_A
            // 
            this.checkBoxSFF_A.AutoSize = true;
            this.checkBoxSFF_A.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSFF_A.Location = new System.Drawing.Point(274, 124);
            this.checkBoxSFF_A.Name = "checkBoxSFF_A";
            this.checkBoxSFF_A.Size = new System.Drawing.Size(57, 18);
            this.checkBoxSFF_A.TabIndex = 202;
            this.checkBoxSFF_A.Text = "Active";
            this.checkBoxSFF_A.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.Red;
            this.label78.Location = new System.Drawing.Point(204, 93);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(15, 18);
            this.label78.TabIndex = 201;
            this.label78.Text = "*";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(23, 91);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(75, 14);
            this.label79.TabIndex = 200;
            this.label79.Text = "Fare Amount:";
            // 
            // textBoxSFF_FA
            // 
            this.textBoxSFF_FA.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSFF_FA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSFF_FA.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSFF_FA.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSFF_FA.Location = new System.Drawing.Point(28, 120);
            this.textBoxSFF_FA.MaxLength = 10;
            this.textBoxSFF_FA.Name = "textBoxSFF_FA";
            this.textBoxSFF_FA.Size = new System.Drawing.Size(204, 24);
            this.textBoxSFF_FA.TabIndex = 199;
            this.textBoxSFF_FA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // buttonSFFADD
            // 
            this.buttonSFFADD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSFFADD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSFFADD.Location = new System.Drawing.Point(703, 41);
            this.buttonSFFADD.Name = "buttonSFFADD";
            this.buttonSFFADD.Size = new System.Drawing.Size(133, 45);
            this.buttonSFFADD.TabIndex = 198;
            this.buttonSFFADD.Text = "Add";
            this.buttonSFFADD.UseVisualStyleBackColor = true;
            this.buttonSFFADD.Click += new System.EventHandler(this.buttonSFFADD_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(477, 53);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(18, 14);
            this.label49.TabIndex = 197;
            this.label49.Text = "to";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(270, 15);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(78, 14);
            this.label60.TabIndex = 195;
            this.label60.Text = "Effective Date";
            // 
            // metroDateTimeSFF_TO
            // 
            this.metroDateTimeSFF_TO.Location = new System.Drawing.Point(495, 44);
            this.metroDateTimeSFF_TO.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeSFF_TO.Name = "metroDateTimeSFF_TO";
            this.metroDateTimeSFF_TO.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeSFF_TO.TabIndex = 196;
            // 
            // metroDateTimeSFF_FROM
            // 
            this.metroDateTimeSFF_FROM.Location = new System.Drawing.Point(274, 44);
            this.metroDateTimeSFF_FROM.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTimeSFF_FROM.Name = "metroDateTimeSFF_FROM";
            this.metroDateTimeSFF_FROM.Size = new System.Drawing.Size(200, 29);
            this.metroDateTimeSFF_FROM.TabIndex = 194;
            this.metroDateTimeSFF_FROM.ValueChanged += new System.EventHandler(this.metroDateTimeSFF_FROM_ValueChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.Red;
            this.label73.Location = new System.Drawing.Point(204, 20);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(15, 18);
            this.label73.TabIndex = 193;
            this.label73.Text = "*";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(23, 18);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(75, 14);
            this.label74.TabIndex = 192;
            this.label74.Text = "Fare Table ID:";
            // 
            // textBoxSFF_FTID
            // 
            this.textBoxSFF_FTID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxSFF_FTID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSFF_FTID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSFF_FTID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxSFF_FTID.Location = new System.Drawing.Point(28, 47);
            this.textBoxSFF_FTID.MaxLength = 10;
            this.textBoxSFF_FTID.Name = "textBoxSFF_FTID";
            this.textBoxSFF_FTID.Size = new System.Drawing.Size(204, 24);
            this.textBoxSFF_FTID.TabIndex = 191;
            this.textBoxSFF_FTID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // tb23
            // 
            this.tb23.Controls.Add(this.panel23);
            this.tb23.Location = new System.Drawing.Point(4, 34);
            this.tb23.Name = "tb23";
            this.tb23.Size = new System.Drawing.Size(862, 565);
            this.tb23.TabIndex = 22;
            this.tb23.Text = "DistanceBasedCardProfiles";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel23.Controls.Add(this.buttonexpdbcp);
            this.panel23.Controls.Add(this.panelDBCP);
            this.panel23.Controls.Add(this.buttonSaveDBCP);
            this.panel23.Controls.Add(this.buttonDBCPDEL);
            this.panel23.Controls.Add(this.dgvDBCP);
            this.panel23.Controls.Add(this.buttonDBCPADD);
            this.panel23.Controls.Add(this.metroComboBoxDBCP_DFTID);
            this.panel23.Controls.Add(this.label103);
            this.panel23.Controls.Add(this.label107);
            this.panel23.Controls.Add(this.label88);
            this.panel23.Controls.Add(this.label95);
            this.panel23.Controls.Add(this.textBoxDBCP_CPID);
            this.panel23.Controls.Add(this.label97);
            this.panel23.Controls.Add(this.label100);
            this.panel23.Controls.Add(this.textBoxDBCP_CPN);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(862, 565);
            this.panel23.TabIndex = 84;
            // 
            // buttonexpdbcp
            // 
            this.buttonexpdbcp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexpdbcp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexpdbcp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexpdbcp.Location = new System.Drawing.Point(704, 220);
            this.buttonexpdbcp.Name = "buttonexpdbcp";
            this.buttonexpdbcp.Size = new System.Drawing.Size(133, 45);
            this.buttonexpdbcp.TabIndex = 215;
            this.buttonexpdbcp.Text = "Export";
            this.buttonexpdbcp.UseVisualStyleBackColor = false;
            this.buttonexpdbcp.Click += new System.EventHandler(this.buttonexpdbcp_Click);
            // 
            // panelDBCP
            // 
            this.panelDBCP.Controls.Add(this.metroComboBoxDBCP_DFTID2);
            this.panelDBCP.Controls.Add(this.label220);
            this.panelDBCP.Controls.Add(this.label221);
            this.panelDBCP.Controls.Add(this.label222);
            this.panelDBCP.Controls.Add(this.label223);
            this.panelDBCP.Controls.Add(this.textBoxDBCP_CPID2);
            this.panelDBCP.Controls.Add(this.label224);
            this.panelDBCP.Controls.Add(this.label225);
            this.panelDBCP.Controls.Add(this.textBoxDBCP_CPN2);
            this.panelDBCP.Location = new System.Drawing.Point(29, 19);
            this.panelDBCP.Name = "panelDBCP";
            this.panelDBCP.Size = new System.Drawing.Size(660, 151);
            this.panelDBCP.TabIndex = 83;
            this.panelDBCP.Visible = false;
            // 
            // metroComboBoxDBCP_DFTID2
            // 
            this.metroComboBoxDBCP_DFTID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxDBCP_DFTID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxDBCP_DFTID2.FormattingEnabled = true;
            this.metroComboBoxDBCP_DFTID2.ItemHeight = 23;
            this.metroComboBoxDBCP_DFTID2.Location = new System.Drawing.Point(418, 33);
            this.metroComboBoxDBCP_DFTID2.Name = "metroComboBoxDBCP_DFTID2";
            this.metroComboBoxDBCP_DFTID2.Size = new System.Drawing.Size(237, 29);
            this.metroComboBoxDBCP_DFTID2.Sorted = true;
            this.metroComboBoxDBCP_DFTID2.TabIndex = 219;
            this.metroComboBoxDBCP_DFTID2.UseSelectable = true;
            this.metroComboBoxDBCP_DFTID2.UseStyleColors = true;
            this.metroComboBoxDBCP_DFTID2.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxDBCP_DFTID2_SelectedIndexChanged);
            this.metroComboBoxDBCP_DFTID2.TextChanged += new System.EventHandler(this.metroComboBoxDBCP_DFTID2_TextChanged);
            // 
            // label220
            // 
            this.label220.AutoSize = true;
            this.label220.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label220.ForeColor = System.Drawing.Color.Red;
            this.label220.Location = new System.Drawing.Point(627, 8);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(15, 18);
            this.label220.TabIndex = 218;
            this.label220.Text = "*";
            // 
            // label221
            // 
            this.label221.AutoSize = true;
            this.label221.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label221.Location = new System.Drawing.Point(413, 10);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(119, 14);
            this.label221.TabIndex = 217;
            this.label221.Text = "Discount FareTable ID:";
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label222.ForeColor = System.Drawing.Color.Red;
            this.label222.Location = new System.Drawing.Point(184, 80);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(15, 18);
            this.label222.TabIndex = 216;
            this.label222.Text = "*";
            // 
            // label223
            // 
            this.label223.AutoSize = true;
            this.label223.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label223.Location = new System.Drawing.Point(3, 78);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(84, 14);
            this.label223.TabIndex = 215;
            this.label223.Text = "Card Profile ID:";
            // 
            // textBoxDBCP_CPID2
            // 
            this.textBoxDBCP_CPID2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBCP_CPID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBCP_CPID2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBCP_CPID2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxDBCP_CPID2.Location = new System.Drawing.Point(8, 107);
            this.textBoxDBCP_CPID2.MaxLength = 10;
            this.textBoxDBCP_CPID2.Name = "textBoxDBCP_CPID2";
            this.textBoxDBCP_CPID2.Size = new System.Drawing.Size(204, 24);
            this.textBoxDBCP_CPID2.TabIndex = 214;
            this.textBoxDBCP_CPID2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label224
            // 
            this.label224.AutoSize = true;
            this.label224.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label224.ForeColor = System.Drawing.Color.Red;
            this.label224.Location = new System.Drawing.Point(389, 5);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(15, 18);
            this.label224.TabIndex = 213;
            this.label224.Text = "*";
            // 
            // label225
            // 
            this.label225.AutoSize = true;
            this.label225.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label225.Location = new System.Drawing.Point(3, 5);
            this.label225.Name = "label225";
            this.label225.Size = new System.Drawing.Size(129, 14);
            this.label225.TabIndex = 212;
            this.label225.Text = "New Card Profile Name:";
            // 
            // textBoxDBCP_CPN2
            // 
            this.textBoxDBCP_CPN2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBCP_CPN2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBCP_CPN2.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBCP_CPN2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxDBCP_CPN2.Location = new System.Drawing.Point(8, 34);
            this.textBoxDBCP_CPN2.MaxLength = 80;
            this.textBoxDBCP_CPN2.Name = "textBoxDBCP_CPN2";
            this.textBoxDBCP_CPN2.Size = new System.Drawing.Size(402, 24);
            this.textBoxDBCP_CPN2.TabIndex = 211;
            // 
            // buttonSaveDBCP
            // 
            this.buttonSaveDBCP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSaveDBCP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveDBCP.Location = new System.Drawing.Point(704, 99);
            this.buttonSaveDBCP.Name = "buttonSaveDBCP";
            this.buttonSaveDBCP.Size = new System.Drawing.Size(133, 45);
            this.buttonSaveDBCP.TabIndex = 214;
            this.buttonSaveDBCP.Text = "Save";
            this.buttonSaveDBCP.UseVisualStyleBackColor = true;
            this.buttonSaveDBCP.Visible = false;
            this.buttonSaveDBCP.Click += new System.EventHandler(this.buttonSaveDBCP_Click);
            // 
            // buttonDBCPDEL
            // 
            this.buttonDBCPDEL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDBCPDEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBCPDEL.Location = new System.Drawing.Point(0, 222);
            this.buttonDBCPDEL.Name = "buttonDBCPDEL";
            this.buttonDBCPDEL.Size = new System.Drawing.Size(111, 41);
            this.buttonDBCPDEL.TabIndex = 213;
            this.buttonDBCPDEL.Text = "Delete";
            this.buttonDBCPDEL.UseVisualStyleBackColor = true;
            this.buttonDBCPDEL.Visible = false;
            this.buttonDBCPDEL.Click += new System.EventHandler(this.buttonDBCPDEL_Click);
            // 
            // dgvDBCP
            // 
            this.dgvDBCP.AllowUserToAddRows = false;
            this.dgvDBCP.AllowUserToResizeRows = false;
            this.dgvDBCP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDBCP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDBCP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBCP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDBCP.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvDBCP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle904.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle904.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle904.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle904.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle904.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle904.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle904.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBCP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle904;
            this.dgvDBCP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle905.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle905.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle905.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle905.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle905.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle905.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle905.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDBCP.DefaultCellStyle = dataGridViewCellStyle905;
            this.dgvDBCP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDBCP.EnableHeadersVisualStyles = false;
            this.dgvDBCP.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvDBCP.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvDBCP.Location = new System.Drawing.Point(0, 241);
            this.dgvDBCP.MultiSelect = false;
            this.dgvDBCP.Name = "dgvDBCP";
            this.dgvDBCP.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle906.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle906.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle906.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle906.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle906.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle906.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle906.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDBCP.RowHeadersDefaultCellStyle = dataGridViewCellStyle906;
            this.dgvDBCP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvDBCP.RowTemplate.Height = 33;
            this.dgvDBCP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDBCP.Size = new System.Drawing.Size(862, 324);
            this.dgvDBCP.TabIndex = 212;
            this.dgvDBCP.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDBCP_CellDoubleClick);
            // 
            // buttonDBCPADD
            // 
            this.buttonDBCPADD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonDBCPADD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBCPADD.Location = new System.Drawing.Point(704, 49);
            this.buttonDBCPADD.Name = "buttonDBCPADD";
            this.buttonDBCPADD.Size = new System.Drawing.Size(133, 45);
            this.buttonDBCPADD.TabIndex = 211;
            this.buttonDBCPADD.Text = "Add";
            this.buttonDBCPADD.UseVisualStyleBackColor = true;
            this.buttonDBCPADD.Click += new System.EventHandler(this.buttonDBCPADD_Click);
            // 
            // metroComboBoxDBCP_DFTID
            // 
            this.metroComboBoxDBCP_DFTID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxDBCP_DFTID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxDBCP_DFTID.FormattingEnabled = true;
            this.metroComboBoxDBCP_DFTID.ItemHeight = 23;
            this.metroComboBoxDBCP_DFTID.Location = new System.Drawing.Point(447, 52);
            this.metroComboBoxDBCP_DFTID.Name = "metroComboBoxDBCP_DFTID";
            this.metroComboBoxDBCP_DFTID.Size = new System.Drawing.Size(237, 29);
            this.metroComboBoxDBCP_DFTID.Sorted = true;
            this.metroComboBoxDBCP_DFTID.TabIndex = 210;
            this.metroComboBoxDBCP_DFTID.UseSelectable = true;
            this.metroComboBoxDBCP_DFTID.UseStyleColors = true;
            this.metroComboBoxDBCP_DFTID.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxDBCP_DFTID_SelectedIndexChanged);
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.ForeColor = System.Drawing.Color.Red;
            this.label103.Location = new System.Drawing.Point(656, 27);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(15, 18);
            this.label103.TabIndex = 209;
            this.label103.Text = "*";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(442, 29);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(119, 14);
            this.label107.TabIndex = 208;
            this.label107.Text = "Discount FareTable ID:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.Color.Red;
            this.label88.Location = new System.Drawing.Point(213, 99);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(15, 18);
            this.label88.TabIndex = 207;
            this.label88.Text = "*";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(32, 97);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(84, 14);
            this.label95.TabIndex = 206;
            this.label95.Text = "Card Profile ID:";
            // 
            // textBoxDBCP_CPID
            // 
            this.textBoxDBCP_CPID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBCP_CPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBCP_CPID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBCP_CPID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxDBCP_CPID.Location = new System.Drawing.Point(37, 126);
            this.textBoxDBCP_CPID.MaxLength = 10;
            this.textBoxDBCP_CPID.Name = "textBoxDBCP_CPID";
            this.textBoxDBCP_CPID.Size = new System.Drawing.Size(204, 24);
            this.textBoxDBCP_CPID.TabIndex = 205;
            this.textBoxDBCP_CPID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.ForeColor = System.Drawing.Color.Red;
            this.label97.Location = new System.Drawing.Point(418, 24);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(15, 18);
            this.label97.TabIndex = 204;
            this.label97.Text = "*";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(32, 24);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(103, 14);
            this.label100.TabIndex = 203;
            this.label100.Text = "Card Profile Name:";
            // 
            // textBoxDBCP_CPN
            // 
            this.textBoxDBCP_CPN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxDBCP_CPN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDBCP_CPN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDBCP_CPN.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxDBCP_CPN.Location = new System.Drawing.Point(37, 53);
            this.textBoxDBCP_CPN.MaxLength = 80;
            this.textBoxDBCP_CPN.Name = "textBoxDBCP_CPN";
            this.textBoxDBCP_CPN.Size = new System.Drawing.Size(402, 24);
            this.textBoxDBCP_CPN.TabIndex = 202;
            this.textBoxDBCP_CPN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keyboard_KeyPress);
            // 
            // tb24
            // 
            this.tb24.Controls.Add(this.p);
            this.tb24.Location = new System.Drawing.Point(4, 34);
            this.tb24.Name = "tb24";
            this.tb24.Size = new System.Drawing.Size(862, 565);
            this.tb24.TabIndex = 23;
            this.tb24.Text = "Search Query";
            // 
            // p
            // 
            this.p.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.p.Controls.Add(this.dgvSEARCH);
            this.p.Controls.Add(this.metroComboBoxSearchParam);
            this.p.Controls.Add(this.label267);
            this.p.Controls.Add(this.panelUID);
            this.p.Controls.Add(this.panelTerminalID);
            this.p.Controls.Add(this.panelProfileID);
            this.p.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p.Location = new System.Drawing.Point(0, 0);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(862, 565);
            this.p.TabIndex = 74;
            // 
            // dgvSEARCH
            // 
            this.dgvSEARCH.AllowUserToAddRows = false;
            this.dgvSEARCH.AllowUserToResizeRows = false;
            this.dgvSEARCH.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSEARCH.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSEARCH.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSEARCH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSEARCH.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvSEARCH.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle907.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle907.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle907.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle907.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle907.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle907.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle907.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSEARCH.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle907;
            this.dgvSEARCH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle908.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle908.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle908.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle908.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle908.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle908.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle908.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSEARCH.DefaultCellStyle = dataGridViewCellStyle908;
            this.dgvSEARCH.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvSEARCH.EnableHeadersVisualStyles = false;
            this.dgvSEARCH.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvSEARCH.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSEARCH.Location = new System.Drawing.Point(0, 207);
            this.dgvSEARCH.MultiSelect = false;
            this.dgvSEARCH.Name = "dgvSEARCH";
            this.dgvSEARCH.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle909.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle909.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle909.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle909.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle909.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle909.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle909.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSEARCH.RowHeadersDefaultCellStyle = dataGridViewCellStyle909;
            this.dgvSEARCH.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSEARCH.RowTemplate.Height = 33;
            this.dgvSEARCH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSEARCH.Size = new System.Drawing.Size(862, 358);
            this.dgvSEARCH.TabIndex = 204;
            this.dgvSEARCH.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSEARCH_CellClick);
            // 
            // metroComboBoxSearchParam
            // 
            this.metroComboBoxSearchParam.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxSearchParam.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxSearchParam.FormattingEnabled = true;
            this.metroComboBoxSearchParam.ItemHeight = 23;
            this.metroComboBoxSearchParam.Items.AddRange(new object[] {
            "Terminal ID",
            "Profile ID",
            "UID",
            "UserCards"});
            this.metroComboBoxSearchParam.Location = new System.Drawing.Point(18, 35);
            this.metroComboBoxSearchParam.Name = "metroComboBoxSearchParam";
            this.metroComboBoxSearchParam.Size = new System.Drawing.Size(295, 29);
            this.metroComboBoxSearchParam.TabIndex = 199;
            this.metroComboBoxSearchParam.UseSelectable = true;
            this.metroComboBoxSearchParam.UseStyleColors = true;
            this.metroComboBoxSearchParam.SelectedIndexChanged += new System.EventHandler(this.metroComboBoxSearchParam_SelectedIndexChanged);
            // 
            // label267
            // 
            this.label267.AutoSize = true;
            this.label267.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label267.Location = new System.Drawing.Point(13, 8);
            this.label267.Name = "label267";
            this.label267.Size = new System.Drawing.Size(60, 14);
            this.label267.TabIndex = 197;
            this.label267.Text = "Search By:";
            // 
            // panelUID
            // 
            this.panelUID.Controls.Add(this.buttonUID);
            this.panelUID.Controls.Add(this.label274);
            this.panelUID.Controls.Add(this.textBoxUID);
            this.panelUID.Location = new System.Drawing.Point(3, 75);
            this.panelUID.Name = "panelUID";
            this.panelUID.Size = new System.Drawing.Size(847, 107);
            this.panelUID.TabIndex = 218;
            this.panelUID.Visible = false;
            // 
            // buttonUID
            // 
            this.buttonUID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUID.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonUID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonUID.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUID.FlatAppearance.BorderSize = 0;
            this.buttonUID.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonUID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUID.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUID.Location = new System.Drawing.Point(424, 36);
            this.buttonUID.Name = "buttonUID";
            this.buttonUID.Size = new System.Drawing.Size(24, 25);
            this.buttonUID.TabIndex = 216;
            this.buttonUID.UseVisualStyleBackColor = true;
            this.buttonUID.Click += new System.EventHandler(this.buttonUID_Click);
            // 
            // label274
            // 
            this.label274.AutoSize = true;
            this.label274.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label274.Location = new System.Drawing.Point(11, 9);
            this.label274.Name = "label274";
            this.label274.Size = new System.Drawing.Size(28, 14);
            this.label274.TabIndex = 215;
            this.label274.Text = "UID:";
            // 
            // textBoxUID
            // 
            this.textBoxUID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxUID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxUID.Location = new System.Drawing.Point(16, 38);
            this.textBoxUID.MaxLength = 80;
            this.textBoxUID.Name = "textBoxUID";
            this.textBoxUID.Size = new System.Drawing.Size(402, 24);
            this.textBoxUID.TabIndex = 214;
            // 
            // panelTerminalID
            // 
            this.panelTerminalID.Controls.Add(this.buttonSearchTerminal);
            this.panelTerminalID.Controls.Add(this.label269);
            this.panelTerminalID.Controls.Add(this.txtBxTerminalID);
            this.panelTerminalID.Location = new System.Drawing.Point(2, 75);
            this.panelTerminalID.Name = "panelTerminalID";
            this.panelTerminalID.Size = new System.Drawing.Size(847, 107);
            this.panelTerminalID.TabIndex = 200;
            // 
            // buttonSearchTerminal
            // 
            this.buttonSearchTerminal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSearchTerminal.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonSearchTerminal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSearchTerminal.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonSearchTerminal.FlatAppearance.BorderSize = 0;
            this.buttonSearchTerminal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonSearchTerminal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearchTerminal.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearchTerminal.Location = new System.Drawing.Point(424, 36);
            this.buttonSearchTerminal.Name = "buttonSearchTerminal";
            this.buttonSearchTerminal.Size = new System.Drawing.Size(24, 25);
            this.buttonSearchTerminal.TabIndex = 216;
            this.buttonSearchTerminal.UseVisualStyleBackColor = true;
            this.buttonSearchTerminal.Click += new System.EventHandler(this.button1_Click);
            // 
            // label269
            // 
            this.label269.AutoSize = true;
            this.label269.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label269.Location = new System.Drawing.Point(11, 9);
            this.label269.Name = "label269";
            this.label269.Size = new System.Drawing.Size(65, 14);
            this.label269.TabIndex = 215;
            this.label269.Text = "Terminal ID:";
            // 
            // txtBxTerminalID
            // 
            this.txtBxTerminalID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtBxTerminalID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBxTerminalID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxTerminalID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtBxTerminalID.Location = new System.Drawing.Point(16, 38);
            this.txtBxTerminalID.MaxLength = 80;
            this.txtBxTerminalID.Name = "txtBxTerminalID";
            this.txtBxTerminalID.Size = new System.Drawing.Size(402, 24);
            this.txtBxTerminalID.TabIndex = 214;
            // 
            // panelProfileID
            // 
            this.panelProfileID.Controls.Add(this.label273);
            this.panelProfileID.Controls.Add(this.label272);
            this.panelProfileID.Controls.Add(this.label271);
            this.panelProfileID.Controls.Add(this.metroComboBoxParam);
            this.panelProfileID.Controls.Add(this.label270);
            this.panelProfileID.Controls.Add(this.label268);
            this.panelProfileID.Controls.Add(this.textBoxVal);
            this.panelProfileID.Controls.Add(this.buttonProfileID);
            this.panelProfileID.Controls.Add(this.label266);
            this.panelProfileID.Controls.Add(this.textBoxProfileID);
            this.panelProfileID.Location = new System.Drawing.Point(2, 75);
            this.panelProfileID.Name = "panelProfileID";
            this.panelProfileID.Size = new System.Drawing.Size(847, 107);
            this.panelProfileID.TabIndex = 217;
            this.panelProfileID.Visible = false;
            // 
            // label273
            // 
            this.label273.AutoSize = true;
            this.label273.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label273.ForeColor = System.Drawing.Color.Red;
            this.label273.Location = new System.Drawing.Point(523, 9);
            this.label273.Name = "label273";
            this.label273.Size = new System.Drawing.Size(15, 18);
            this.label273.TabIndex = 218;
            this.label273.Text = "*";
            // 
            // label272
            // 
            this.label272.AutoSize = true;
            this.label272.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label272.ForeColor = System.Drawing.Color.Red;
            this.label272.Location = new System.Drawing.Point(246, 9);
            this.label272.Name = "label272";
            this.label272.Size = new System.Drawing.Size(15, 18);
            this.label272.TabIndex = 222;
            this.label272.Text = "*";
            // 
            // label271
            // 
            this.label271.AutoSize = true;
            this.label271.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label271.ForeColor = System.Drawing.Color.Red;
            this.label271.Location = new System.Drawing.Point(114, 9);
            this.label271.Name = "label271";
            this.label271.Size = new System.Drawing.Size(15, 18);
            this.label271.TabIndex = 221;
            this.label271.Text = "*";
            // 
            // metroComboBoxParam
            // 
            this.metroComboBoxParam.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.metroComboBoxParam.ForeColor = System.Drawing.SystemColors.WindowText;
            this.metroComboBoxParam.FormattingEnabled = true;
            this.metroComboBoxParam.ItemHeight = 23;
            this.metroComboBoxParam.Items.AddRange(new object[] {
            "AcquirerId",
            "FacilityCode",
            "FacilityName",
            "HeartBeatInterval",
            "HideCashTotal",
            "LogLevel",
            "NumberOfIncrements",
            "ParticipantId",
            "ParticipantName",
            "ParticipantShortName",
            "PrinterConfig",
            "ScreenTimeout",
            "TransactionUploadCount",
            "TransactionUploadInterval"});
            this.metroComboBoxParam.Location = new System.Drawing.Point(279, 36);
            this.metroComboBoxParam.Name = "metroComboBoxParam";
            this.metroComboBoxParam.Size = new System.Drawing.Size(272, 29);
            this.metroComboBoxParam.Sorted = true;
            this.metroComboBoxParam.TabIndex = 220;
            this.metroComboBoxParam.UseSelectable = true;
            this.metroComboBoxParam.UseStyleColors = true;
            // 
            // label270
            // 
            this.label270.AutoSize = true;
            this.label270.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label270.Location = new System.Drawing.Point(273, 9);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(62, 14);
            this.label270.TabIndex = 219;
            this.label270.Text = "Parameter:";
            // 
            // label268
            // 
            this.label268.AutoSize = true;
            this.label268.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label268.Location = new System.Drawing.Point(145, 9);
            this.label268.Name = "label268";
            this.label268.Size = new System.Drawing.Size(36, 14);
            this.label268.TabIndex = 218;
            this.label268.Text = "Value:";
            // 
            // textBoxVal
            // 
            this.textBoxVal.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxVal.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxVal.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxVal.Location = new System.Drawing.Point(150, 38);
            this.textBoxVal.MaxLength = 80;
            this.textBoxVal.Name = "textBoxVal";
            this.textBoxVal.Size = new System.Drawing.Size(124, 24);
            this.textBoxVal.TabIndex = 217;
            // 
            // buttonProfileID
            // 
            this.buttonProfileID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonProfileID.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.buttonProfileID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonProfileID.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonProfileID.FlatAppearance.BorderSize = 0;
            this.buttonProfileID.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonProfileID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProfileID.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProfileID.Location = new System.Drawing.Point(554, 36);
            this.buttonProfileID.Name = "buttonProfileID";
            this.buttonProfileID.Size = new System.Drawing.Size(24, 25);
            this.buttonProfileID.TabIndex = 216;
            this.buttonProfileID.UseVisualStyleBackColor = true;
            this.buttonProfileID.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label266
            // 
            this.label266.AutoSize = true;
            this.label266.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label266.Location = new System.Drawing.Point(11, 9);
            this.label266.Name = "label266";
            this.label266.Size = new System.Drawing.Size(56, 14);
            this.label266.TabIndex = 215;
            this.label266.Text = "Profile ID:";
            // 
            // textBoxProfileID
            // 
            this.textBoxProfileID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxProfileID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxProfileID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxProfileID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBoxProfileID.Location = new System.Drawing.Point(16, 38);
            this.textBoxProfileID.MaxLength = 80;
            this.textBoxProfileID.Name = "textBoxProfileID";
            this.textBoxProfileID.Size = new System.Drawing.Size(124, 24);
            this.textBoxProfileID.TabIndex = 214;
            // 
            // tb25
            // 
            this.tb25.Controls.Add(this.panel24);
            this.tb25.Location = new System.Drawing.Point(4, 34);
            this.tb25.Name = "tb25";
            this.tb25.Size = new System.Drawing.Size(862, 565);
            this.tb25.TabIndex = 24;
            this.tb25.Text = "Profile Discounts";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel24.Controls.Add(this.buttonexppd);
            this.panel24.Controls.Add(this.panelPD);
            this.panel24.Controls.Add(this.buttonSAVEPD);
            this.panel24.Controls.Add(this.buttonDELPD);
            this.panel24.Controls.Add(this.dgvPD);
            this.panel24.Controls.Add(this.label280);
            this.panel24.Controls.Add(this.label281);
            this.panel24.Controls.Add(this.mcbxFTID);
            this.panel24.Controls.Add(this.mcbxProfiles);
            this.panel24.Controls.Add(this.buttonGENPD);
            this.panel24.Controls.Add(this.label282);
            this.panel24.Controls.Add(this.label283);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(862, 565);
            this.panel24.TabIndex = 84;
            // 
            // buttonexppd
            // 
            this.buttonexppd.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonexppd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonexppd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonexppd.Location = new System.Drawing.Point(717, 206);
            this.buttonexppd.Name = "buttonexppd";
            this.buttonexppd.Size = new System.Drawing.Size(133, 45);
            this.buttonexppd.TabIndex = 150;
            this.buttonexppd.Text = "Export";
            this.buttonexppd.UseVisualStyleBackColor = false;
            this.buttonexppd.Click += new System.EventHandler(this.buttonexppd_Click);
            // 
            // panelPD
            // 
            this.panelPD.Controls.Add(this.label276);
            this.panelPD.Controls.Add(this.label277);
            this.panelPD.Controls.Add(this.mcbxFTID2);
            this.panelPD.Controls.Add(this.mcbxProfiles2);
            this.panelPD.Controls.Add(this.label278);
            this.panelPD.Controls.Add(this.label279);
            this.panelPD.Location = new System.Drawing.Point(19, 15);
            this.panelPD.Name = "panelPD";
            this.panelPD.Size = new System.Drawing.Size(696, 124);
            this.panelPD.TabIndex = 139;
            this.panelPD.Visible = false;
            // 
            // label276
            // 
            this.label276.AutoSize = true;
            this.label276.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label276.ForeColor = System.Drawing.Color.Red;
            this.label276.Location = new System.Drawing.Point(660, 63);
            this.label276.Name = "label276";
            this.label276.Size = new System.Drawing.Size(15, 18);
            this.label276.TabIndex = 141;
            this.label276.Text = "*";
            // 
            // label277
            // 
            this.label277.AutoSize = true;
            this.label277.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label277.ForeColor = System.Drawing.Color.Red;
            this.label277.Location = new System.Drawing.Point(660, 0);
            this.label277.Name = "label277";
            this.label277.Size = new System.Drawing.Size(15, 18);
            this.label277.TabIndex = 140;
            this.label277.Text = "*";
            // 
            // mcbxFTID2
            // 
            this.mcbxFTID2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxFTID2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxFTID2.FormattingEnabled = true;
            this.mcbxFTID2.ItemHeight = 23;
            this.mcbxFTID2.Location = new System.Drawing.Point(8, 90);
            this.mcbxFTID2.Name = "mcbxFTID2";
            this.mcbxFTID2.Size = new System.Drawing.Size(680, 29);
            this.mcbxFTID2.Sorted = true;
            this.mcbxFTID2.TabIndex = 139;
            this.mcbxFTID2.UseSelectable = true;
            this.mcbxFTID2.UseStyleColors = true;
            this.mcbxFTID2.SelectedIndexChanged += new System.EventHandler(this.mcbxFTID2_SelectedIndexChanged);
            // 
            // mcbxProfiles2
            // 
            this.mcbxProfiles2.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxProfiles2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxProfiles2.FormattingEnabled = true;
            this.mcbxProfiles2.ItemHeight = 23;
            this.mcbxProfiles2.Location = new System.Drawing.Point(8, 29);
            this.mcbxProfiles2.Name = "mcbxProfiles2";
            this.mcbxProfiles2.Size = new System.Drawing.Size(680, 29);
            this.mcbxProfiles2.Sorted = true;
            this.mcbxProfiles2.TabIndex = 138;
            this.mcbxProfiles2.UseSelectable = true;
            this.mcbxProfiles2.UseStyleColors = true;
            this.mcbxProfiles2.SelectedIndexChanged += new System.EventHandler(this.mcbxProfiles2_SelectedIndexChanged);
            // 
            // label278
            // 
            this.label278.AutoSize = true;
            this.label278.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label278.Location = new System.Drawing.Point(3, 61);
            this.label278.Name = "label278";
            this.label278.Size = new System.Drawing.Size(98, 14);
            this.label278.TabIndex = 137;
            this.label278.Text = "New FareTable ID:";
            // 
            // label279
            // 
            this.label279.AutoSize = true;
            this.label279.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label279.Location = new System.Drawing.Point(3, 0);
            this.label279.Name = "label279";
            this.label279.Size = new System.Drawing.Size(101, 14);
            this.label279.TabIndex = 136;
            this.label279.Text = "New Profile Name:";
            // 
            // buttonSAVEPD
            // 
            this.buttonSAVEPD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonSAVEPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSAVEPD.Location = new System.Drawing.Point(550, 145);
            this.buttonSAVEPD.Name = "buttonSAVEPD";
            this.buttonSAVEPD.Size = new System.Drawing.Size(133, 45);
            this.buttonSAVEPD.TabIndex = 149;
            this.buttonSAVEPD.Text = "Save";
            this.buttonSAVEPD.UseVisualStyleBackColor = true;
            this.buttonSAVEPD.Visible = false;
            this.buttonSAVEPD.Click += new System.EventHandler(this.buttonSAVEPD_Click);
            // 
            // buttonDELPD
            // 
            this.buttonDELPD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonDELPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDELPD.Location = new System.Drawing.Point(1, 208);
            this.buttonDELPD.Name = "buttonDELPD";
            this.buttonDELPD.Size = new System.Drawing.Size(111, 41);
            this.buttonDELPD.TabIndex = 148;
            this.buttonDELPD.Text = "Delete";
            this.buttonDELPD.UseVisualStyleBackColor = true;
            this.buttonDELPD.Visible = false;
            this.buttonDELPD.Click += new System.EventHandler(this.buttonDELPD_Click);
            // 
            // dgvPD
            // 
            this.dgvPD.AllowUserToAddRows = false;
            this.dgvPD.AllowUserToResizeRows = false;
            this.dgvPD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPD.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPD.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPD.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle910.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle910.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle910.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle910.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle910.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle910.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle910.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle910;
            this.dgvPD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle911.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle911.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle911.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle911.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle911.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle911.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle911.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPD.DefaultCellStyle = dataGridViewCellStyle911;
            this.dgvPD.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPD.EnableHeadersVisualStyles = false;
            this.dgvPD.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPD.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPD.Location = new System.Drawing.Point(0, 241);
            this.dgvPD.MultiSelect = false;
            this.dgvPD.Name = "dgvPD";
            this.dgvPD.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle912.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle912.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle912.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle912.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle912.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle912.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle912.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPD.RowHeadersDefaultCellStyle = dataGridViewCellStyle912;
            this.dgvPD.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPD.RowTemplate.Height = 33;
            this.dgvPD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPD.Size = new System.Drawing.Size(862, 324);
            this.dgvPD.TabIndex = 147;
            this.dgvPD.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPD_CellContentDoubleClick);
            // 
            // label280
            // 
            this.label280.AutoSize = true;
            this.label280.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label280.ForeColor = System.Drawing.Color.Red;
            this.label280.Location = new System.Drawing.Point(679, 78);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(15, 18);
            this.label280.TabIndex = 146;
            this.label280.Text = "*";
            // 
            // label281
            // 
            this.label281.AutoSize = true;
            this.label281.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label281.ForeColor = System.Drawing.Color.Red;
            this.label281.Location = new System.Drawing.Point(679, 15);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(15, 18);
            this.label281.TabIndex = 145;
            this.label281.Text = "*";
            // 
            // mcbxFTID
            // 
            this.mcbxFTID.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxFTID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxFTID.FormattingEnabled = true;
            this.mcbxFTID.ItemHeight = 23;
            this.mcbxFTID.Location = new System.Drawing.Point(27, 105);
            this.mcbxFTID.Name = "mcbxFTID";
            this.mcbxFTID.Size = new System.Drawing.Size(680, 29);
            this.mcbxFTID.Sorted = true;
            this.mcbxFTID.TabIndex = 144;
            this.mcbxFTID.UseSelectable = true;
            this.mcbxFTID.UseStyleColors = true;
            this.mcbxFTID.SelectedIndexChanged += new System.EventHandler(this.mcbxFTID_SelectedIndexChanged);
            // 
            // mcbxProfiles
            // 
            this.mcbxProfiles.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.mcbxProfiles.ForeColor = System.Drawing.SystemColors.WindowText;
            this.mcbxProfiles.FormattingEnabled = true;
            this.mcbxProfiles.ItemHeight = 23;
            this.mcbxProfiles.Location = new System.Drawing.Point(27, 44);
            this.mcbxProfiles.Name = "mcbxProfiles";
            this.mcbxProfiles.Size = new System.Drawing.Size(680, 29);
            this.mcbxProfiles.Sorted = true;
            this.mcbxProfiles.TabIndex = 143;
            this.mcbxProfiles.UseSelectable = true;
            this.mcbxProfiles.UseStyleColors = true;
            this.mcbxProfiles.SelectedIndexChanged += new System.EventHandler(this.mcbxProfiles_SelectedIndexChanged);
            // 
            // buttonGENPD
            // 
            this.buttonGENPD.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonGENPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGENPD.Location = new System.Drawing.Point(689, 145);
            this.buttonGENPD.Name = "buttonGENPD";
            this.buttonGENPD.Size = new System.Drawing.Size(161, 45);
            this.buttonGENPD.TabIndex = 142;
            this.buttonGENPD.Text = "Generate";
            this.buttonGENPD.UseVisualStyleBackColor = true;
            this.buttonGENPD.Click += new System.EventHandler(this.buttonGENPD_Click);
            // 
            // label282
            // 
            this.label282.AutoSize = true;
            this.label282.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label282.Location = new System.Drawing.Point(22, 76);
            this.label282.Name = "label282";
            this.label282.Size = new System.Drawing.Size(72, 14);
            this.label282.TabIndex = 141;
            this.label282.Text = "FareTable ID:";
            // 
            // label283
            // 
            this.label283.AutoSize = true;
            this.label283.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label283.Location = new System.Drawing.Point(22, 15);
            this.label283.Name = "label283";
            this.label283.Size = new System.Drawing.Size(75, 14);
            this.label283.TabIndex = 140;
            this.label283.Text = "Profile Name:";
            // 
            // tb26
            // 
            this.tb26.Controls.Add(this.panel25);
            this.tb26.Location = new System.Drawing.Point(4, 34);
            this.tb26.Name = "tb26";
            this.tb26.Size = new System.Drawing.Size(862, 565);
            this.tb26.TabIndex = 27;
            this.tb26.Text = "Config Checker";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.Window;
            this.panel25.Controls.Add(this.efx);
            this.panel25.Controls.Add(this.buttonPauseResume);
            this.panel25.Controls.Add(this.pb);
            this.panel25.Controls.Add(this.labelCHECK);
            this.panel25.Controls.Add(this.startInitial);
            this.panel25.Controls.Add(this.comboCHECK);
            this.panel25.Controls.Add(this.label284);
            this.panel25.Controls.Add(this.dgvCC);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(862, 565);
            this.panel25.TabIndex = 84;
            // 
            // efx
            // 
            this.efx.AutoSize = true;
            this.efx.Font = new System.Drawing.Font("Google Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.efx.Location = new System.Drawing.Point(11, 79);
            this.efx.Name = "efx";
            this.efx.Size = new System.Drawing.Size(169, 20);
            this.efx.TabIndex = 221;
            this.efx.Text = "Cheking Parameters...";
            this.efx.Visible = false;
            // 
            // buttonPauseResume
            // 
            this.buttonPauseResume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPauseResume.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.pause;
            this.buttonPauseResume.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPauseResume.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPauseResume.FlatAppearance.BorderSize = 0;
            this.buttonPauseResume.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonPauseResume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPauseResume.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPauseResume.Location = new System.Drawing.Point(14, 216);
            this.buttonPauseResume.Name = "buttonPauseResume";
            this.buttonPauseResume.Size = new System.Drawing.Size(24, 25);
            this.buttonPauseResume.TabIndex = 220;
            this.buttonPauseResume.UseVisualStyleBackColor = true;
            this.buttonPauseResume.Visible = false;
            this.buttonPauseResume.Click += new System.EventHandler(this.buttonPauseResume_Click);
            // 
            // pb
            // 
            this.pb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb.Image = global::AFPI_Beejees_db.Properties.Resources.giphy;
            this.pb.Location = new System.Drawing.Point(178, 73);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(31, 30);
            this.pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb.TabIndex = 219;
            this.pb.TabStop = false;
            this.pb.Visible = false;
            // 
            // labelCHECK
            // 
            this.labelCHECK.AutoSize = true;
            this.labelCHECK.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCHECK.Location = new System.Drawing.Point(11, 102);
            this.labelCHECK.Name = "labelCHECK";
            this.labelCHECK.Size = new System.Drawing.Size(0, 14);
            this.labelCHECK.TabIndex = 218;
            // 
            // startInitial
            // 
            this.startInitial.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.startInitial.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.RUN1;
            this.startInitial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.startInitial.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.startInitial.FlatAppearance.BorderSize = 0;
            this.startInitial.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.startInitial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.startInitial.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startInitial.Location = new System.Drawing.Point(380, 31);
            this.startInitial.Name = "startInitial";
            this.startInitial.Size = new System.Drawing.Size(24, 25);
            this.startInitial.TabIndex = 217;
            this.startInitial.UseVisualStyleBackColor = true;
            this.startInitial.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // comboCHECK
            // 
            this.comboCHECK.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.comboCHECK.ForeColor = System.Drawing.SystemColors.WindowText;
            this.comboCHECK.FormattingEnabled = true;
            this.comboCHECK.ItemHeight = 23;
            this.comboCHECK.Location = new System.Drawing.Point(14, 43);
            this.comboCHECK.Name = "comboCHECK";
            this.comboCHECK.Size = new System.Drawing.Size(360, 29);
            this.comboCHECK.Sorted = true;
            this.comboCHECK.TabIndex = 150;
            this.comboCHECK.UseSelectable = true;
            this.comboCHECK.UseStyleColors = true;
            // 
            // label284
            // 
            this.label284.AutoSize = true;
            this.label284.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label284.Location = new System.Drawing.Point(11, 26);
            this.label284.Name = "label284";
            this.label284.Size = new System.Drawing.Size(86, 14);
            this.label284.TabIndex = 149;
            this.label284.Text = "Select Route ID:";
            // 
            // dgvCC
            // 
            this.dgvCC.AllowUserToAddRows = false;
            this.dgvCC.AllowUserToResizeRows = false;
            this.dgvCC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvCC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvCC.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvCC.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle913.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle913.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle913.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle913.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle913.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle913.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle913.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle913;
            this.dgvCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle914.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle914.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle914.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle914.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle914.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle914.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle914.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCC.DefaultCellStyle = dataGridViewCellStyle914;
            this.dgvCC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvCC.EnableHeadersVisualStyles = false;
            this.dgvCC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvCC.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvCC.Location = new System.Drawing.Point(0, 232);
            this.dgvCC.MultiSelect = false;
            this.dgvCC.Name = "dgvCC";
            this.dgvCC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle915.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle915.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle915.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle915.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle915.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle915.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle915.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCC.RowHeadersDefaultCellStyle = dataGridViewCellStyle915;
            this.dgvCC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvCC.RowTemplate.Height = 33;
            this.dgvCC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCC.Size = new System.Drawing.Size(862, 333);
            this.dgvCC.TabIndex = 148;
            this.dgvCC.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCC_CellClick);
            // 
            // tb27
            // 
            this.tb27.Controls.Add(this.panel26);
            this.tb27.Location = new System.Drawing.Point(4, 34);
            this.tb27.Name = "tb27";
            this.tb27.Size = new System.Drawing.Size(862, 565);
            this.tb27.TabIndex = 28;
            this.tb27.Text = "Move Route";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel26.Controls.Add(this.buttonMove);
            this.panel26.Controls.Add(this.moveTo);
            this.panel26.Controls.Add(this.label26);
            this.panel26.Controls.Add(this.selRoute);
            this.panel26.Controls.Add(this.label25);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(862, 565);
            this.panel26.TabIndex = 220;
            // 
            // buttonMove
            // 
            this.buttonMove.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonMove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMove.Location = new System.Drawing.Point(12, 119);
            this.buttonMove.Name = "buttonMove";
            this.buttonMove.Size = new System.Drawing.Size(133, 45);
            this.buttonMove.TabIndex = 212;
            this.buttonMove.Text = "Move";
            this.buttonMove.UseVisualStyleBackColor = true;
            this.buttonMove.Click += new System.EventHandler(this.buttonMove_Click);
            // 
            // moveTo
            // 
            this.moveTo.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.moveTo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.moveTo.FormattingEnabled = true;
            this.moveTo.ItemHeight = 23;
            this.moveTo.Location = new System.Drawing.Point(12, 80);
            this.moveTo.Name = "moveTo";
            this.moveTo.Size = new System.Drawing.Size(488, 29);
            this.moveTo.Sorted = true;
            this.moveTo.TabIndex = 154;
            this.moveTo.UseSelectable = true;
            this.moveTo.UseStyleColors = true;
            this.moveTo.SelectedIndexChanged += new System.EventHandler(this.moveTo_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(9, 63);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(101, 14);
            this.label26.TabIndex = 153;
            this.label26.Text = "Destination Profile:";
            // 
            // selRoute
            // 
            this.selRoute.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.selRoute.ForeColor = System.Drawing.SystemColors.WindowText;
            this.selRoute.FormattingEnabled = true;
            this.selRoute.ItemHeight = 23;
            this.selRoute.Location = new System.Drawing.Point(12, 31);
            this.selRoute.Name = "selRoute";
            this.selRoute.Size = new System.Drawing.Size(488, 29);
            this.selRoute.Sorted = true;
            this.selRoute.TabIndex = 152;
            this.selRoute.UseSelectable = true;
            this.selRoute.UseStyleColors = true;
            this.selRoute.SelectedIndexChanged += new System.EventHandler(this.selRoute_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(9, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 14);
            this.label25.TabIndex = 151;
            this.label25.Text = "Select Route:";
            // 
            // tb28
            // 
            this.tb28.Controls.Add(this.panel27);
            this.tb28.Location = new System.Drawing.Point(4, 34);
            this.tb28.Name = "tb28";
            this.tb28.Size = new System.Drawing.Size(862, 565);
            this.tb28.TabIndex = 29;
            this.tb28.Text = "Print Template";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel27.Controls.Add(this.label123);
            this.panel27.Controls.Add(this.PTTN);
            this.panel27.Controls.Add(this.PTT);
            this.panel27.Controls.Add(this.label291);
            this.panel27.Controls.Add(this.label289);
            this.panel27.Controls.Add(this.label290);
            this.panel27.Controls.Add(this.PTDT2);
            this.panel27.Controls.Add(this.PTDT);
            this.panel27.Controls.Add(this.PTExp);
            this.panel27.Controls.Add(this.PTDel);
            this.panel27.Controls.Add(this.dgvPT);
            this.panel27.Controls.Add(this.PTSave);
            this.panel27.Controls.Add(this.PTAdd);
            this.panel27.Controls.Add(this.label93);
            this.panel27.Controls.Add(this.PTTID);
            this.panel27.Controls.Add(this.PTTT);
            this.panel27.Controls.Add(this.label288);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(862, 565);
            this.panel27.TabIndex = 220;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(111, 59);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(89, 14);
            this.label123.TabIndex = 242;
            this.label123.Text = "Template Name:";
            // 
            // PTTN
            // 
            this.PTTN.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PTTN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PTTN.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTTN.ForeColor = System.Drawing.SystemColors.InfoText;
            this.PTTN.Location = new System.Drawing.Point(114, 76);
            this.PTTN.MaxLength = 10;
            this.PTTN.Name = "PTTN";
            this.PTTN.Size = new System.Drawing.Size(260, 24);
            this.PTTN.TabIndex = 241;
            // 
            // PTT
            // 
            this.PTT.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PTT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PTT.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTT.ForeColor = System.Drawing.SystemColors.InfoText;
            this.PTT.Location = new System.Drawing.Point(14, 122);
            this.PTT.MaxLength = 1234567;
            this.PTT.Multiline = true;
            this.PTT.Name = "PTT";
            this.PTT.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.PTT.Size = new System.Drawing.Size(819, 191);
            this.PTT.TabIndex = 240;
            // 
            // label291
            // 
            this.label291.AutoSize = true;
            this.label291.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label291.Location = new System.Drawing.Point(11, 105);
            this.label291.Name = "label291";
            this.label291.Size = new System.Drawing.Size(56, 14);
            this.label291.TabIndex = 239;
            this.label291.Text = "Template:";
            // 
            // label289
            // 
            this.label289.AutoSize = true;
            this.label289.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label289.Location = new System.Drawing.Point(583, 36);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(18, 14);
            this.label289.TabIndex = 238;
            this.label289.Text = "to";
            // 
            // label290
            // 
            this.label290.AutoSize = true;
            this.label290.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label290.Location = new System.Drawing.Point(377, 10);
            this.label290.Name = "label290";
            this.label290.Size = new System.Drawing.Size(78, 14);
            this.label290.TabIndex = 236;
            this.label290.Text = "Effective Date";
            // 
            // PTDT2
            // 
            this.PTDT2.Location = new System.Drawing.Point(601, 27);
            this.PTDT2.MinimumSize = new System.Drawing.Size(0, 29);
            this.PTDT2.Name = "PTDT2";
            this.PTDT2.Size = new System.Drawing.Size(200, 29);
            this.PTDT2.TabIndex = 237;
            // 
            // PTDT
            // 
            this.PTDT.Location = new System.Drawing.Point(380, 27);
            this.PTDT.MinimumSize = new System.Drawing.Size(0, 29);
            this.PTDT.Name = "PTDT";
            this.PTDT.Size = new System.Drawing.Size(200, 29);
            this.PTDT.TabIndex = 235;
            this.PTDT.ValueChanged += new System.EventHandler(this.PTDT_ValueChanged);
            // 
            // PTExp
            // 
            this.PTExp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PTExp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.PTExp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PTExp.Location = new System.Drawing.Point(700, 380);
            this.PTExp.Name = "PTExp";
            this.PTExp.Size = new System.Drawing.Size(133, 45);
            this.PTExp.TabIndex = 233;
            this.PTExp.Text = "Export";
            this.PTExp.UseVisualStyleBackColor = false;
            this.PTExp.Click += new System.EventHandler(this.PTExp_Click);
            // 
            // PTDel
            // 
            this.PTDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PTDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PTDel.Location = new System.Drawing.Point(3, 384);
            this.PTDel.Name = "PTDel";
            this.PTDel.Size = new System.Drawing.Size(111, 41);
            this.PTDel.TabIndex = 232;
            this.PTDel.Text = "Delete";
            this.PTDel.UseVisualStyleBackColor = true;
            this.PTDel.Visible = false;
            this.PTDel.Click += new System.EventHandler(this.PTDel_Click);
            // 
            // dgvPT
            // 
            this.dgvPT.AllowUserToAddRows = false;
            this.dgvPT.AllowUserToResizeRows = false;
            this.dgvPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle916.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle916.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle916.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle916.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle916.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle916.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle916.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle916;
            this.dgvPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle917.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle917.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle917.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle917.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle917.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle917.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle917.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPT.DefaultCellStyle = dataGridViewCellStyle917;
            this.dgvPT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPT.EnableHeadersVisualStyles = false;
            this.dgvPT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPT.Location = new System.Drawing.Point(0, 413);
            this.dgvPT.MultiSelect = false;
            this.dgvPT.Name = "dgvPT";
            this.dgvPT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle918.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle918.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle918.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle918.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle918.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle918.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle918.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPT.RowHeadersDefaultCellStyle = dataGridViewCellStyle918;
            this.dgvPT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPT.RowTemplate.Height = 33;
            this.dgvPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPT.Size = new System.Drawing.Size(862, 152);
            this.dgvPT.TabIndex = 231;
            this.dgvPT.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPT_CellContentDoubleClick);
            // 
            // PTSave
            // 
            this.PTSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PTSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PTSave.Location = new System.Drawing.Point(533, 319);
            this.PTSave.Name = "PTSave";
            this.PTSave.Size = new System.Drawing.Size(133, 45);
            this.PTSave.TabIndex = 230;
            this.PTSave.Text = "Save";
            this.PTSave.UseVisualStyleBackColor = true;
            this.PTSave.Visible = false;
            this.PTSave.Click += new System.EventHandler(this.PTSave_Click);
            // 
            // PTAdd
            // 
            this.PTAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PTAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PTAdd.Location = new System.Drawing.Point(672, 319);
            this.PTAdd.Name = "PTAdd";
            this.PTAdd.Size = new System.Drawing.Size(161, 45);
            this.PTAdd.TabIndex = 229;
            this.PTAdd.Text = "Add";
            this.PTAdd.UseVisualStyleBackColor = true;
            this.PTAdd.Click += new System.EventHandler(this.PTAdd_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(11, 59);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(70, 14);
            this.label93.TabIndex = 228;
            this.label93.Text = "Template ID:";
            // 
            // PTTID
            // 
            this.PTTID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PTTID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PTTID.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTTID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.PTTID.Location = new System.Drawing.Point(14, 76);
            this.PTTID.MaxLength = 10;
            this.PTTID.Name = "PTTID";
            this.PTTID.Size = new System.Drawing.Size(91, 24);
            this.PTTID.TabIndex = 227;
            this.PTTID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // PTTT
            // 
            this.PTTT.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.PTTT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PTTT.FormattingEnabled = true;
            this.PTTT.ItemHeight = 23;
            this.PTTT.Items.AddRange(new object[] {
            "CASHBOX_REMOVAL_REPORT",
            "END_OF_SHIFT_REPORT",
            "ROUTE_CHANGE_REPORT",
            "START_OF_SHIFT_REPORT",
            "TICKET"});
            this.PTTT.Location = new System.Drawing.Point(14, 27);
            this.PTTT.Name = "PTTT";
            this.PTTT.Size = new System.Drawing.Size(360, 29);
            this.PTTT.Sorted = true;
            this.PTTT.TabIndex = 224;
            this.PTTT.UseSelectable = true;
            this.PTTT.UseStyleColors = true;
            this.PTTT.SelectedIndexChanged += new System.EventHandler(this.PTTT_SelectedIndexChanged);
            // 
            // label288
            // 
            this.label288.AutoSize = true;
            this.label288.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label288.Location = new System.Drawing.Point(9, 10);
            this.label288.Name = "label288";
            this.label288.Size = new System.Drawing.Size(86, 14);
            this.label288.TabIndex = 223;
            this.label288.Text = " Template Type:";
            // 
            // tb29
            // 
            this.tb29.Controls.Add(this.panel28);
            this.tb29.Location = new System.Drawing.Point(4, 34);
            this.tb29.Name = "tb29";
            this.tb29.Size = new System.Drawing.Size(862, 565);
            this.tb29.TabIndex = 30;
            this.tb29.Text = "Print Profile";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel28.Controls.Add(this.labelTT);
            this.panel28.Controls.Add(this.labelList);
            this.panel28.Controls.Add(this.labelList3);
            this.panel28.Controls.Add(this.buttonPPE);
            this.panel28.Controls.Add(this.buttonPPDEL);
            this.panel28.Controls.Add(this.dgvPPT);
            this.panel28.Controls.Add(this.PPsave);
            this.panel28.Controls.Add(this.PPadd);
            this.panel28.Controls.Add(this.label287);
            this.panel28.Controls.Add(this.PPVERtxt);
            this.panel28.Controls.Add(this.PPTIDcbx);
            this.panel28.Controls.Add(this.label286);
            this.panel28.Controls.Add(this.PPPcbx);
            this.panel28.Controls.Add(this.label285);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(862, 565);
            this.panel28.TabIndex = 220;
            // 
            // labelTT
            // 
            this.labelTT.AutoSize = true;
            this.labelTT.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTT.Location = new System.Drawing.Point(546, 66);
            this.labelTT.Name = "labelTT";
            this.labelTT.Size = new System.Drawing.Size(82, 14);
            this.labelTT.TabIndex = 225;
            this.labelTT.Text = "Template type:";
            // 
            // labelList
            // 
            this.labelList.AutoSize = true;
            this.labelList.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelList.Location = new System.Drawing.Point(11, 121);
            this.labelList.Name = "labelList";
            this.labelList.Size = new System.Drawing.Size(0, 14);
            this.labelList.TabIndex = 224;
            // 
            // labelList3
            // 
            this.labelList3.AutoSize = true;
            this.labelList3.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelList3.Location = new System.Drawing.Point(11, 107);
            this.labelList3.Name = "labelList3";
            this.labelList3.Size = new System.Drawing.Size(133, 14);
            this.labelList3.TabIndex = 223;
            this.labelList3.Text = "Template types in Profile:";
            // 
            // buttonPPE
            // 
            this.buttonPPE.BackColor = System.Drawing.SystemColors.HighlightText;
            this.buttonPPE.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonPPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPPE.Location = new System.Drawing.Point(729, 207);
            this.buttonPPE.Name = "buttonPPE";
            this.buttonPPE.Size = new System.Drawing.Size(133, 45);
            this.buttonPPE.TabIndex = 222;
            this.buttonPPE.Text = "Export";
            this.buttonPPE.UseVisualStyleBackColor = false;
            this.buttonPPE.Click += new System.EventHandler(this.buttonPPE_Click);
            // 
            // buttonPPDEL
            // 
            this.buttonPPDEL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonPPDEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPPDEL.Location = new System.Drawing.Point(0, 209);
            this.buttonPPDEL.Name = "buttonPPDEL";
            this.buttonPPDEL.Size = new System.Drawing.Size(111, 41);
            this.buttonPPDEL.TabIndex = 221;
            this.buttonPPDEL.Text = "Delete";
            this.buttonPPDEL.UseVisualStyleBackColor = true;
            this.buttonPPDEL.Visible = false;
            this.buttonPPDEL.Click += new System.EventHandler(this.buttonPPDEL_Click);
            // 
            // dgvPPT
            // 
            this.dgvPPT.AllowUserToAddRows = false;
            this.dgvPPT.AllowUserToResizeRows = false;
            this.dgvPPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPPT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPPT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPPT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPPT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle919.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle919.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle919.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle919.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle919.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle919.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle919.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPPT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle919;
            this.dgvPPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle920.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle920.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle920.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle920.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle920.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle920.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle920.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPPT.DefaultCellStyle = dataGridViewCellStyle920;
            this.dgvPPT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPPT.EnableHeadersVisualStyles = false;
            this.dgvPPT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPPT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPPT.Location = new System.Drawing.Point(0, 237);
            this.dgvPPT.MultiSelect = false;
            this.dgvPPT.Name = "dgvPPT";
            this.dgvPPT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle921.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle921.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle921.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle921.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle921.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle921.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle921.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPPT.RowHeadersDefaultCellStyle = dataGridViewCellStyle921;
            this.dgvPPT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPPT.RowTemplate.Height = 33;
            this.dgvPPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPPT.Size = new System.Drawing.Size(862, 328);
            this.dgvPPT.TabIndex = 220;
            this.dgvPPT.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPPT_CellContentDoubleClick);
            // 
            // PPsave
            // 
            this.PPsave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PPsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PPsave.Location = new System.Drawing.Point(549, 90);
            this.PPsave.Name = "PPsave";
            this.PPsave.Size = new System.Drawing.Size(133, 45);
            this.PPsave.TabIndex = 219;
            this.PPsave.Text = "Save";
            this.PPsave.UseVisualStyleBackColor = true;
            this.PPsave.Visible = false;
            this.PPsave.Click += new System.EventHandler(this.PPsave_Click);
            // 
            // PPadd
            // 
            this.PPadd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PPadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PPadd.Location = new System.Drawing.Point(688, 90);
            this.PPadd.Name = "PPadd";
            this.PPadd.Size = new System.Drawing.Size(161, 45);
            this.PPadd.TabIndex = 218;
            this.PPadd.Text = "Add";
            this.PPadd.UseVisualStyleBackColor = true;
            this.PPadd.Click += new System.EventHandler(this.PPadd_Click);
            // 
            // label287
            // 
            this.label287.AutoSize = true;
            this.label287.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label287.Location = new System.Drawing.Point(11, 63);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(46, 14);
            this.label287.TabIndex = 217;
            this.label287.Text = "Version:";
            // 
            // PPVERtxt
            // 
            this.PPVERtxt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PPVERtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PPVERtxt.Enabled = false;
            this.PPVERtxt.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PPVERtxt.ForeColor = System.Drawing.SystemColors.InfoText;
            this.PPVERtxt.Location = new System.Drawing.Point(12, 80);
            this.PPVERtxt.MaxLength = 10;
            this.PPVERtxt.Name = "PPVERtxt";
            this.PPVERtxt.Size = new System.Drawing.Size(91, 24);
            this.PPVERtxt.TabIndex = 216;
            this.PPVERtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // PPTIDcbx
            // 
            this.PPTIDcbx.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.PPTIDcbx.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PPTIDcbx.FormattingEnabled = true;
            this.PPTIDcbx.ItemHeight = 23;
            this.PPTIDcbx.Location = new System.Drawing.Point(549, 31);
            this.PPTIDcbx.Name = "PPTIDcbx";
            this.PPTIDcbx.Size = new System.Drawing.Size(300, 29);
            this.PPTIDcbx.Sorted = true;
            this.PPTIDcbx.TabIndex = 154;
            this.PPTIDcbx.UseSelectable = true;
            this.PPTIDcbx.UseStyleColors = true;
            this.PPTIDcbx.SelectedIndexChanged += new System.EventHandler(this.PPTIDcbx_SelectedIndexChanged);
            // 
            // label286
            // 
            this.label286.AutoSize = true;
            this.label286.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label286.Location = new System.Drawing.Point(546, 14);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(89, 14);
            this.label286.TabIndex = 153;
            this.label286.Text = "Template Name:";
            // 
            // PPPcbx
            // 
            this.PPPcbx.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.PPPcbx.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PPPcbx.FormattingEnabled = true;
            this.PPPcbx.ItemHeight = 23;
            this.PPPcbx.Location = new System.Drawing.Point(12, 31);
            this.PPPcbx.Name = "PPPcbx";
            this.PPPcbx.Size = new System.Drawing.Size(531, 29);
            this.PPPcbx.Sorted = true;
            this.PPPcbx.TabIndex = 152;
            this.PPPcbx.UseSelectable = true;
            this.PPPcbx.UseStyleColors = true;
            this.PPPcbx.SelectedIndexChanged += new System.EventHandler(this.PPPcbx_SelectedIndexChanged);
            // 
            // label285
            // 
            this.label285.AutoSize = true;
            this.label285.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label285.Location = new System.Drawing.Point(9, 14);
            this.label285.Name = "label285";
            this.label285.Size = new System.Drawing.Size(75, 14);
            this.label285.TabIndex = 151;
            this.label285.Text = "Profile Name:";
            // 
            // tb30
            // 
            this.tb30.Controls.Add(this.panel29);
            this.tb30.Location = new System.Drawing.Point(4, 34);
            this.tb30.Name = "tb30";
            this.tb30.Size = new System.Drawing.Size(862, 565);
            this.tb30.TabIndex = 31;
            this.tb30.Text = "StopBasedFareTables";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel29.Controls.Add(this.SBFTexp);
            this.panel29.Controls.Add(this.SBFTDel);
            this.panel29.Controls.Add(this.dgvSBFT);
            this.panel29.Controls.Add(this.SBFTSave);
            this.panel29.Controls.Add(this.SBFTAdd);
            this.panel29.Controls.Add(this.SBFT_Pro);
            this.panel29.Controls.Add(this.SBFT_Acc);
            this.panel29.Controls.Add(this.label292);
            this.panel29.Controls.Add(this.SBFT_ET);
            this.panel29.Controls.Add(this.label293);
            this.panel29.Controls.Add(this.SBFT_EF);
            this.panel29.Controls.Add(this.SBFT_Act);
            this.panel29.Controls.Add(this.label294);
            this.panel29.Controls.Add(this.label295);
            this.panel29.Controls.Add(this.SBFT_Ftid);
            this.panel29.Controls.Add(this.SBFT_Fm);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(862, 565);
            this.panel29.TabIndex = 220;
            // 
            // SBFTexp
            // 
            this.SBFTexp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.SBFTexp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.SBFTexp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SBFTexp.Location = new System.Drawing.Point(726, 289);
            this.SBFTexp.Name = "SBFTexp";
            this.SBFTexp.Size = new System.Drawing.Size(133, 45);
            this.SBFTexp.TabIndex = 227;
            this.SBFTexp.Text = "Export";
            this.SBFTexp.UseVisualStyleBackColor = false;
            this.SBFTexp.Click += new System.EventHandler(this.SBFTexp_Click);
            // 
            // SBFTDel
            // 
            this.SBFTDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.SBFTDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SBFTDel.Location = new System.Drawing.Point(0, 291);
            this.SBFTDel.Name = "SBFTDel";
            this.SBFTDel.Size = new System.Drawing.Size(111, 41);
            this.SBFTDel.TabIndex = 226;
            this.SBFTDel.Text = "Delete";
            this.SBFTDel.UseVisualStyleBackColor = true;
            this.SBFTDel.Visible = false;
            this.SBFTDel.Click += new System.EventHandler(this.SBFTDel_Click);
            // 
            // dgvSBFT
            // 
            this.dgvSBFT.AllowUserToAddRows = false;
            this.dgvSBFT.AllowUserToResizeRows = false;
            this.dgvSBFT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSBFT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSBFT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSBFT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvSBFT.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle922.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle922.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle922.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle922.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle922.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle922.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle922.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSBFT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle922;
            this.dgvSBFT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle923.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle923.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle923.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle923.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle923.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle923.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle923.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSBFT.DefaultCellStyle = dataGridViewCellStyle923;
            this.dgvSBFT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvSBFT.EnableHeadersVisualStyles = false;
            this.dgvSBFT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvSBFT.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvSBFT.Location = new System.Drawing.Point(0, 319);
            this.dgvSBFT.MultiSelect = false;
            this.dgvSBFT.Name = "dgvSBFT";
            this.dgvSBFT.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle924.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle924.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle924.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle924.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle924.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle924.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle924.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSBFT.RowHeadersDefaultCellStyle = dataGridViewCellStyle924;
            this.dgvSBFT.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSBFT.RowTemplate.Height = 33;
            this.dgvSBFT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSBFT.Size = new System.Drawing.Size(862, 246);
            this.dgvSBFT.TabIndex = 225;
            this.dgvSBFT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSBFT_CellDoubleClick);
            // 
            // SBFTSave
            // 
            this.SBFTSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SBFTSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SBFTSave.Location = new System.Drawing.Point(419, 160);
            this.SBFTSave.Name = "SBFTSave";
            this.SBFTSave.Size = new System.Drawing.Size(133, 45);
            this.SBFTSave.TabIndex = 224;
            this.SBFTSave.Text = "Save";
            this.SBFTSave.UseVisualStyleBackColor = true;
            this.SBFTSave.Visible = false;
            this.SBFTSave.Click += new System.EventHandler(this.SBFTSave_Click);
            // 
            // SBFTAdd
            // 
            this.SBFTAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SBFTAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SBFTAdd.Location = new System.Drawing.Point(558, 160);
            this.SBFTAdd.Name = "SBFTAdd";
            this.SBFTAdd.Size = new System.Drawing.Size(133, 45);
            this.SBFTAdd.TabIndex = 223;
            this.SBFTAdd.Text = "Add";
            this.SBFTAdd.UseVisualStyleBackColor = true;
            this.SBFTAdd.Click += new System.EventHandler(this.SBFTAdd_Click);
            // 
            // SBFT_Pro
            // 
            this.SBFT_Pro.AutoSize = true;
            this.SBFT_Pro.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SBFT_Pro.Location = new System.Drawing.Point(621, 110);
            this.SBFT_Pro.Name = "SBFT_Pro";
            this.SBFT_Pro.Size = new System.Drawing.Size(70, 18);
            this.SBFT_Pro.TabIndex = 149;
            this.SBFT_Pro.Text = "Prorated";
            this.SBFT_Pro.UseVisualStyleBackColor = true;
            // 
            // SBFT_Acc
            // 
            this.SBFT_Acc.AutoSize = true;
            this.SBFT_Acc.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SBFT_Acc.Location = new System.Drawing.Point(523, 110);
            this.SBFT_Acc.Name = "SBFT_Acc";
            this.SBFT_Acc.Size = new System.Drawing.Size(93, 18);
            this.SBFT_Acc.TabIndex = 148;
            this.SBFT_Acc.Text = "Accumulative";
            this.SBFT_Acc.UseVisualStyleBackColor = true;
            // 
            // label292
            // 
            this.label292.AutoSize = true;
            this.label292.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label292.Location = new System.Drawing.Point(470, 52);
            this.label292.Name = "label292";
            this.label292.Size = new System.Drawing.Size(18, 14);
            this.label292.TabIndex = 147;
            this.label292.Text = "to";
            // 
            // SBFT_ET
            // 
            this.SBFT_ET.Location = new System.Drawing.Point(488, 43);
            this.SBFT_ET.MinimumSize = new System.Drawing.Size(0, 29);
            this.SBFT_ET.Name = "SBFT_ET";
            this.SBFT_ET.Size = new System.Drawing.Size(200, 29);
            this.SBFT_ET.TabIndex = 146;
            // 
            // label293
            // 
            this.label293.AutoSize = true;
            this.label293.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label293.Location = new System.Drawing.Point(263, 14);
            this.label293.Name = "label293";
            this.label293.Size = new System.Drawing.Size(81, 14);
            this.label293.TabIndex = 145;
            this.label293.Text = "Effective Date:";
            // 
            // SBFT_EF
            // 
            this.SBFT_EF.Location = new System.Drawing.Point(267, 43);
            this.SBFT_EF.MinimumSize = new System.Drawing.Size(0, 29);
            this.SBFT_EF.Name = "SBFT_EF";
            this.SBFT_EF.Size = new System.Drawing.Size(200, 29);
            this.SBFT_EF.TabIndex = 144;
            // 
            // SBFT_Act
            // 
            this.SBFT_Act.AutoSize = true;
            this.SBFT_Act.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SBFT_Act.Location = new System.Drawing.Point(460, 110);
            this.SBFT_Act.Name = "SBFT_Act";
            this.SBFT_Act.Size = new System.Drawing.Size(57, 18);
            this.SBFT_Act.TabIndex = 143;
            this.SBFT_Act.Text = "Active";
            this.SBFT_Act.UseVisualStyleBackColor = true;
            // 
            // label294
            // 
            this.label294.AutoSize = true;
            this.label294.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label294.Location = new System.Drawing.Point(9, 79);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(66, 14);
            this.label294.TabIndex = 142;
            this.label294.Text = "Fare Matrix:";
            // 
            // label295
            // 
            this.label295.AutoSize = true;
            this.label295.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label295.Location = new System.Drawing.Point(9, 14);
            this.label295.Name = "label295";
            this.label295.Size = new System.Drawing.Size(69, 14);
            this.label295.TabIndex = 141;
            this.label295.Text = "FareTableID:";
            // 
            // SBFT_Ftid
            // 
            this.SBFT_Ftid.BackColor = System.Drawing.SystemColors.HighlightText;
            this.SBFT_Ftid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SBFT_Ftid.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SBFT_Ftid.ForeColor = System.Drawing.SystemColors.MenuText;
            this.SBFT_Ftid.Location = new System.Drawing.Point(14, 43);
            this.SBFT_Ftid.Name = "SBFT_Ftid";
            this.SBFT_Ftid.Size = new System.Drawing.Size(234, 24);
            this.SBFT_Ftid.TabIndex = 139;
            this.SBFT_Ftid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCreate_PID_KeyPress);
            // 
            // SBFT_Fm
            // 
            this.SBFT_Fm.BackColor = System.Drawing.SystemColors.HighlightText;
            this.SBFT_Fm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SBFT_Fm.Font = new System.Drawing.Font("Google Sans", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SBFT_Fm.ForeColor = System.Drawing.SystemColors.MenuText;
            this.SBFT_Fm.Location = new System.Drawing.Point(14, 107);
            this.SBFT_Fm.Name = "SBFT_Fm";
            this.SBFT_Fm.Size = new System.Drawing.Size(440, 24);
            this.SBFT_Fm.TabIndex = 140;
            // 
            // tb31
            // 
            this.tb31.Controls.Add(this.panel30);
            this.tb31.Location = new System.Drawing.Point(4, 34);
            this.tb31.Name = "tb31";
            this.tb31.Size = new System.Drawing.Size(862, 565);
            this.tb31.TabIndex = 32;
            this.tb31.Text = "ProfileStopBaseds";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel30.Controls.Add(this.PSBExp);
            this.panel30.Controls.Add(this.PSBsave);
            this.panel30.Controls.Add(this.PSBDel);
            this.panel30.Controls.Add(this.dgvPSB);
            this.panel30.Controls.Add(this.PSBgen);
            this.panel30.Controls.Add(this.PSBsid);
            this.panel30.Controls.Add(this.PSBpn);
            this.panel30.Controls.Add(this.label296);
            this.panel30.Controls.Add(this.label297);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(862, 565);
            this.panel30.TabIndex = 221;
            // 
            // PSBExp
            // 
            this.PSBExp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.PSBExp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.PSBExp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PSBExp.Location = new System.Drawing.Point(726, 208);
            this.PSBExp.Name = "PSBExp";
            this.PSBExp.Size = new System.Drawing.Size(133, 45);
            this.PSBExp.TabIndex = 155;
            this.PSBExp.Text = "Export";
            this.PSBExp.UseVisualStyleBackColor = false;
            this.PSBExp.Click += new System.EventHandler(this.PSBExp_Click);
            // 
            // PSBsave
            // 
            this.PSBsave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PSBsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PSBsave.Location = new System.Drawing.Point(490, 143);
            this.PSBsave.Name = "PSBsave";
            this.PSBsave.Size = new System.Drawing.Size(96, 31);
            this.PSBsave.TabIndex = 154;
            this.PSBsave.Text = "Save";
            this.PSBsave.UseVisualStyleBackColor = true;
            this.PSBsave.Visible = false;
            this.PSBsave.Click += new System.EventHandler(this.PSBsave_Click);
            // 
            // PSBDel
            // 
            this.PSBDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PSBDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PSBDel.Location = new System.Drawing.Point(0, 210);
            this.PSBDel.Name = "PSBDel";
            this.PSBDel.Size = new System.Drawing.Size(111, 41);
            this.PSBDel.TabIndex = 153;
            this.PSBDel.Text = "Delete";
            this.PSBDel.UseVisualStyleBackColor = true;
            this.PSBDel.Visible = false;
            this.PSBDel.Click += new System.EventHandler(this.PSBDel_Click);
            // 
            // dgvPSB
            // 
            this.dgvPSB.AllowUserToAddRows = false;
            this.dgvPSB.AllowUserToResizeRows = false;
            this.dgvPSB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPSB.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPSB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPSB.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPSB.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle925.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle925.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle925.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle925.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle925.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle925.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle925.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPSB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle925;
            this.dgvPSB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle926.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle926.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle926.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle926.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle926.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle926.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle926.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPSB.DefaultCellStyle = dataGridViewCellStyle926;
            this.dgvPSB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPSB.EnableHeadersVisualStyles = false;
            this.dgvPSB.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPSB.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPSB.Location = new System.Drawing.Point(0, 241);
            this.dgvPSB.MultiSelect = false;
            this.dgvPSB.Name = "dgvPSB";
            this.dgvPSB.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle927.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle927.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle927.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle927.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle927.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle927.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle927.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPSB.RowHeadersDefaultCellStyle = dataGridViewCellStyle927;
            this.dgvPSB.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPSB.RowTemplate.Height = 33;
            this.dgvPSB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPSB.Size = new System.Drawing.Size(862, 324);
            this.dgvPSB.TabIndex = 152;
            this.dgvPSB.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPSB_CellDoubleClick);
            // 
            // PSBgen
            // 
            this.PSBgen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PSBgen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PSBgen.Location = new System.Drawing.Point(592, 143);
            this.PSBgen.Name = "PSBgen";
            this.PSBgen.Size = new System.Drawing.Size(96, 31);
            this.PSBgen.TabIndex = 151;
            this.PSBgen.Text = "Generate";
            this.PSBgen.UseVisualStyleBackColor = true;
            this.PSBgen.Click += new System.EventHandler(this.PSBgen_Click);
            // 
            // PSBsid
            // 
            this.PSBsid.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.PSBsid.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PSBsid.FormattingEnabled = true;
            this.PSBsid.ItemHeight = 23;
            this.PSBsid.Location = new System.Drawing.Point(8, 104);
            this.PSBsid.Name = "PSBsid";
            this.PSBsid.Size = new System.Drawing.Size(680, 29);
            this.PSBsid.Sorted = true;
            this.PSBsid.TabIndex = 143;
            this.PSBsid.UseSelectable = true;
            this.PSBsid.UseStyleColors = true;
            this.PSBsid.SelectedIndexChanged += new System.EventHandler(this.PSBsid_SelectedIndexChanged);
            // 
            // PSBpn
            // 
            this.PSBpn.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.PSBpn.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PSBpn.FormattingEnabled = true;
            this.PSBpn.ItemHeight = 23;
            this.PSBpn.Location = new System.Drawing.Point(8, 43);
            this.PSBpn.Name = "PSBpn";
            this.PSBpn.Size = new System.Drawing.Size(680, 29);
            this.PSBpn.Sorted = true;
            this.PSBpn.TabIndex = 142;
            this.PSBpn.UseSelectable = true;
            this.PSBpn.UseStyleColors = true;
            this.PSBpn.SelectedIndexChanged += new System.EventHandler(this.PSBpn_SelectedIndexChanged);
            // 
            // label296
            // 
            this.label296.AutoSize = true;
            this.label296.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label296.Location = new System.Drawing.Point(3, 75);
            this.label296.Name = "label296";
            this.label296.Size = new System.Drawing.Size(130, 14);
            this.label296.TabIndex = 141;
            this.label296.Text = "Stop Based FareTableID:";
            // 
            // label297
            // 
            this.label297.AutoSize = true;
            this.label297.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label297.Location = new System.Drawing.Point(3, 14);
            this.label297.Name = "label297";
            this.label297.Size = new System.Drawing.Size(75, 14);
            this.label297.TabIndex = 140;
            this.label297.Text = "Profile Name:";
            // 
            // tb32
            // 
            this.tb32.Controls.Add(this.panel31);
            this.tb32.Location = new System.Drawing.Point(4, 34);
            this.tb32.Name = "tb32";
            this.tb32.Size = new System.Drawing.Size(862, 565);
            this.tb32.TabIndex = 33;
            this.tb32.Text = "RouteStopFares";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel31.Controls.Add(this.RSFExp);
            this.panel31.Controls.Add(this.RSFsave);
            this.panel31.Controls.Add(this.RSFDel);
            this.panel31.Controls.Add(this.dgvRSF);
            this.panel31.Controls.Add(this.RSFGen);
            this.panel31.Controls.Add(this.RSFsid);
            this.panel31.Controls.Add(this.RSFrn);
            this.panel31.Controls.Add(this.label298);
            this.panel31.Controls.Add(this.label299);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(862, 565);
            this.panel31.TabIndex = 221;
            // 
            // RSFExp
            // 
            this.RSFExp.BackColor = System.Drawing.SystemColors.HighlightText;
            this.RSFExp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.RSFExp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RSFExp.Location = new System.Drawing.Point(726, 201);
            this.RSFExp.Name = "RSFExp";
            this.RSFExp.Size = new System.Drawing.Size(133, 45);
            this.RSFExp.TabIndex = 164;
            this.RSFExp.Text = "Export";
            this.RSFExp.UseVisualStyleBackColor = false;
            this.RSFExp.Click += new System.EventHandler(this.RSFExp_Click);
            // 
            // RSFsave
            // 
            this.RSFsave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.RSFsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RSFsave.Location = new System.Drawing.Point(490, 136);
            this.RSFsave.Name = "RSFsave";
            this.RSFsave.Size = new System.Drawing.Size(96, 31);
            this.RSFsave.TabIndex = 163;
            this.RSFsave.Text = "Save";
            this.RSFsave.UseVisualStyleBackColor = true;
            this.RSFsave.Visible = false;
            this.RSFsave.Click += new System.EventHandler(this.RSFsave_Click);
            // 
            // RSFDel
            // 
            this.RSFDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.RSFDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RSFDel.Location = new System.Drawing.Point(0, 203);
            this.RSFDel.Name = "RSFDel";
            this.RSFDel.Size = new System.Drawing.Size(111, 41);
            this.RSFDel.TabIndex = 162;
            this.RSFDel.Text = "Delete";
            this.RSFDel.UseVisualStyleBackColor = true;
            this.RSFDel.Visible = false;
            this.RSFDel.Click += new System.EventHandler(this.RSFDel_Click);
            // 
            // dgvRSF
            // 
            this.dgvRSF.AllowUserToAddRows = false;
            this.dgvRSF.AllowUserToResizeRows = false;
            this.dgvRSF.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRSF.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRSF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRSF.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvRSF.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle928.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle928.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle928.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle928.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle928.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle928.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle928.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRSF.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle928;
            this.dgvRSF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle929.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle929.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle929.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle929.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle929.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle929.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle929.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRSF.DefaultCellStyle = dataGridViewCellStyle929;
            this.dgvRSF.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvRSF.EnableHeadersVisualStyles = false;
            this.dgvRSF.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvRSF.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRSF.Location = new System.Drawing.Point(0, 241);
            this.dgvRSF.MultiSelect = false;
            this.dgvRSF.Name = "dgvRSF";
            this.dgvRSF.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle930.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle930.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle930.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle930.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle930.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle930.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle930.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRSF.RowHeadersDefaultCellStyle = dataGridViewCellStyle930;
            this.dgvRSF.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvRSF.RowTemplate.Height = 33;
            this.dgvRSF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRSF.Size = new System.Drawing.Size(862, 324);
            this.dgvRSF.TabIndex = 161;
            this.dgvRSF.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRSF_CellDoubleClick);
            // 
            // RSFGen
            // 
            this.RSFGen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.RSFGen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RSFGen.Location = new System.Drawing.Point(592, 136);
            this.RSFGen.Name = "RSFGen";
            this.RSFGen.Size = new System.Drawing.Size(96, 31);
            this.RSFGen.TabIndex = 160;
            this.RSFGen.Text = "Generate";
            this.RSFGen.UseVisualStyleBackColor = true;
            this.RSFGen.Click += new System.EventHandler(this.RSFGen_Click);
            // 
            // RSFsid
            // 
            this.RSFsid.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.RSFsid.ForeColor = System.Drawing.SystemColors.WindowText;
            this.RSFsid.FormattingEnabled = true;
            this.RSFsid.ItemHeight = 23;
            this.RSFsid.Location = new System.Drawing.Point(8, 97);
            this.RSFsid.Name = "RSFsid";
            this.RSFsid.Size = new System.Drawing.Size(680, 29);
            this.RSFsid.Sorted = true;
            this.RSFsid.TabIndex = 159;
            this.RSFsid.UseSelectable = true;
            this.RSFsid.UseStyleColors = true;
            // 
            // RSFrn
            // 
            this.RSFrn.FontWeight = MetroFramework.MetroComboBoxWeight.Light;
            this.RSFrn.ForeColor = System.Drawing.SystemColors.WindowText;
            this.RSFrn.FormattingEnabled = true;
            this.RSFrn.ItemHeight = 23;
            this.RSFrn.Location = new System.Drawing.Point(8, 36);
            this.RSFrn.Name = "RSFrn";
            this.RSFrn.Size = new System.Drawing.Size(680, 29);
            this.RSFrn.Sorted = true;
            this.RSFrn.TabIndex = 158;
            this.RSFrn.UseSelectable = true;
            this.RSFrn.UseStyleColors = true;
            // 
            // label298
            // 
            this.label298.AutoSize = true;
            this.label298.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label298.Location = new System.Drawing.Point(3, 68);
            this.label298.Name = "label298";
            this.label298.Size = new System.Drawing.Size(130, 14);
            this.label298.TabIndex = 157;
            this.label298.Text = "Stop Based FareTableID:";
            // 
            // label299
            // 
            this.label299.AutoSize = true;
            this.label299.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label299.Location = new System.Drawing.Point(3, 7);
            this.label299.Name = "label299";
            this.label299.Size = new System.Drawing.Size(72, 14);
            this.label299.TabIndex = 156;
            this.label299.Text = "Route Name:";
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu.Controls.Add(this.button6);
            this.panelMenu.Controls.Add(this.buttonDFRT);
            this.panelMenu.Controls.Add(this.button4);
            this.panelMenu.Controls.Add(this.button16);
            this.panelMenu.Controls.Add(this.buttonSP);
            this.panelMenu.Controls.Add(this.buttonDBIF);
            this.panelMenu.Controls.Add(this.buttonDBFRT);
            this.panelMenu.Controls.Add(this.buttonDBRm);
            this.panelMenu.Controls.Add(this.buttonT);
            this.panelMenu.Controls.Add(this.buttonF);
            this.panelMenu.Controls.Add(this.buttonBP);
            this.panelMenu.Controls.Add(this.buttonm);
            this.panelMenu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu.Location = new System.Drawing.Point(94, 178);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(262, 531);
            this.panelMenu.TabIndex = 65;
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(-2, 430);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(268, 51);
            this.button6.TabIndex = 80;
            this.button6.Text = "Create StopBasedFareTables";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_2);
            // 
            // buttonDFRT
            // 
            this.buttonDFRT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDFRT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonDFRT.FlatAppearance.BorderSize = 0;
            this.buttonDFRT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDFRT.Location = new System.Drawing.Point(-1, 256);
            this.buttonDFRT.Name = "buttonDFRT";
            this.buttonDFRT.Size = new System.Drawing.Size(263, 49);
            this.buttonDFRT.TabIndex = 73;
            this.buttonDFRT.Text = "Create Fare Table Discount";
            this.buttonDFRT.UseVisualStyleBackColor = true;
            this.buttonDFRT.Click += new System.EventHandler(this.buttonDFRT_Click);
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(-1, 471);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(268, 51);
            this.button4.TabIndex = 79;
            this.button4.Text = "Create SingleFixFare";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(-2, 388);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(268, 51);
            this.button16.TabIndex = 78;
            this.button16.Text = "Create BusJeepneySettings";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click_1);
            // 
            // buttonSP
            // 
            this.buttonSP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSP.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonSP.FlatAppearance.BorderSize = 0;
            this.buttonSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSP.Location = new System.Drawing.Point(-4, 343);
            this.buttonSP.Name = "buttonSP";
            this.buttonSP.Size = new System.Drawing.Size(268, 51);
            this.buttonSP.TabIndex = 77;
            this.buttonSP.Text = "Create System Parameter";
            this.buttonSP.UseVisualStyleBackColor = true;
            this.buttonSP.Click += new System.EventHandler(this.buttonSP_Click);
            // 
            // buttonDBIF
            // 
            this.buttonDBIF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDBIF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonDBIF.FlatAppearance.BorderSize = 0;
            this.buttonDBIF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBIF.Location = new System.Drawing.Point(-1, 295);
            this.buttonDBIF.Name = "buttonDBIF";
            this.buttonDBIF.Size = new System.Drawing.Size(265, 59);
            this.buttonDBIF.TabIndex = 77;
            this.buttonDBIF.Text = "Create Increment Fares";
            this.buttonDBIF.UseVisualStyleBackColor = true;
            this.buttonDBIF.Click += new System.EventHandler(this.buttonDBIF_Click);
            // 
            // buttonDBFRT
            // 
            this.buttonDBFRT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDBFRT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonDBFRT.FlatAppearance.BorderSize = 0;
            this.buttonDBFRT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBFRT.Location = new System.Drawing.Point(-2, 210);
            this.buttonDBFRT.Name = "buttonDBFRT";
            this.buttonDBFRT.Size = new System.Drawing.Size(263, 59);
            this.buttonDBFRT.TabIndex = 74;
            this.buttonDBFRT.Text = "Create Fare Table";
            this.buttonDBFRT.UseVisualStyleBackColor = true;
            this.buttonDBFRT.Click += new System.EventHandler(this.buttonDBFRT_Click);
            // 
            // buttonDBRm
            // 
            this.buttonDBRm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDBRm.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonDBRm.FlatAppearance.BorderSize = 0;
            this.buttonDBRm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDBRm.Location = new System.Drawing.Point(1, 170);
            this.buttonDBRm.Name = "buttonDBRm";
            this.buttonDBRm.Size = new System.Drawing.Size(263, 51);
            this.buttonDBRm.TabIndex = 72;
            this.buttonDBRm.Text = "Create Route";
            this.buttonDBRm.UseVisualStyleBackColor = true;
            this.buttonDBRm.Click += new System.EventHandler(this.buttonDBRm_Click);
            // 
            // buttonT
            // 
            this.buttonT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonT.FlatAppearance.BorderSize = 0;
            this.buttonT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonT.Location = new System.Drawing.Point(1, 132);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(263, 45);
            this.buttonT.TabIndex = 71;
            this.buttonT.Text = "Add Terminal";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonF
            // 
            this.buttonF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonF.FlatAppearance.BorderSize = 0;
            this.buttonF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonF.Location = new System.Drawing.Point(0, 93);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(263, 45);
            this.buttonF.TabIndex = 70;
            this.buttonF.Text = "Create Fleet";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonBP
            // 
            this.buttonBP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBP.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonBP.FlatAppearance.BorderSize = 0;
            this.buttonBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBP.Location = new System.Drawing.Point(0, 48);
            this.buttonBP.Name = "buttonBP";
            this.buttonBP.Size = new System.Drawing.Size(263, 45);
            this.buttonBP.TabIndex = 69;
            this.buttonBP.Text = "Create Profile";
            this.buttonBP.UseVisualStyleBackColor = true;
            this.buttonBP.Click += new System.EventHandler(this.buttonBP_Click);
            // 
            // buttonm
            // 
            this.buttonm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonm.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonm.FlatAppearance.BorderSize = 0;
            this.buttonm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonm.Location = new System.Drawing.Point(0, 8);
            this.buttonm.Name = "buttonm";
            this.buttonm.Size = new System.Drawing.Size(263, 51);
            this.buttonm.TabIndex = 68;
            this.buttonm.Text = "Add Merchants";
            this.buttonm.UseVisualStyleBackColor = true;
            this.buttonm.Click += new System.EventHandler(this.buttonm_Click);
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(-4, 15);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(268, 51);
            this.button5.TabIndex = 80;
            this.button5.Text = "Create Card Profiles";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // buttonRBF
            // 
            this.buttonRBF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRBF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonRBF.FlatAppearance.BorderSize = 0;
            this.buttonRBF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRBF.Location = new System.Drawing.Point(-1, 71);
            this.buttonRBF.Name = "buttonRBF";
            this.buttonRBF.Size = new System.Drawing.Size(263, 53);
            this.buttonRBF.TabIndex = 76;
            this.buttonRBF.Text = "Create Route Fares";
            this.buttonRBF.UseVisualStyleBackColor = true;
            this.buttonRBF.Click += new System.EventHandler(this.buttonRBF_Click);
            // 
            // buttonAMENU
            // 
            this.buttonAMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.assoc2;
            this.buttonAMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonAMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonAMENU.FlatAppearance.BorderSize = 0;
            this.buttonAMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAMENU.Location = new System.Drawing.Point(0, 104);
            this.buttonAMENU.Name = "buttonAMENU";
            this.buttonAMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonAMENU.TabIndex = 75;
            this.buttonAMENU.UseVisualStyleBackColor = true;
            this.buttonAMENU.Click += new System.EventHandler(this.Button3_Click);
            // 
            // buttonRDF
            // 
            this.buttonRDF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRDF.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonRDF.FlatAppearance.BorderSize = 0;
            this.buttonRDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRDF.Location = new System.Drawing.Point(-1, 119);
            this.buttonRDF.Name = "buttonRDF";
            this.buttonRDF.Size = new System.Drawing.Size(263, 62);
            this.buttonRDF.TabIndex = 78;
            this.buttonRDF.Text = "Create Discounted Fares";
            this.buttonRDF.UseVisualStyleBackColor = true;
            this.buttonRDF.Click += new System.EventHandler(this.buttonRDF_Click);
            // 
            // logo
            // 
            this.logo.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.logo1;
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logo.Location = new System.Drawing.Point(0, 5);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(356, 175);
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            this.logo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mouse_Down);
            // 
            // panelMenu2
            // 
            this.panelMenu2.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu2.Controls.Add(this.button8);
            this.panelMenu2.Controls.Add(this.button7);
            this.panelMenu2.Controls.Add(this.buttonPD);
            this.panelMenu2.Controls.Add(this.button5);
            this.panelMenu2.Controls.Add(this.buttonRDF);
            this.panelMenu2.Controls.Add(this.buttonRBF);
            this.panelMenu2.Controls.Add(this.buttonPP);
            this.panelMenu2.Controls.Add(this.buttonPR);
            this.panelMenu2.Controls.Add(this.buttonpdb);
            this.panelMenu2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu2.Location = new System.Drawing.Point(94, 178);
            this.panelMenu2.Name = "panelMenu2";
            this.panelMenu2.Size = new System.Drawing.Size(262, 531);
            this.panelMenu2.TabIndex = 77;
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(-2, 462);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(263, 51);
            this.button8.TabIndex = 83;
            this.button8.Text = "Create Route Stop Fares";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(-1, 414);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(263, 51);
            this.button7.TabIndex = 82;
            this.button7.Text = "Create Profile Stopbased";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonPD
            // 
            this.buttonPD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPD.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPD.FlatAppearance.BorderSize = 0;
            this.buttonPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPD.Location = new System.Drawing.Point(0, 186);
            this.buttonPD.Name = "buttonPD";
            this.buttonPD.Size = new System.Drawing.Size(263, 53);
            this.buttonPD.TabIndex = 81;
            this.buttonPD.Text = "Create Profile Discounts";
            this.buttonPD.UseVisualStyleBackColor = true;
            this.buttonPD.Click += new System.EventHandler(this.button51);
            // 
            // buttonPP
            // 
            this.buttonPP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPP.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPP.FlatAppearance.BorderSize = 0;
            this.buttonPP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPP.Location = new System.Drawing.Point(-1, 363);
            this.buttonPP.Name = "buttonPP";
            this.buttonPP.Size = new System.Drawing.Size(263, 51);
            this.buttonPP.TabIndex = 76;
            this.buttonPP.Text = "Create Profile Parameter";
            this.buttonPP.UseVisualStyleBackColor = true;
            this.buttonPP.Click += new System.EventHandler(this.buttonpp_Click);
            // 
            // buttonPR
            // 
            this.buttonPR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPR.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonPR.FlatAppearance.BorderSize = 0;
            this.buttonPR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPR.Location = new System.Drawing.Point(1, 246);
            this.buttonPR.Name = "buttonPR";
            this.buttonPR.Size = new System.Drawing.Size(263, 54);
            this.buttonPR.TabIndex = 73;
            this.buttonPR.Text = "Create Profile Routes";
            this.buttonPR.UseVisualStyleBackColor = true;
            this.buttonPR.Click += new System.EventHandler(this.buttonPR_Click);
            // 
            // buttonpdb
            // 
            this.buttonpdb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonpdb.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonpdb.FlatAppearance.BorderSize = 0;
            this.buttonpdb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonpdb.Location = new System.Drawing.Point(-1, 308);
            this.buttonpdb.Name = "buttonpdb";
            this.buttonpdb.Size = new System.Drawing.Size(263, 51);
            this.buttonpdb.TabIndex = 74;
            this.buttonpdb.Text = "Create Distance Based Profile";
            this.buttonpdb.UseVisualStyleBackColor = true;
            this.buttonpdb.Click += new System.EventHandler(this.buttonpdb_Click);
            // 
            // buttonMoveR
            // 
            this.buttonMoveR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonMoveR.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonMoveR.FlatAppearance.BorderSize = 0;
            this.buttonMoveR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMoveR.Location = new System.Drawing.Point(-1, 306);
            this.buttonMoveR.Name = "buttonMoveR";
            this.buttonMoveR.Size = new System.Drawing.Size(263, 45);
            this.buttonMoveR.TabIndex = 82;
            this.buttonMoveR.Text = "Move Route";
            this.buttonMoveR.UseVisualStyleBackColor = true;
            this.buttonMoveR.Click += new System.EventHandler(this.buttonMoveR_Click);
            // 
            // buttonConfigChecker
            // 
            this.buttonConfigChecker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonConfigChecker.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonConfigChecker.FlatAppearance.BorderSize = 0;
            this.buttonConfigChecker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConfigChecker.Location = new System.Drawing.Point(-2, 256);
            this.buttonConfigChecker.Name = "buttonConfigChecker";
            this.buttonConfigChecker.Size = new System.Drawing.Size(263, 45);
            this.buttonConfigChecker.TabIndex = 74;
            this.buttonConfigChecker.Text = "Config Checker";
            this.buttonConfigChecker.UseVisualStyleBackColor = true;
            this.buttonConfigChecker.Click += new System.EventHandler(this.buttonConfigChecker_Click);
            // 
            // buttonEXIT
            // 
            this.buttonEXIT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonEXIT.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.DOWN1;
            this.buttonEXIT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonEXIT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonEXIT.FlatAppearance.BorderSize = 0;
            this.buttonEXIT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonEXIT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonEXIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEXIT.Location = new System.Drawing.Point(0, 416);
            this.buttonEXIT.Name = "buttonEXIT";
            this.buttonEXIT.Size = new System.Drawing.Size(94, 105);
            this.buttonEXIT.TabIndex = 75;
            this.buttonEXIT.UseVisualStyleBackColor = true;
            this.buttonEXIT.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonCMENU
            // 
            this.buttonCMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonCMENU.BackColor = System.Drawing.Color.DimGray;
            this.buttonCMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.ADD1;
            this.buttonCMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonCMENU.FlatAppearance.BorderSize = 0;
            this.buttonCMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCMENU.Location = new System.Drawing.Point(0, 0);
            this.buttonCMENU.Name = "buttonCMENU";
            this.buttonCMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonCMENU.TabIndex = 68;
            this.buttonCMENU.UseVisualStyleBackColor = false;
            this.buttonCMENU.Click += new System.EventHandler(this.Button11_Click);
            // 
            // titleLB
            // 
            this.titleLB.AutoSize = true;
            this.titleLB.Font = new System.Drawing.Font("Google Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.titleLB.Location = new System.Drawing.Point(402, 19);
            this.titleLB.Name = "titleLB";
            this.titleLB.Size = new System.Drawing.Size(0, 20);
            this.titleLB.TabIndex = 78;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel14.Controls.Add(this.buttonqsl);
            this.panel14.Controls.Add(this.buttonUMENU);
            this.panel14.Controls.Add(this.buttonAMENU);
            this.panel14.Controls.Add(this.buttonCMENU);
            this.panel14.Controls.Add(this.buttonEXIT);
            this.panel14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel14.Location = new System.Drawing.Point(0, 179);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(94, 531);
            this.panel14.TabIndex = 79;
            // 
            // buttonqsl
            // 
            this.buttonqsl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonqsl.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.QQ;
            this.buttonqsl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonqsl.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonqsl.FlatAppearance.BorderSize = 0;
            this.buttonqsl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonqsl.Location = new System.Drawing.Point(0, 314);
            this.buttonqsl.Name = "buttonqsl";
            this.buttonqsl.Size = new System.Drawing.Size(94, 105);
            this.buttonqsl.TabIndex = 77;
            this.buttonqsl.UseVisualStyleBackColor = true;
            this.buttonqsl.Click += new System.EventHandler(this.buttonqsl_Click);
            // 
            // buttonUMENU
            // 
            this.buttonUMENU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUMENU.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.OTHER;
            this.buttonUMENU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonUMENU.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUMENU.FlatAppearance.BorderSize = 0;
            this.buttonUMENU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUMENU.Location = new System.Drawing.Point(0, 209);
            this.buttonUMENU.Name = "buttonUMENU";
            this.buttonUMENU.Size = new System.Drawing.Size(94, 105);
            this.buttonUMENU.TabIndex = 76;
            this.buttonUMENU.UseVisualStyleBackColor = true;
            this.buttonUMENU.Click += new System.EventHandler(this.buttonUMENU_Click);
            // 
            // togDEL
            // 
            this.togDEL.AutoSize = true;
            this.togDEL.Location = new System.Drawing.Point(459, 650);
            this.togDEL.Name = "togDEL";
            this.togDEL.Size = new System.Drawing.Size(80, 22);
            this.togDEL.TabIndex = 80;
            this.togDEL.Text = "Off";
            this.togDEL.UseSelectable = true;
            this.togDEL.CheckedChanged += new System.EventHandler(this.togDEL_CheckedChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(376, 654);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 14);
            this.label4.TabIndex = 81;
            this.label4.Text = "Admin Mode:";
            // 
            // panelMenu3
            // 
            this.panelMenu3.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu3.Controls.Add(this.buttonMoveR);
            this.panelMenu3.Controls.Add(this.button2);
            this.panelMenu3.Controls.Add(this.button1);
            this.panelMenu3.Controls.Add(this.buttonConfigChecker);
            this.panelMenu3.Controls.Add(this.buttonUC);
            this.panelMenu3.Controls.Add(this.buttonUA);
            this.panelMenu3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu3.Location = new System.Drawing.Point(94, 178);
            this.panelMenu3.Name = "panelMenu3";
            this.panelMenu3.Size = new System.Drawing.Size(262, 532);
            this.panelMenu3.TabIndex = 78;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(0, 204);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(263, 45);
            this.button2.TabIndex = 71;
            this.button2.Text = "Manage Profile Print Templates";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(-4, 143);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(263, 45);
            this.button1.TabIndex = 70;
            this.button1.Text = "Manage Print Templates";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // buttonUC
            // 
            this.buttonUC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUC.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUC.FlatAppearance.BorderSize = 0;
            this.buttonUC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUC.Location = new System.Drawing.Point(1, 77);
            this.buttonUC.Name = "buttonUC";
            this.buttonUC.Size = new System.Drawing.Size(263, 45);
            this.buttonUC.TabIndex = 69;
            this.buttonUC.Text = "Manage User Cards";
            this.buttonUC.UseVisualStyleBackColor = true;
            this.buttonUC.Click += new System.EventHandler(this.buttonUC_Click);
            // 
            // buttonUA
            // 
            this.buttonUA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUA.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.buttonUA.FlatAppearance.BorderSize = 0;
            this.buttonUA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUA.Location = new System.Drawing.Point(0, 14);
            this.buttonUA.Name = "buttonUA";
            this.buttonUA.Size = new System.Drawing.Size(263, 45);
            this.buttonUA.TabIndex = 68;
            this.buttonUA.Text = "Manage User Accounts";
            this.buttonUA.UseVisualStyleBackColor = true;
            this.buttonUA.Click += new System.EventHandler(this.button_UA_Click);
            // 
            // panelMenu4
            // 
            this.panelMenu4.BackColor = System.Drawing.Color.DimGray;
            this.panelMenu4.Controls.Add(this.SearchQuery);
            this.panelMenu4.Controls.Add(this.QueryRunner);
            this.panelMenu4.Controls.Add(this.button15);
            this.panelMenu4.Controls.Add(this.button13);
            this.panelMenu4.Controls.Add(this.button14);
            this.panelMenu4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelMenu4.Location = new System.Drawing.Point(94, 179);
            this.panelMenu4.Name = "panelMenu4";
            this.panelMenu4.Size = new System.Drawing.Size(262, 532);
            this.panelMenu4.TabIndex = 82;
            this.panelMenu4.Visible = false;
            // 
            // SearchQuery
            // 
            this.SearchQuery.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SearchQuery.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.SearchQuery.FlatAppearance.BorderSize = 0;
            this.SearchQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchQuery.Location = new System.Drawing.Point(0, 263);
            this.SearchQuery.Name = "SearchQuery";
            this.SearchQuery.Size = new System.Drawing.Size(263, 45);
            this.SearchQuery.TabIndex = 72;
            this.SearchQuery.Text = "SEARCH";
            this.SearchQuery.UseVisualStyleBackColor = true;
            this.SearchQuery.Click += new System.EventHandler(this.SearchQuery_Click);
            // 
            // QueryRunner
            // 
            this.QueryRunner.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.QueryRunner.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.QueryRunner.FlatAppearance.BorderSize = 0;
            this.QueryRunner.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryRunner.Location = new System.Drawing.Point(0, 206);
            this.QueryRunner.Name = "QueryRunner";
            this.QueryRunner.Size = new System.Drawing.Size(263, 45);
            this.QueryRunner.TabIndex = 71;
            this.QueryRunner.Text = "QUERY RUNNER";
            this.QueryRunner.UseVisualStyleBackColor = true;
            this.QueryRunner.Click += new System.EventHandler(this.button2_Click);
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(0, 145);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(263, 45);
            this.button15.TabIndex = 70;
            this.button15.Text = " DELETE SQL";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button16_Click);
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(0, 77);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(263, 45);
            this.button13.TabIndex = 69;
            this.button13.Text = "UPDATE SQL";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(0, 14);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(263, 45);
            this.button14.TabIndex = 68;
            this.button14.Text = "INSERT SQL";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // timerCHECK
            // 
            this.timerCHECK.Interval = 1350;
            this.timerCHECK.Tick += new System.EventHandler(this.timerCHECK_Tick);
            // 
            // qm
            // 
            this.qm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.qm.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.qm1;
            this.qm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.qm.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.qm.FlatAppearance.BorderSize = 0;
            this.qm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.qm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qm.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qm.Location = new System.Drawing.Point(1209, 654);
            this.qm.Name = "qm";
            this.qm.Size = new System.Drawing.Size(24, 25);
            this.qm.TabIndex = 218;
            this.qm.UseVisualStyleBackColor = true;
            this.qm.Click += new System.EventHandler(this.qm_Click);
            // 
            // label300
            // 
            this.label300.AutoSize = true;
            this.label300.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label300.Location = new System.Drawing.Point(480, 85);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(34, 14);
            this.label300.TabIndex = 159;
            this.label300.Text = "Type:";
            // 
            // label301
            // 
            this.label301.AutoSize = true;
            this.label301.Font = new System.Drawing.Font("Google Sans", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label301.Location = new System.Drawing.Point(470, 71);
            this.label301.Name = "label301";
            this.label301.Size = new System.Drawing.Size(34, 14);
            this.label301.TabIndex = 160;
            this.label301.Text = "Type:";
            // 
            // MainProg
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = global::AFPI_Beejees_db.Properties.Resources.bg2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BackImage = global::AFPI_Beejees_db.Properties.Resources.logo1;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(1249, 694);
            this.Controls.Add(this.qm);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.togDEL);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.titleLB);
            this.Controls.Add(this.tabMASTER);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelMenu2);
            this.Controls.Add(this.panelMenu4);
            this.Controls.Add(this.panelMenu3);
            this.Font = new System.Drawing.Font("Google Sans", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "MainProg";
            this.Padding = new System.Windows.Forms.Padding(30, 87, 30, 29);
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Text = " ";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.Load += new System.EventHandler(this.AFPI_Form_Load);
            this.tabMASTER.ResumeLayout(false);
            this.tb1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panelMerc.ResumeLayout(false);
            this.panelMerc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PNCHECKER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PIDCHECKER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMERC)).EndInit();
            this.panelPlaceHolderMerc.ResumeLayout(false);
            this.panelPlaceHolderMerc.PerformLayout();
            this.tb2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBP)).EndInit();
            this.tb3.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.panelBF.ResumeLayout(false);
            this.panelBF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFleets)).EndInit();
            this.tb4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panelTerminal2.ResumeLayout(false);
            this.panelTerminal2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGridFleets)).EndInit();
            this.tb5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelDBR.ResumeLayout(false);
            this.panelDBR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBR)).EndInit();
            this.tb6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panelDFT.ResumeLayout(false);
            this.panelDFT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNRA_DFT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxDFT_RA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDFT)).EndInit();
            this.tb7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panelDBFT.ResumeLayout(false);
            this.panelDBFT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBFT)).EndInit();
            this.tb8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panelRBF.ResumeLayout(false);
            this.panelRBF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRBF)).EndInit();
            this.tb9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panelRDF.ResumeLayout(false);
            this.panelRDF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDF)).EndInit();
            this.tb10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panelPR.ResumeLayout(false);
            this.panelPR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPR)).EndInit();
            this.tb11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panelPDB.ResumeLayout(false);
            this.panelPDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPDB)).EndInit();
            this.tb12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panelPP.ResumeLayout(false);
            this.panelPP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPP)).EndInit();
            this.tb13.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panelSP.ResumeLayout(false);
            this.panelSP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSP)).EndInit();
            this.tb14.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panelDBIF.ResumeLayout(false);
            this.panelDBIF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBIF)).EndInit();
            this.tb15.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panelUA.ResumeLayout(false);
            this.panelUA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUA)).EndInit();
            this.tb16.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panelUC.ResumeLayout(false);
            this.panelUC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUC)).EndInit();
            this.tb17.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvINSERT)).EndInit();
            this.tb18.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUPDATE)).EndInit();
            this.tb19.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDEL)).EndInit();
            this.tb20.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panelBJS.ResumeLayout(false);
            this.panelBJS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBS)).EndInit();
            this.tb21.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQUERY)).EndInit();
            this.tb22.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panelSFF.ResumeLayout(false);
            this.panelSFF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSFF)).EndInit();
            this.tb23.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panelDBCP.ResumeLayout(false);
            this.panelDBCP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDBCP)).EndInit();
            this.tb24.ResumeLayout(false);
            this.p.ResumeLayout(false);
            this.p.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSEARCH)).EndInit();
            this.panelUID.ResumeLayout(false);
            this.panelUID.PerformLayout();
            this.panelTerminalID.ResumeLayout(false);
            this.panelTerminalID.PerformLayout();
            this.panelProfileID.ResumeLayout(false);
            this.panelProfileID.PerformLayout();
            this.tb25.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panelPD.ResumeLayout(false);
            this.panelPD.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPD)).EndInit();
            this.tb26.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCC)).EndInit();
            this.tb27.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tb28.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).EndInit();
            this.tb29.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPPT)).EndInit();
            this.tb30.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSBFT)).EndInit();
            this.tb31.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSB)).EndInit();
            this.tb32.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSF)).EndInit();
            this.panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.panelMenu2.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panelMenu3.ResumeLayout(false);
            this.panelMenu4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroTabControl tabMASTER;
        private System.Windows.Forms.TabPage tb1;
        private System.Windows.Forms.TabPage tb2;
        private System.Windows.Forms.TabPage tb3;
        private System.Windows.Forms.TabPage tb4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TextBox textBox_PSname;
        private System.Windows.Forms.TextBox textBoxEdit_Pname;
        private System.Windows.Forms.Button buttonCreate;
        private System.Windows.Forms.TextBox textBox_CreatePsname;
        private System.Windows.Forms.TextBox textBoxCreatePname;
        private System.Windows.Forms.TextBox textBoxCreate_PID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBoxPNBP;
        private System.Windows.Forms.Button buttonUpdateBP;
        private System.Windows.Forms.TextBox textBoxPNBP2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_TermID;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button buttonTerminalUP;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20d;
        private System.Windows.Forms.TextBox textBoxFleetsName;
        private System.Windows.Forms.Button buttonBF;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox comboBoxBJFID;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroComboBox comboBoxMerchantList;
        private MetroFramework.Controls.MetroComboBox textBoxFname;
        private MetroFramework.Controls.MetroComboBox comboBoxTermT;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tb5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabPage tb6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TabPage tb7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.CheckBox checkBoxDBR;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.RadioButton radioButton_cred;
        private System.Windows.Forms.RadioButton radioButton_debit;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBoxBDR_RID;
        private System.Windows.Forms.TextBox textBoxDBR_RSN;
        private System.Windows.Forms.TextBox textBoxDBR_RLN;
        private System.Windows.Forms.Button buttonDBR_Create;
        private System.Windows.Forms.CheckBox checkBoxDFT_ACT;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBoxDFT_FTB;
        private System.Windows.Forms.TextBox textBoxDFT_DISC;
        private System.Windows.Forms.Label label54;
        private MetroFramework.Controls.MetroDateTime metroDateTimeDFT_F;
        private System.Windows.Forms.Label label55;
        private MetroFramework.Controls.MetroDateTime metroDateTimeDFT_T;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button buttonDFT_Create;
        private System.Windows.Forms.Button buttonDBFT_Create;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxDBFT_BFD;
        private System.Windows.Forms.Label label58;
        private MetroFramework.Controls.MetroDateTime metroDateTimeDBFT_T;
        private System.Windows.Forms.Label label59;
        private MetroFramework.Controls.MetroDateTime metroDateTimeDBFT_F;
        private System.Windows.Forms.CheckBox checkBoxDBFT_A;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBoxDBFT_FTI;
        private System.Windows.Forms.TextBox textBoxDBFT_FA;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button buttonAMENU;
        private System.Windows.Forms.Button buttonDBFRT;
        private System.Windows.Forms.Button buttonDFRT;
        private System.Windows.Forms.Button buttonDBRm;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonBP;
        private System.Windows.Forms.Button buttonm;
        private System.Windows.Forms.Panel panelMenu2;
        private System.Windows.Forms.Button buttonEXIT;
        private System.Windows.Forms.Button buttonpdb;
        private System.Windows.Forms.Button buttonPR;
        private System.Windows.Forms.Button buttonCMENU;
        private System.Windows.Forms.Button buttonRBF;
        private System.Windows.Forms.Button buttonRDF;
        private System.Windows.Forms.TabPage tb8;
        private System.Windows.Forms.TabPage tb9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TabPage tb10;
        private System.Windows.Forms.Panel panel9;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRBF_RID;
        private System.Windows.Forms.Button buttonRBF_Gen;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label71;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRBF_BFI;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRDBF_DID;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRDBF_RID;
        private System.Windows.Forms.Button buttonRDBF_Gen;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPR_RID;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPR_PID;
        private System.Windows.Forms.Button buttonPR_Gen;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TabPage tb11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button buttonPP;
        private System.Windows.Forms.TabPage tb12;
        private System.Windows.Forms.Panel panel11;
        private MetroFramework.Controls.MetroGrid dataGridViewBP;
        private MetroFramework.Controls.MetroGrid dataGridViewFleets;
        private MetroFramework.Controls.MetroGrid metroGridFleets;
        private MetroFramework.Controls.MetroGrid dgvDBR;
        private MetroFramework.Controls.MetroGrid dgvDFT;
        private MetroFramework.Controls.MetroGrid dgvDBFT;
        private MetroFramework.Controls.MetroGrid dgvRBF;
        private MetroFramework.Controls.MetroGrid dgvRDF;
        private MetroFramework.Controls.MetroGrid dgvPR;
        private MetroFramework.Controls.MetroGrid dgvPDB;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label96;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPDB_BID;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPDB_PID;
        private System.Windows.Forms.Button buttonPDB_Gen;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label titleLB;
        private MetroFramework.Controls.MetroGrid dgvPP;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label53;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPP_SPI;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPP_PID;
        private System.Windows.Forms.Button buttonGenPP;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button buttonSP;
        private System.Windows.Forms.TabPage tb13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox textBoxSP_V;
        private MetroFramework.Controls.MetroComboBox metroComboBoxSP_T;
        private MetroFramework.Controls.MetroGrid dgvSP;
        private System.Windows.Forms.Button buttonSP_Gen;
        private MetroFramework.Controls.MetroComboBox metroComboBoxSP_P;
        private System.Windows.Forms.Button buttonDBIF;
        private System.Windows.Forms.TabPage tb14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button buttonBPdel;
        private System.Windows.Forms.PictureBox PB_PIDCHECKER;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox DBIF_ifd;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox DBIF_sd;
        private System.Windows.Forms.TextBox DBIF_ifa;
        private MetroFramework.Controls.MetroGrid dgvDBIF;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Button buttonCreate_DBIF;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label109;
        private MetroFramework.Controls.MetroComboBox DBIF_ftid;
        private System.Windows.Forms.PictureBox PB_PNCHECKER;
        private System.Windows.Forms.Button buttonBFdel;
        private System.Windows.Forms.Button buttonDelT;
        private System.Windows.Forms.Button buttonDELDBR;
        private System.Windows.Forms.Button buttonDELDFT;
        private System.Windows.Forms.Button buttonDELDBFT;
        private System.Windows.Forms.Button buttonDELRBF;
        private System.Windows.Forms.Button buttonDELRDF;
        private System.Windows.Forms.Button buttonDELPR;
        private System.Windows.Forms.Button buttonDELPDB;
        private System.Windows.Forms.Button buttonDELPP;
        private System.Windows.Forms.Button buttonDELSP;
        private System.Windows.Forms.Button buttonDELDBIF;
        private System.Windows.Forms.Panel panel14;
        private MetroFramework.Controls.MetroToggle togDEL;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonDELMERC;
        private System.Windows.Forms.Button buttonUMENU;
        private System.Windows.Forms.Panel panelMenu3;
        private System.Windows.Forms.Button buttonUC;
        private System.Windows.Forms.Button buttonUA;
        private System.Windows.Forms.TabPage tb15;
        private System.Windows.Forms.TabPage tb16;
        private System.Windows.Forms.Panel panel15;
        private MetroFramework.Controls.MetroComboBox metroComboBoxUA_MN;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox_UA_UID;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TextBox textBox_UA_SN;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox textBox_UA_LN;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox textBoxUA_CID;
        private System.Windows.Forms.Label label121;
        private MetroFramework.Controls.MetroDateTime metroDateTimeEDUA2;
        private System.Windows.Forms.Label label122;
        private MetroFramework.Controls.MetroDateTime metroDateTimeEDUA;
        private MetroFramework.Controls.MetroGrid dgvUA;
        private System.Windows.Forms.Button buttonUP_UA;
        private System.Windows.Forms.Button buttonDELUA;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.RadioButton radioButtonDFT_U;
        private System.Windows.Forms.RadioButton radioButtonDFT_E;
        private System.Windows.Forms.Button buttonSAVE_Fleets;
        private System.Windows.Forms.Button buttonSAVEDBR;
        private MetroFramework.Controls.MetroComboBox comboBoxBF;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.TextBox textBoxNewPIDBF;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox textBoxNewTID;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private MetroFramework.Controls.MetroComboBox metroComboBoxTType;
        private MetroFramework.Controls.MetroComboBox metroComboBoxFleet;
        private System.Windows.Forms.Panel panelTerminal2;
        private System.Windows.Forms.Button buttonST;
        private System.Windows.Forms.Panel panelDBR;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.CheckBox checkBoxNDBR;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.RadioButton radioButtonNdcDBR;
        private System.Windows.Forms.RadioButton radioButtonNddDBR;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.TextBox textBoxNRID_DBR;
        private System.Windows.Forms.TextBox textBoxNRSN_DBR;
        private System.Windows.Forms.TextBox textBoxRLN_DBR;
        private System.Windows.Forms.Button buttonqsl;
        private System.Windows.Forms.NumericUpDown textBoxDFT_RA;
        private System.Windows.Forms.Panel panelMenu4;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TabPage tb17;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TabPage tb18;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TabPage tb19;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private MetroFramework.Controls.MetroGrid dgvINSERT;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Button buttonPlayIns;
        private System.Windows.Forms.Label labelINSfile;
        private System.Windows.Forms.Label label158;
        private MetroFramework.Controls.MetroGrid dgvUPDATE;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label163;
        private MetroFramework.Controls.MetroGrid dgvDEL;
        private System.Windows.Forms.Button buttonOpenINS;
        private MetroFramework.Controls.MetroComboBox textBoxINS;
        private MetroFramework.Controls.MetroComboBox mcbxColUP;
        private MetroFramework.Controls.MetroComboBox mcbxTB;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.TextBox mcbxVALDEL;
        private System.Windows.Forms.Label label164;
        private MetroFramework.Controls.MetroComboBox mcbxCOLDEL;
        private MetroFramework.Controls.MetroComboBox mcbxTBDEL;
        private System.Windows.Forms.Button buttonDEL;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.TextBox textBoxVALUP;
        private System.Windows.Forms.Button buttonUp;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TabPage tb20;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel16;
        private MetroFramework.Controls.MetroComboBox metroComboBoxVID;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.RadioButton radioButtonDISPATCHER;
        private System.Windows.Forms.RadioButton radioButtonDRIVER;
        private System.Windows.Forms.Button buttonUC_DEL;
        private System.Windows.Forms.Button buttonUCADD;
        private MetroFramework.Controls.MetroGrid dgvUC;
        private System.Windows.Forms.Label label125;
        private MetroFramework.Controls.MetroComboBox metroComboBoxUC_UN;
        private System.Windows.Forms.Label label126;
        private MetroFramework.Controls.MetroDateTime metroDateTimeUCED2;
        private System.Windows.Forms.Label label127;
        private MetroFramework.Controls.MetroDateTime metroDateTimeUCED;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox textBoxUC_UID;
        private System.Windows.Forms.Label labelPID;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private MetroFramework.Controls.MetroDateTime DTBSTO;
        private MetroFramework.Controls.MetroDateTime DTBSFROM;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.TextBox SIBS;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.TextBox LNBS;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.TextBox VIDBS;
        private MetroFramework.Controls.MetroComboBox TIDBS;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Button buttonDELBS;
        private System.Windows.Forms.Button buttonUPBS;
        private MetroFramework.Controls.MetroGrid dgvBS;
        private System.Windows.Forms.TextBox textBoxSETUP;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Button QueryRunner;
        private System.Windows.Forms.TabPage tb21;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button buttonQuery;
        private System.Windows.Forms.Label labelQuery;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.TextBox textBoxQuery;
        private System.Windows.Forms.Label label180;
        private MetroFramework.Controls.MetroGrid dgvQUERY;
        private System.Windows.Forms.Label label33;
        private MetroFramework.Controls.MetroComboBox comboBoxMercBP;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panelBF;
        private System.Windows.Forms.TextBox textBoxAppend;
        private System.Windows.Forms.Label labelAlert;
        private System.Windows.Forms.Panel panelPlaceHolderMerc;
        private MetroFramework.Controls.MetroGrid dgvMERC;
        private System.Windows.Forms.Panel panelMerc;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.RadioButton radioButtonDFT_D;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage tb22;
        private System.Windows.Forms.TabPage tb23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBoxSFF_FA;
        private System.Windows.Forms.Button buttonSFFADD;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label60;
        private MetroFramework.Controls.MetroDateTime metroDateTimeSFF_TO;
        private MetroFramework.Controls.MetroDateTime metroDateTimeSFF_FROM;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBoxSFF_FTID;
        private System.Windows.Forms.Button buttonSFFDEL;
        private MetroFramework.Controls.MetroGrid dgvSFF;
        private System.Windows.Forms.CheckBox checkBoxSFF_A;
        private MetroFramework.Controls.MetroComboBox metroComboBoxDBCP_DFTID;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox textBoxDBCP_CPID;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox textBoxDBCP_CPN;
        private System.Windows.Forms.Button buttonDBCPDEL;
        private MetroFramework.Controls.MetroGrid dgvDBCP;
        private System.Windows.Forms.Button buttonDBCPADD;
        private System.Windows.Forms.Button buttonSaveBP;
        private System.Windows.Forms.Button buttonSaveDFT;
        private System.Windows.Forms.Panel panelDFT;
        private System.Windows.Forms.RadioButton radioButtonNDOWN_DFT;
        private System.Windows.Forms.NumericUpDown numericUpDownNRA_DFT;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private MetroFramework.Controls.MetroDateTime metroDateTimeNTO_DFT;
        private System.Windows.Forms.Label label183;
        private MetroFramework.Controls.MetroDateTime metroDateTimeNED_DFT;
        private System.Windows.Forms.CheckBox checkBoxA_DFT;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.RadioButton radioButtonNUP_DFT;
        private System.Windows.Forms.RadioButton radioButtonExactNDFT;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.TextBox textBoxNFTID_DFT;
        private System.Windows.Forms.TextBox textBoxND_DFT;
        private System.Windows.Forms.Panel panelDBFT;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.TextBox textBoxNBFD_DBFT;
        private System.Windows.Forms.Label label192;
        private MetroFramework.Controls.MetroDateTime metroDateTimeNTO_DBFT;
        private System.Windows.Forms.Label label193;
        private MetroFramework.Controls.MetroDateTime metroDateTimeNED_DBFT;
        private System.Windows.Forms.CheckBox checkBoxA_DBFT;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.TextBox textBoxNFTID_DBFT;
        private System.Windows.Forms.TextBox textBoxNFA_DBFT;
        private System.Windows.Forms.Button buttonSAVE_DBFT;
        private System.Windows.Forms.Panel panelDBIF;
        private MetroFramework.Controls.MetroComboBox cbxNewFTIDDBIF;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.TextBox textBoxNIFD_DBIF;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.TextBox textBoxNSDDBIF;
        private System.Windows.Forms.TextBox textBoxNIF_DBIF;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Button buttonSAVE_DBIF;
        private System.Windows.Forms.CheckBox checkBoxOneDBIF;
        private System.Windows.Forms.Panel panelSP;
        private MetroFramework.Controls.MetroComboBox metroComboBoxSP_T2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxSP_P2;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.TextBox textBoxSP_V2;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Button buttonSaveSP;
        private System.Windows.Forms.Panel panelBJS;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label203;
        private MetroFramework.Controls.MetroDateTime DTBSTO2;
        private MetroFramework.Controls.MetroDateTime DTBSFROM2;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.TextBox SIBS2;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.TextBox LNBS2;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.TextBox VIDBS2;
        private MetroFramework.Controls.MetroComboBox TIDBS2;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Button buttonSaveBJS;
        private System.Windows.Forms.Panel panelSFF;
        private System.Windows.Forms.CheckBox checkBoxSFF_A2;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.TextBox textBoxSFF_FA2;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.Label label217;
        private MetroFramework.Controls.MetroDateTime metroDateTimeSFF_TO2;
        private MetroFramework.Controls.MetroDateTime metroDateTimeSFF_FROM2;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.TextBox textBoxSFF_FTID2;
        private System.Windows.Forms.Button buttonSaveSFF;
        private System.Windows.Forms.Panel panelDBCP;
        private MetroFramework.Controls.MetroComboBox metroComboBoxDBCP_DFTID2;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.TextBox textBoxDBCP_CPID2;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Button buttonSaveDBCP;
        private System.Windows.Forms.Panel panelUC;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.RadioButton radioButtonDISPATCHER2;
        private System.Windows.Forms.RadioButton radioButtonDRIVER2;
        private System.Windows.Forms.Label label230;
        private MetroFramework.Controls.MetroComboBox metroComboBoxUC_UN2;
        private System.Windows.Forms.Label label231;
        private MetroFramework.Controls.MetroDateTime metroDateTimeUCED2second;
        private System.Windows.Forms.Label label232;
        private MetroFramework.Controls.MetroDateTime metroDateTimeUCEDsecond;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.TextBox textBoxUC_UID2;
        private System.Windows.Forms.Button buttonSaveUC;
        private System.Windows.Forms.Panel panelUA;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label label227;
        private MetroFramework.Controls.MetroDateTime metroDateTimeEDUA2second;
        private System.Windows.Forms.Label label236;
        private MetroFramework.Controls.MetroDateTime metroDateTimeEDUAsecond;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.TextBox textBox_UA_SN2;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.TextBox textBox_UA_LN2;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.TextBox textBoxUA_CID2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxUA_MN2;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.TextBox textBox_UA_UID2;
        private System.Windows.Forms.Button buttonSaveUA;
        private System.Windows.Forms.Panel panelRBF;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.Label label247;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRBF_BFI2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRBF_RID2;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.Button buttonSAVERBF;
        private System.Windows.Forms.Panel panelRDF;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label251;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRDBF_DID2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRDBF_RID2;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.Button buttonSAVERDF;
        private System.Windows.Forms.Button buttonSavePR;
        private System.Windows.Forms.Panel panelPR;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.Label label255;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPR_RID2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPR_PID2;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Button buttonSAVEPDB;
        private System.Windows.Forms.Panel panelPDB;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label259;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPDB_BID2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPDB_PID2;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Button buttonsavePP;
        private System.Windows.Forms.Label labelSSVAL;
        private System.Windows.Forms.Panel panelPP;
        private System.Windows.Forms.Label labelSSVAL2;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPP_SPI2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxPP_PID2;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Button SearchQuery;
        private System.Windows.Forms.TabPage tb24;
        private System.Windows.Forms.Panel p;
        private MetroFramework.Controls.MetroComboBox metroComboBoxSearchParam;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.Panel panelTerminalID;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.TextBox textBoxDBCP_CPN2;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.TextBox txtBxTerminalID;
        private System.Windows.Forms.Button buttonSearchTerminal;
        private MetroFramework.Controls.MetroGrid dgvSEARCH;
        private System.Windows.Forms.Panel panelProfileID;
        private System.Windows.Forms.Button buttonProfileID;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.TextBox textBoxProfileID;
        private MetroFramework.Controls.MetroComboBox metroComboBoxParam;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.TextBox textBoxVal;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.Panel panelUID;
        private System.Windows.Forms.Button buttonUID;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.TextBox textBoxUID;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.TabPage tb25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panelPD;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private MetroFramework.Controls.MetroComboBox mcbxFTID2;
        private MetroFramework.Controls.MetroComboBox mcbxProfiles2;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Button buttonSAVEPD;
        private System.Windows.Forms.Button buttonDELPD;
        private MetroFramework.Controls.MetroGrid dgvPD;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Label label281;
        private MetroFramework.Controls.MetroComboBox mcbxFTID;
        private MetroFramework.Controls.MetroComboBox mcbxProfiles;
        private System.Windows.Forms.Button buttonGENPD;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.Button buttonPD;
        private System.Windows.Forms.CheckBox checkBoxPro_DBFT2;
        private System.Windows.Forms.CheckBox checkBoxAcc_DBFT2;
        private System.Windows.Forms.CheckBox checkBoxPro_DBFT;
        private System.Windows.Forms.CheckBox checkBoxAcc_DBFT;
        private System.Windows.Forms.Button buttonexpmerc;
        private System.Windows.Forms.Button buttonexpbp;
        private System.Windows.Forms.Button buttonexpbf;
        private System.Windows.Forms.Button buttonterminalexp;
        private System.Windows.Forms.Button buttonexpdbr;
        private System.Windows.Forms.Button buttonexpdft;
        private System.Windows.Forms.Button buttonexpdbft;
        private System.Windows.Forms.Button buttonexprbf;
        private System.Windows.Forms.Button buttonexprdf;
        private System.Windows.Forms.Button buttonexppr;
        private System.Windows.Forms.Button buttonexppdb;
        private System.Windows.Forms.Button buttonexppp;
        private System.Windows.Forms.Button buttonexpsp;
        private System.Windows.Forms.Button buttonexpdbif;
        private System.Windows.Forms.Button buttonexpua;
        private System.Windows.Forms.Button buttonexpuc;
        private System.Windows.Forms.Button buttonexpbjs;
        private System.Windows.Forms.Button buttonexpsff;
        private System.Windows.Forms.Button buttonexpdbcp;
        private System.Windows.Forms.Button buttonexppd;
        private System.Windows.Forms.Button buttonRemoveSP;
        private System.Windows.Forms.TabPage tb26;
        private System.Windows.Forms.Timer timerCHECK;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label labelCHECK;
        private System.Windows.Forms.Button startInitial;
        private MetroFramework.Controls.MetroGrid dgvCC;
        private System.Windows.Forms.Button buttonConfigChecker;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.Button buttonPauseResume;
        private System.Windows.Forms.Label efx;
        private System.Windows.Forms.Button qm;
        private System.Windows.Forms.CheckBox checkBoxPro_DFT2;
        private System.Windows.Forms.CheckBox checkBoxAcc_DFT2;
        private System.Windows.Forms.CheckBox checkBoxPro_DFT;
        private System.Windows.Forms.CheckBox checkBoxAcc_DFT;
        private System.Windows.Forms.Button buttonMoveR;
        private System.Windows.Forms.TabPage tb27;
        private System.Windows.Forms.Panel panel26;
        private MetroFramework.Controls.MetroComboBox comboCHECK;
        private System.Windows.Forms.Label label284;
        private MetroFramework.Controls.MetroComboBox selRoute;
        private System.Windows.Forms.Label label25;
        private MetroFramework.Controls.MetroComboBox moveTo;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button buttonMove;
        private System.Windows.Forms.TabPage tb28;
        private System.Windows.Forms.TabPage tb29;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button buttonPPE;
        private System.Windows.Forms.Button buttonPPDEL;
        private MetroFramework.Controls.MetroGrid dgvPPT;
        private System.Windows.Forms.Button PPsave;
        private System.Windows.Forms.Button PPadd;
        private System.Windows.Forms.TextBox PPVERtxt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button PTExp;
        private System.Windows.Forms.Button PTDel;
        private MetroFramework.Controls.MetroGrid dgvPT;
        private System.Windows.Forms.Button PTSave;
        private System.Windows.Forms.Button PTAdd;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox PTTID;
        private MetroFramework.Controls.MetroComboBox PTTT;
        private System.Windows.Forms.Label label288;
        private System.Windows.Forms.Label label287;
        private MetroFramework.Controls.MetroComboBox PPTIDcbx;
        private System.Windows.Forms.Label label286;
        private MetroFramework.Controls.MetroComboBox PPPcbx;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.Label label290;
        private MetroFramework.Controls.MetroDateTime PTDT2;
        private MetroFramework.Controls.MetroDateTime PTDT;
        private System.Windows.Forms.TextBox PTT;
        private System.Windows.Forms.Label label291;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox PTTN;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TabPage tb30;
        private System.Windows.Forms.TabPage tb31;
        private System.Windows.Forms.TabPage tb32;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button SBFTexp;
        private System.Windows.Forms.Button SBFTDel;
        private MetroFramework.Controls.MetroGrid dgvSBFT;
        private System.Windows.Forms.Button SBFTSave;
        private System.Windows.Forms.Button SBFTAdd;
        private System.Windows.Forms.CheckBox SBFT_Pro;
        private System.Windows.Forms.CheckBox SBFT_Acc;
        private System.Windows.Forms.Label label292;
        private MetroFramework.Controls.MetroDateTime SBFT_ET;
        private System.Windows.Forms.Label label293;
        private MetroFramework.Controls.MetroDateTime SBFT_EF;
        private System.Windows.Forms.CheckBox SBFT_Act;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.Label label295;
        private System.Windows.Forms.TextBox SBFT_Ftid;
        private System.Windows.Forms.TextBox SBFT_Fm;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Button PSBExp;
        private System.Windows.Forms.Button PSBsave;
        private System.Windows.Forms.Button PSBDel;
        private MetroFramework.Controls.MetroGrid dgvPSB;
        private System.Windows.Forms.Button PSBgen;
        private MetroFramework.Controls.MetroComboBox PSBsid;
        private MetroFramework.Controls.MetroComboBox PSBpn;
        private System.Windows.Forms.Label label296;
        private System.Windows.Forms.Label label297;
        private System.Windows.Forms.Button RSFExp;
        private System.Windows.Forms.Button RSFsave;
        private System.Windows.Forms.Button RSFDel;
        private MetroFramework.Controls.MetroGrid dgvRSF;
        private System.Windows.Forms.Button RSFGen;
        private MetroFramework.Controls.MetroComboBox RSFsid;
        private MetroFramework.Controls.MetroComboBox RSFrn;
        private System.Windows.Forms.Label label298;
        private System.Windows.Forms.Label label299;
        private System.Windows.Forms.CheckBox SFFPro;
        private System.Windows.Forms.CheckBox SFFacc;
        private System.Windows.Forms.CheckBox SFFPro2;
        private System.Windows.Forms.CheckBox SFFacc2;
        private System.Windows.Forms.Label labelList3;
        private System.Windows.Forms.Label labelList;
        private System.Windows.Forms.Label labelTT;
        private System.Windows.Forms.Label label301;
        private System.Windows.Forms.Label label300;
    }
}

